eval 'exec perl $0 $*'
        if 0;

$XDIM = 256;
$YDIM = 256;
$ZDIM = 256;

$NumArgs = $#ARGV+1;
$NTHREADS = $ARGV[0];
$NTHREADS =~ tr/A-Z/a-z/;

if($NumArgs != 1){
  print "./run.pl [threads]\n";
  exit(0);
}

$EXECUTABLE = "./run";

for($XDimPerBlock=$XDIM;$XDimPerBlock<=$XDIM;$XDimPerBlock*=2){
  for($YDimPerBlock=8;$YDimPerBlock<=32;$YDimPerBlock*=2){
    for($ZDimPerBlock=$ZDIM/2;$ZDimPerBlock<=$ZDIM;$ZDimPerBlock*=2){
      for($XBlocks=1;$XBlocks<=$XDIM;$XBlocks*=2){
        for($YBlocks=1;$YBlocks<=$YDIM;$YBlocks*=2){
          for($ZBlocks=1;$ZBlocks<=$ZDIM;$ZBlocks*=2){
            $ChunkMax = $XDIM*$YDIM*$ZDIM / $XDimPerBlock / $YDimPerBlock / $ZDimPerBlock;
            if($NTHREADS==1){$ChunkMax=1;}
            for($Chunks=1;$Chunks<=$ChunkMax;$Chunks*=2){
              if( ($XDimPerBlock*$XBlocks == $XDIM) && ($YDimPerBlock*$YBlocks == $YDIM) && ($ZDimPerBlock*$ZBlocks == $ZDIM) ){
                if($NTHREADS*$Chunks <= $XBlocks*$YBlocks*$ZBlocks){
                  printf("%s %3d %3d %3d   %3d %3d %3d   %3d   %3d\n",$EXECUTABLE,$XDimPerBlock,$YDimPerBlock,$ZDimPerBlock,$XBlocks,$YBlocks,$ZBlocks,$NTHREADS,$Chunks);
                  //system("$EXECUTABLE $XDimPerBlock $YDimPerBlock $ZDimPerBlock $XBlocks $YBlocks $ZBlocks $NTHREADS $Chunks |grep GFl");
}}}}}}}}}

