volatile int32_t * spe_locks[MaxThreads];

/*
void _usleep(double microseconds){
  uint64_t DeltaTicks = (1000*microseconds * FrequencyGHz);
  uint64_t Start = CycleTime();
  uint64_t End   = CycleTime();
  //printf("%016llx %016llx %016llx\n",Start,End,DeltaTicks);
  while( (uint64_t)(End-Start) < DeltaTicks )End = CycleTime();
}
*/

void _sleep_ticks(uint32_t DeltaTicks){
  uint64_t Start = CycleTime();
  uint64_t End   = CycleTime();
  while( (uint64_t)(End-Start) < DeltaTicks )End = CycleTime();
}

void barrier_wait(uint32_t ActualSPEs){              
  int i;
  //for(i=0;i<ActualSPEs;i++){while(((volatile int32_t)(*(volatile int32_t *)spe_locks[i]))==0){_usleep(0.5);}}
  for(i=0;i<ActualSPEs;i++){while(((volatile int32_t)(*(volatile int32_t *)spe_locks[i]))==0){_sleep_ticks(100);}}
  for(i=0;i<ActualSPEs;i++){       *spe_locks[i]=0;}
}
