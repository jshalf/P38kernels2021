
//------------------------------------------------------------------------------------------------------------------------------

typedef struct {
  volatile uint32_t Size; // in bytes
  volatile uint32_t EAL;  // in bytes
} DMAListElement;

//------------------------------------------------------------------------------------------------------------------------------

typedef struct _BEST_ALIGNMENT {
  uint32_t ActualNonZeros;              // Actual number of nonzeros (including symmetry)
  uint32_t NRows,NCols,NTiles;          // Actual number of Rows, Columns and Tiles in this matrix
  uint32_t ROffset,COffset;             // Offsets into the source and destination vectors (this matrix might be a cache block in a larger matrix)

  uint32_t Bits,Format,logR,logC;	// Index Bits, Format, register blocking RxC (only powers of 2)
  uint32_t InitY;                       // This matrix must initialize the destination vector
  uint32_t FirstRow,LastRow;            // first and last row to accelerate BCSR
  uint32_t SourceCompression;


  uint32_t ColumnsTransfered;		// NOTE: is the total number of doubles of the (sparse) source vector touched by this cache block
  uint32_t DMAStanzas;			// number of stanzas (elements) in the DMA list
  DMAListElement *DMAList;              // Preformatted/constructed DMA List to gather multiple stanzas of X and pack them together
  					// each is : Size, EAL (low 32b of effective address)
  					// requires that the column indices are relative to the packed form (not sparse)
					// load list, DMA_GETL, SpMV
					
  uint32_t CacheLines;			// number of cache lines that need to be copied from X to tempX
  uint32_t *CacheLineList;		// offsets in source vector of cache lines to get


    double *V;                          // [V]alue array
  uint32_t *P;                          // row [P]ointers (relative to column index array ~ RxC tile relative)
  uint16_t *C16b;                       // [C]olumn index array (stored in 16bit)
  uint32_t *C32b;                       // [C]olumn index array (stored in 32bit)
  uint16_t *R16b;                       // [R]ow coordinate array (stored in 16bit)
  uint32_t *R32b;                       // [R]ow coordinate array (stored in 32bit)

  void *base0,*base1;
  uint64_t base0Size,base1Size;

} SparseMatrix;

//------------------------------------------------------------------------------------------------------------------------------

typedef struct _BEST_ALIGNMENT {
  uint32_t ActualNonZeros;			// Actual number of nonzeros (including symmetry)
  uint32_t NRows,NCols;				// Actual number of Rows and Columns in this matrix
  uint32_t OptimizationMask;
  uint32_t RThreads,CThreads;			// How the matrix was parallelized (thread blocks)
  uint32_t FirstBlockForThread[MaxThreads+1];	// all values >= ActualThreads should be the same
  double FlopToByteRatio;
  double *tempX[MaxThreads];			// can be used for cache blocking
  double *tempY[MaxThreads];			// can be used for reductions

  SparseMatrix * blocks;			// all the sparse matrix cache blocks

} BlockedSparseMatrix;

//------------------------------------------------------------------------------------------------------------------------------

