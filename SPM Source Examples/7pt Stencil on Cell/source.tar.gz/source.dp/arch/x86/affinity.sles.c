#include <sched.h>
cpu_set_t OriginalMask;
 int32_t NUMA_Cores          = -1;
 int32_t NUMA_LogCores       = -1;

void Affinity_Init(){ 
  printf("implementing NUMA via <sched.h>\n");

  CPU_ZERO(&OriginalMask);
  sched_getaffinity(0, sizeof(OriginalMask), &OriginalMask);
  uint32_t i;
  for(i=0;i<MaxThreads;i++)if(CPU_ISSET(i,&OriginalMask)){
    if(NUMA_Cores<0)NUMA_Cores=0;NUMA_Cores++;
  }
  switch(NUMA_Cores){
    case   1: NUMA_LogCores = 0;break;
    case   2: NUMA_LogCores = 1;break;
    case   4: NUMA_LogCores = 2;break;
    case   8: NUMA_LogCores = 3;break;
    case  16: NUMA_LogCores = 4;break;
    case  32: NUMA_LogCores = 5;break;
    case  64: NUMA_LogCores = 6;break;
    case 128: NUMA_LogCores = 7;break;
    case 266: NUMA_LogCores = 8;break;
  }

  printf("  found %d cores\n",NUMA_Cores);
  if(NUMA_Cores <= 0)exit(0);
  return;
}

void Affinity_Bind_Memory(uint32_t thread){
  uint32_t thread2=thread;
  #ifdef INTERLEAVED_MULTICORE
    thread2 = ((thread<<1) | (thread>>(NUMA_LogCores-1))) & (uint64_t)(NUMA_Cores-1); // (twiddled mapping on the clovertown)
  #endif
  cpu_set_t NewMask;
  CPU_ZERO(&NewMask);
  CPU_SET(thread2,&NewMask);
  if(sched_setaffinity(0, sizeof(NewMask), &NewMask)<0){
    printf("Couldn't bind thread=%d to cpu=%d\n",thread,thread2);
    exit(0);
  }
  sched_getaffinity(0, sizeof(NewMask), &NewMask);
  return;
}

void Affinity_Bind_Thread(uint32_t thread){
  uint32_t thread2=thread;
  #ifdef INTERLEAVED_MULTICORE
    thread2 = ((thread<<1) | (thread>>(NUMA_LogCores-1))) & (uint64_t)(NUMA_Cores-1); // (twiddled mapping on the clovertown)
  #endif
  cpu_set_t NewMask;
  CPU_ZERO(&NewMask);
  CPU_SET(thread2,&NewMask);
  if(sched_setaffinity(0, sizeof(NewMask), &NewMask)<0){
    printf("Couldn't bind thread=%d to cpu=%d\n",thread,thread2);
    exit(0);
  }
  sched_getaffinity(0, sizeof(NewMask), &NewMask);
  return;
}

void Affinity_unBind(){
  cpu_set_t NewMask;
  CPU_ZERO(&NewMask);
  if(sched_setaffinity(0, sizeof(OriginalMask), &OriginalMask)<0){
    printf("Couldn't unbind threads\n");exit(0);
  }
  sched_getaffinity(0, sizeof(NewMask), &NewMask);
  return;
}
