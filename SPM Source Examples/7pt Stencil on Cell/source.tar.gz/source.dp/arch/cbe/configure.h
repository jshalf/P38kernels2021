#define CacheLineSizeInBytes                         128
#define CacheLineSizeInDoubles (CacheLineSizeInBytes>>3)
#define CacheLineSizeInQWords  (CacheLineSizeInBytes>>4)
#define CacheLinesAvailable                         1500
