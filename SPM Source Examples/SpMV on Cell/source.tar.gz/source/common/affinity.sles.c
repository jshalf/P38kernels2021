// SpMV Affinity routines
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

int32_t MALLOC_VIA_NUMA   =  1;
int32_t NUMA_Sockets      = -1;
int32_t NUMA_CoresPerNode = -1;
int32_t NUMA_Cores        = -1;
int32_t NUMA_LogCores     = -1;

#define MaxNodes 8
//uint64_t NUMA_Heap_Size_in_Bytes =  256*1024*1024;
uint64_t NUMA_Heap_Size_in_Bytes =  (uint64_t)1*1024*1024*1024;
uint64_t NUMA_Heap_Pad_in_Bytes  =                 1*1024*1024;
void *NUMA_Heap_Start[MaxNodes];
void *NUMA_Heap_End[MaxNodes];
void *NUMA_Heap_free[MaxNodes];

#if defined(ENABLE_AFFINITY_VIA_NUMA)
  #include <numa.h>
  nodemask_t nodemask;
#endif

#if defined(ENABLE_AFFINITY_VIA_SCHED)
  #include <sched.h>
  uint64_t OriginalMask;
#endif

#if defined(ENABLE_AFFINITY_VIA_SOLARIS)
  #include <sys/processor.h>
  #include <sys/procset.h>
#endif

void NUMA_Heap_Flush(){
  int i;
  for(i=0;i<MaxNodes;i++){
    NUMA_Heap_free[i]=(void*)(((uint64_t)NUMA_Heap_Start[i]+NUMA_Heap_Pad_in_Bytes+127)& ~(127));
  }
}

void *NUMA_MALLOC(uint64_t size,uint32_t thr){
  if(MALLOC_VIA_NUMA && (NUMA_Sockets>1)){
    size = (size + 127) & ~(127);
    uint32_t node = thr / NUMA_CoresPerNode;
    uint64_t freeSpace = (uint64_t)NUMA_Heap_End[node] - (uint64_t)NUMA_Heap_free[node];
    //printf("trying to allocate %ld bytes on node %d(%d)\n",size,node,thr);
    if(freeSpace>(size+128)){
      void*rv = NUMA_Heap_free[node];
      NUMA_Heap_free[node]+=size+128;
      //printf("%016lx %016lx %016lx\n",NUMA_Heap_Start[node],NUMA_Heap_free[node],NUMA_Heap_End[node]);
      return(rv);
    }else{printf("insufficient space\n");return(MALLOC(size));}
  }else{return(MALLOC(size));}
}

void NUMA_FREE(void *ptr){
  // FIX - test to see if Start<ptr<End
  if(MALLOC_VIA_NUMA && (NUMA_Sockets>1)){
  }else{FREE(ptr);}
}

//FIX - use CPU_SET, CPU_CLR, etc...
void Affinity_Init(){
  #if defined(ENABLE_AFFINITY_VIA_NUMA)
    if (numa_available() < 0) {
      fprintf(stderr, "your system does not support NUMA...\n");
    }else{
      NUMA_Heap_Size_in_Bytes = 256*1024*1024; // only 512MB / socket
      printf("implementing NUMA via <numa.h>\n");
      NUMA_Sockets = numa_max_node()+1;

      // Cell Specific
      NUMA_CoresPerNode = spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES,0);

      numa_set_strict(1);
      numa_set_bind_policy(1);

      printf("found %d nodes with %d cores each\n", NUMA_Sockets,NUMA_CoresPerNode);
    }
  #elif defined(ENABLE_AFFINITY_VIA_SCHED)
    printf("implementing NUMA via <sched.h>\n");

    CPU_ZERO(&OriginalMask);
    sched_getaffinity(0, sizeof(OriginalMask), &OriginalMask);
    uint32_t i;
    for(i=0;i<MaxThreads;i++)if(CPU_ISSET(i,&OriginalMask)){
      if(NUMA_Cores<0)NUMA_Cores=0;NUMA_Cores++;
    }

    printf("  found %d cores\n",NUMA_Cores);
    if(NUMA_Cores == 0)exit(0);
    switch(NUMA_Cores){
      case   1: NUMA_LogCores = 0;break;
      case   2: NUMA_LogCores = 1;break;
      case   4: NUMA_LogCores = 2;break;
      case   8: NUMA_LogCores = 3;break;
      case  16: NUMA_LogCores = 4;break;
      case  32: NUMA_LogCores = 5;break;
      case  64: NUMA_LogCores = 6;break;
      case 128: NUMA_LogCores = 7;break;
      case 256: NUMA_LogCores = 8;break;
    }
    printf("  found %d cores\n",NUMA_Cores);

  #elif defined(ENABLE_AFFINITY_VIA_SOLARIS)
    uint32_t i;
    printf("implementing NUMA via <sys/processor.h>\n");
    int NUMA_Cores=0;
    for(i=0;i<MaxThreads;i++)if(processor_bind(P_LWPID, P_MYID, i, NULL)>=0){
      NUMA_Cores++;
    }
                       NUMA_CoresPerNode = NUMA_Cores;  NUMA_Sockets=1;
    if(NUMA_Cores> 64){NUMA_CoresPerNode = NUMA_Cores/2;NUMA_Sockets=2;}
    if(NUMA_Cores>128){NUMA_CoresPerNode = NUMA_Cores/4;NUMA_Sockets=4;}
    printf("Found %d sockets each with %d cores(%d)\n",NUMA_Sockets,NUMA_CoresPerNode,NUMA_Cores);
    processor_bind(P_LWPID, P_MYID, PBIND_NONE, NULL);
  #endif


  // Allocate some large pages for NUMA
  if(MALLOC_VIA_NUMA && (NUMA_Sockets>1)){
    printf("allocating NUMA heap-like structures of size %16ld/2^node bytes\n",NUMA_Heap_Size_in_Bytes);
    int i,j,k;
    for(i=0;i<MaxNodes;i++){
      NUMA_Heap_Start[i]=NULL;
      NUMA_Heap_End[i]=NULL;
      NUMA_Heap_free[i]=NULL;
    }
    uint64_t malloc_size_in_bytes = NUMA_Heap_Size_in_Bytes;
    for(i=1;i<=NUMA_Sockets;i*=2){
      for(j=i/2;j<i;j++){
	Affinity_Bind_Memory(j*NUMA_CoresPerNode);
	NUMA_Heap_Start[j] = (double *)MALLOC(malloc_size_in_bytes);
        NUMA_Heap_End[j]=NUMA_Heap_Start[j]+malloc_size_in_bytes;
        NUMA_Heap_free[j]=(void*)(((uint64_t)NUMA_Heap_Start[j]+NUMA_Heap_Pad_in_Bytes+0x7FF)& ~(0x7FF));
        //NUMA_Heap_free[j]=(void*)(((uint64_t)NUMA_Heap_Start[j]+NUMA_Heap_Pad_in_Bytes+127)& ~(127));
        //printf("allocating %16ld bytes on node %d(core %d)\n",malloc_size_in_bytes,j,j*NUMA_CoresPerNode);
        //printf("%016lx %016lx %016lx\n",NUMA_Heap_Start[j],NUMA_Heap_free[j],NUMA_Heap_End[j]);
        double *ptr = (double*)NUMA_Heap_Start[j];
        for(k=0;k<malloc_size_in_bytes/8;k++)ptr[k]=0.0;
      }
      malloc_size_in_bytes/=2;
    }
    Affinity_unBind();
  }
}

#if defined(ENABLE_AFFINITY_VIA_SCHED)
uint64_t ThreadToMask(uint32_t thread){
  if(NUMA_Cores>0){
    thread = (thread % NUMA_Cores); // FIX ???
    uint64_t mask = 1<<thread; // i.e.  bit 'thread' is set (linear mapping on Opteron)
    #ifdef INTERLEAVED_MULTICORE
      mask = 1<< ( ((thread<<1) | (thread>>(NUMA_LogCores-1))) & (NUMA_Cores-1)); // (twiddled mapping on the clovertown)
    #endif
    return(mask);
  }
  return(OriginalMask);
}
#endif

void Affinity_Bind_Memory(uint32_t thread){
  #if defined(ENABLE_AFFINITY_VIA_NUMA)
    nodemask_zero(&nodemask);
    nodemask_set(&nodemask,(thread/NUMA_CoresPerNode));
    numa_set_membind(&nodemask);
  #elif defined(ENABLE_AFFINITY_VIA_SCHED)
    uint32_t thread2=thread;
             thread2=0;
    cpu_set_t NewMask;
    CPU_ZERO(&NewMask);
    CPU_SET(thread2,&NewMask);
    if(sched_setaffinity(0, sizeof(NewMask), &NewMask)<0){
      printf("Couldn't bind thread=%d to cpu=%d\n",thread,thread2);
      exit(0);
    }
    sched_getaffinity(0, sizeof(NewMask), &NewMask);
  #elif defined(ENABLE_AFFINITY_VIA_SOLARIS)
    if(processor_bind(P_LWPID, P_MYID, thread, NULL)<0){
      printf("Couldn't bind thread %d\n",thread);
      //exit(0);
    }
  #endif
}

void Affinity_Bind_Thread(uint32_t thread){
  #if defined(ENABLE_AFFINITY_VIA_NUMA)
    nodemask_zero(&nodemask);
    nodemask_set(&nodemask,(thread/NUMA_CoresPerNode));
    numa_run_on_node((thread/NUMA_CoresPerNode));
    //numa_bind(&nodemask); // binds both memory and execution
  #elif defined(ENABLE_AFFINITY_VIA_SCHED)
    uint32_t thread2=thread;
    cpu_set_t NewMask;
    CPU_ZERO(&NewMask);
    CPU_SET(thread2,&NewMask);
    if(sched_setaffinity(0, sizeof(NewMask), &NewMask)<0){
      printf("Couldn't bind thread=%d to cpu=%d\n",thread,thread2);
      exit(0);
    }
    sched_getaffinity(0, sizeof(NewMask), &NewMask);
  #elif defined(ENABLE_AFFINITY_VIA_SOLARIS)
    if(processor_bind(P_LWPID, P_MYID, thread, NULL)<0){
      printf("Couldn't bind thread %d\n",thread);
      //exit(0);
    }
  #endif
}

void Affinity_unBind(){ // FIX !! mask too big??
  #if defined(ENABLE_AFFINITY_VIA_NUMA)
    nodemask_zero(&nodemask);
    nodemask_set(&nodemask,0);
    numa_set_membind(&nodemask);
    numa_run_on_node(0);
    //numa_bind(&nodemask);
    //numa_set_membind(&numa_all_nodes);
    //numa_bind(&numa_all_nodes);
  #elif defined(ENABLE_AFFINITY_VIA_SCHED)
    cpu_set_t NewMask;
    CPU_ZERO(&NewMask);
    if(sched_setaffinity(0, sizeof(OriginalMask), &OriginalMask)<0){
      printf("Couldn't unbind threads\n");exit(0);
    }
    sched_getaffinity(0, sizeof(NewMask), &NewMask);
  #elif defined(ENABLE_AFFINITY_VIA_SOLARIS)
    if(processor_bind(P_LWPID, P_MYID, PBIND_NONE, NULL)<0){
       printf("Couldn't unbind thread\n");
       exit(0);
    }
  #endif
}
