void Init_Grid(double *G, int64_t StartX, int64_t EndX, int64_t StartY, int64_t EndY, int64_t StartZ, int64_t EndZ){
  int64_t z,y,x,l;
  /*
  if(StartX==   1)StartX--;
  if(  EndX>=Parameters.XDim)  EndX++;
  if(StartY==   1)StartY--;
  if(  EndY>=Parameters.YDim)  EndY++;
  if(StartZ==   1)StartZ--;
  if(  EndZ>=Parameters.ZDim)  EndZ++;
  */

  //printf("%3lld...%3lld, %3lld...%3lld, %3lld...%3lld\n",StartX,EndX,StartY,EndY,StartZ,EndZ);
  //printf("z=%3lld...%3lld, y=%3lld...%3lld, x=%3lld...%3lld\n",StartZ,EndZ,StartY,EndY,StartX,EndX);
  //fflush(stdout);


  for(z=StartZ;z<EndZ;z++){int64_t zPlaneSize = z*Parameters.PlaneSize;
    for(y=StartY;y<EndY;y++){int64_t yXDimP2 = y*Parameters.PencilSize;
      for(x=StartX;x<EndX;x++){
        int64_t zyx = zPlaneSize + yXDimP2 + x;
        G[zyx]=1.0 + 0.001*((x*y*z)%1000);
  }}}
}
