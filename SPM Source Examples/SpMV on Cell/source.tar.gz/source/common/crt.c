//void CRT_RESET(){char command[20];sprintf(command,"%c[0m",0x1B);printf("%s",command);}
//void CRT_GREEN(){char command[20];sprintf(command,"%c[%d;%d;%dm",0x1B,1,30+2,40+0);printf("%s",command);}
//void CRT_RED()  {char command[20];sprintf(command,"%c[%d;%d;%dm",0x1B,5,30+1,40+0);printf("%s",command);}

char  CRT_DONE[20] = "\033[1;32;40m";
char CRT_ERROR[20] = "\033[5;31;40m";
char CRT_RESET[20] = "\033[0m";

