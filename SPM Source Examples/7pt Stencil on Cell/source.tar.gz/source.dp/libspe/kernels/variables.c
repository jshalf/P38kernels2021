#define    UNROLLINGS 8
void (*Stencil_Plane[16][UNROLLINGS])() = {
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {  &_stencil3_u0,   &_stencil3_u1,   &_stencil3_u2,   &_stencil3_u3,   &_stencil3_u4,   &_stencil3_u5,   &_stencil3_u6,   &_stencil3_u7},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL},
    {           NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL,            NULL}
};
