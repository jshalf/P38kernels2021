eval 'exec perl $0 $*'
        if 0;

$CacheLineSizeBytes = 128;
$CacheLineSizeDoubles = $CacheLineSizeBytes/8;
$RMin=2;
$CMin=1;
$RMax=8;
$CMax=8;

open(H,">configure.h");
print H "//=====================================================================================================\n";
print H "#define MaxThreads             16\n";
print H "\n";
print H "#define PageEntriesAvailable   255\n";
print H "#define PageSizeInDoubles      2000000\n";
print H "\n";
print H "#define MaxStanzaLength        16384\n";
print H "#define MaxStanzas             256\n";
print H "#define CacheLinesAvailable    1600\n";
print H "#define CacheLineSizeInDoubles $CacheLineSizeDoubles\n";
print H "\n";
print H "#define RegBlock_MinR          $RMin\n";
print H "#define RegBlock_MinC          $CMin\n";
print H "#define RegBlock_MaxR          $RMax\n";
print H "#define RegBlock_MaxC          $CMax\n";
print H "\n";
print H "#define PREFETCH_MAX_V         0\n";
print H "#define PREFETCH_MAX_C         0\n";
print H "\n";
print H "#define ENABLE_FORMATS         0x0002 // bit mask for formats\n";
print H "#define ENABLE_16b             1\n";
print H "\n";
print H "//#define ENABLE_AFFINITY_VIA_NUMA\n";
close(H);


open(H,">kernels.coo.h");
open(F,">kernels.coo.c");
for($GlobalR=$RMin;$GlobalR<=$RMax;$GlobalR*=2){
  for($GlobalC=$CMin;$GlobalC<=$CMax;$GlobalC*=2){
      if($GlobalR==1){}
                 else{&COO_2RxC($GlobalR,$GlobalC);}
}}
close(F);
close(H);



open(F,">variables.c");
print F "//==================================================================================================================================\n";
print F "void (*kernels_bfRC[2][2][LOG_RegBlock_MaxR+1][LOG_RegBlock_MaxC+1])(const uint32_t, const double *__restrict__, const uint16_t * __restrict__, const uint16_t * __restrict__, const double *__restrict__, double *) =  // {16:32b}, {BCSR:BCOO}, logR, logC\n";
print F "{ \n";
for($bits=16,$logbits=0;$bits<=32;$bits*=2,$logbits++){
  print F "  { // $bits"."b sub array\n";
  for($f=0;$f<=1;$f++){
    if($f==0){$format="csr";}
    if($f==1){$format="coo";}
    print F "    { // $format sub array\n";
    for($r=1,$logr=0;$r<=8;$r*=2,$logr++){
      print F "      { ";
      for($c=1,$logc=0;$c<=8;$c*=2,$logc++){
           if(($r<$RMin)||($c<$CMin)||($r>$RMax)||($c>$CMax)){printf(F "%20s","NULL");}
        elsif($bits==32){             printf(F "%20s","NULL");}
        elsif($f==0){                 printf(F "%20s","NULL");}
        #elsif($f==0){                 printf(F "%20s","&SpMV_b$r"."x"."$c"."_$format".$bits."b");}
        elsif($f==1){                 printf(F "%20s","&SpMV_b$r"."x"."$c"."_$format".$bits."b");}
        elsif($f> 1){                 printf(F "%20s","NULL");}
        if($c==8){print F "  ";}
             else{print F ", ";}
      }
      if($r==8){print F "} \n";}
           else{print F "},\n";}
    }
    if($f==1){print F "    } \n";}
         else{print F "    },\n";}
  }
  if($bits==32){print F "  } \n";}
           else{print F "  },\n";}
}
print F "};\n";
close(F);



#================================================================================
#
#================================================================================
sub COO_2RxC{
  local($R,$C)=@_;
  if($R==1){print "R=1 not yet supported\n";exit(0);}

  $bits = "16";
  $RC = $R*$C;
  $RC8 = 8*$RC;


  print F "//==================================================================================================================================\n";
  print H "void SpMV_b$R"."x"."$C"."_coo".$bits."b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y);\n";
  print F "void SpMV_b$R"."x"."$C"."_coo".$bits."b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){\n";

  print F "\n";
  print F "  // For each SIMDized row in the tile\n";
  for($r=0;$r<$R;$r+=2){print F "  double * __restrict__ Y".$r." = (double * __restrict__)Y + $r;\n";}
  for($r=0;$r<$RC;$r+=2){print F "  double * __restrict__ V".$r." = (double * __restrict__)V + $r;\n";}
  for($c=0;$c<$C;$c+=2){print F "  double * __restrict__ X".$c." = (double * __restrict__)X + $c;\n";}
  for($r=0;$r<$R;$r+=2){print F "  qword _Z".$r."QW;\n";}
  for($r=0;$r<$R;$r+=2){print F "  qword  Z".$r."QW;\n";}
  for($r=0;$r<$R;$r+=2){print F "  qword  Y".$r."QW;\n";}
  for($r=0;$r<$RC;$r+=2){print F "  qword  V".$r."QW;\n";}
  for($c=0;$c<$C;$c+=2){$cp=$c+1;print F "  qword  X".$c.$cp."QW;\n";}
  if($C>1){for($c=0;$c<$C;$c++ ){print F "  qword  X".$c.$c."QW;\n";}}
  if($C==1){print F "  qword XccQW;\n";}

  print F "\n";
  print F "  qword RotateAmountQW;\n";
  print F "  qword R16QW;\n";
  print F "  qword C16QW;\n";
  print F "  qword R32SplatQW;\n";
  print F "  qword C32SplatQW;\n";
  print F "                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   \n";
  print F "  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};\n";
  print F "  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};\n";
  print F "  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};\n";
  print F "\n";
  print F "  qword XByteOffsetQW;\n";
  print F "  qword XInHighDoubleQW;\n";
  print F "  qword XsplatControlWord;\n";
  print F "\n";
  print F "  qword    YByteOffsetQW;\n";
  #print F "  qword   _YByteOffsetQW = si_shufb(si_from_uint((uint32_t)0xFFFFFFFF),si_from_uint((uint32_t)0xFFFFFFFF),(qword)ReplicateWord0QW);\n";
  print F "  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});\n";
  print F "  qword  __YByteOffsetQW;\n";
  print F "  qword SameRowQW;\n";
  print F "\n";
  print F "  uint32_t RCByteOffset = 0;  // byte offset in R and C\n";
  print F "  uint32_t VByteOffset = 0;   // offset in V\n";
  print F "  uint32_t TilesRemaining = NTiles;\n";
  print F "\n";
$MAXStages = 5;
for($pipeline=0;$pipeline<=$MAXStages;$pipeline++){
if($pipeline>=5){
                                                     print  F "  while(TilesRemaining){//======================================================================================\n";
                                                     print  F "    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
                                                     #print  F "    //     printf("[%12.6e, %12.6e]\n",*((double *)(&Z0QW)),*((double *)(&Z0QW)+1));\n";
                               for($r=0;$r<$R;$r+=2){print  F "                         si_stqx((qword)Z".$r."QW,si_from_ptr((void*)Y$r),__YByteOffsetQW);\n";}
                                                     print  F "\n";
}
if($pipeline>=4){
                                                     print  F "    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
                               for($r=0;$r<$R;$r+=2){print  F "                 _Z".$r."QW = si_selb(Y".$r."QW,Z".$r."QW,SameRowQW);\n";}
             if($C==1){$vofs=0;for($r=0;$r<$R;$r+=2){print  F "                  Z".$r."QW = si_dfma(XccQW,V".$vofs."QW,_Z".$r."QW);\n";$vofs+=2;}}
                  else{$vofs=0;for($r=0;$r<$R;$r+=2){print  F "                  Z".$r."QW = si_dfma(X00QW,V".$vofs."QW,_Z".$r."QW);\n";$vofs+=2;}}
          for($c=1;$c<$C;$c++){for($r=0;$r<$R;$r+=2){print  F "                  Z".$r."QW = si_dfma(X".$c.$c."QW,V".$vofs."QW, Z".$r."QW);\n";$vofs+=2;}}
                                                     print  F "       __YByteOffsetQW = _YByteOffsetQW;\n";
                                                     print  F "\n";
}
if($pipeline>=3){
                                                     print  F "    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
                                           if($C==1){print  F "                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);\n";}
                 else{for($c=0;$c<$C;$c+=2){$cp=$c+1;print  F "                 X".$c .$c ."QW = si_shufb(X".$c.$cp."QW,X".$c.$cp."QW,(qword)ReplicateDouble0QW);\n";
                                                     print  F "                 X".$cp.$cp."QW = si_shufb(X".$c.$cp."QW,X".$c.$cp."QW,(qword)ReplicateDouble1QW);\n";}}
  $vofs=0;for($c=0;$c<$C;$c++){for($r=0;$r<$R;$r+=2){printf F "%22s","V".$vofs."QW";print  F " = si_lqx(si_from_ptr((void*)V".$vofs."),si_from_uint(VByteOffset));\n";$vofs+=2;}}
                                                     print  F "          VByteOffset += $RC8;\n";
                      for($r=0;$r<$R;$r+=2){         print  F "                  Y".$r."QW = si_lqx(si_from_ptr((void*)Y$r),YByteOffsetQW);\n";}
                                                     print  F "             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);\n";
                                                     print  F "        _YByteOffsetQW =  YByteOffsetQW;\n";
                                                     print  F "\n";
}
if($pipeline>=2){
                                                     print  F "    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
                                                     print  F "         XByteOffsetQW = si_shli(C32SplatQW,3);\n";
                                                     print  F "         YByteOffsetQW = si_shli(R32SplatQW,3);\n";
                      for($c=0;$c<$C;$c+=2){$cp=$c+1;print  F "                 X".$c.$cp."QW = si_lqx(si_from_ptr((void*)X".$c."),XByteOffsetQW);\n";}
                                           if($C==1){print  F "     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));\n";}
                                                     print  F "\n";
}
if($pipeline>=1){
                                                     print  F "    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -\n";
                                           if($C==1){print  F "       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);\n";}
                                                     print  F "         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);\n";
                                                     print  F "         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);\n";
                                                     print  F "        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);\n";
                                                     print  F "\n";
}
if($pipeline>=0){
                                                     print  F "    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
                                                     print  F "                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));\n";
                                                     print  F "                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));\n";
                                                     print  F "        RCByteOffset += 2;\n";
                                                     print  F "\n";
}
if($pipeline>=5){
                                                     print  F "    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
                                                     print  F "    TilesRemaining--;\n";
                                                     print  F "  }//===========================================================================================================\n\n";
}
                                                     print  F "\n\n";
} # pipeline
                                                     print  F "}\n";
} # function
