//==================================================================================================================================
void SpMV_b1x1_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x1_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x2_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x2_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x4_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x4_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x8_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x8_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<1*SpA->FirstRow){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }
  Yofs = 1*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d  Y0QW = _mm_load_sd(&(ZRelative[0+Yofs]));                          //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[Cofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[Cofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[Cofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[Cofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[Cofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[Cofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[Cofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[Cofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_sd(&(YRelative[0+Yofs]),Y0QW);                                   //   store vector
        Yofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=1;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_sd(&(YRelative[0+Yofs]),_mm_load_sd(&(ZRelative[0+Yofs])));
      Yofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x1_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x1_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x2_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x2_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x4_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x4_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x8_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x8_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<2*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }
  Yofs = 2*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        Yofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      Yofs+=2;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      Yofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x1_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x1_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x2_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x2_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x4_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x4_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x8_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x8_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<4*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }
  Yofs = 4*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        Yofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      Yofs+=4;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      Yofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x1_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x1_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x2_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x2_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x4_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x4_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x8_csr16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x8_csr32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Yofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<8*SpA->FirstRow){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }
  Yofs = 8*SpA->FirstRow;

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        __m128d Y01QW = _mm_load_pd(&(ZRelative[0+Yofs]));                          //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(ZRelative[2+Yofs]));                          //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(ZRelative[4+Yofs]));                          //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(ZRelative[6+Yofs]));                          //   initialize vector (128b)
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[Cofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[Cofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[Cofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        _mm_store_pd(&(YRelative[0+Yofs]),Y01QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[2+Yofs]),Y23QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[4+Yofs]),Y45QW);                                   //   store vector (128b)
        _mm_store_pd(&(YRelative[6+Yofs]),Y67QW);                                   //   store vector (128b)
        Yofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[2+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[4+Yofs]),ZeroPD);
      _mm_store_pd(&(YRelative[6+Yofs]),ZeroPD);
      Yofs+=8;
    }
    else while(Yofs<SpA->NRows){
      _mm_store_pd(&(YRelative[0+Yofs]),_mm_load_pd(&(ZRelative[0+Yofs])));
      _mm_store_pd(&(YRelative[2+Yofs]),_mm_load_pd(&(ZRelative[2+Yofs])));
      _mm_store_pd(&(YRelative[4+Yofs]),_mm_load_pd(&(ZRelative[4+Yofs])));
      _mm_store_pd(&(YRelative[6+Yofs]),_mm_load_pd(&(ZRelative[6+Yofs])));
      Yofs+=8;
    }
  }

}

//==================================================================================================================================
