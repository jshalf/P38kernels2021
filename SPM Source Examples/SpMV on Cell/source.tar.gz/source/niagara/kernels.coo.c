//==================================================================================================================================
void SpMV_b1x1_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x1_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x2_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x2_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x4_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x4_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x8_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x8_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=1){
      YRelative[row+0]=ZRelative[row+0];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x1_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x1_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x2_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x2_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x4_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x4_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x8_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x8_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=2){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x1_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x1_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x2_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x2_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x4_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x4_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x8_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x8_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=4){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x1_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x1_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x2_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x2_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x4_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x4_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x8_coo16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x8_coo32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=(double)0.0;
      YRelative[row+1]=(double)0.0;
      YRelative[row+2]=(double)0.0;
      YRelative[row+3]=(double)0.0;
      YRelative[row+4]=(double)0.0;
      YRelative[row+5]=(double)0.0;
      YRelative[row+6]=(double)0.0;
      YRelative[row+7]=(double)0.0;
    }
    else for(row=0;row<SpA->NRows;row+=8){
      YRelative[row+0]=ZRelative[row+0];
      YRelative[row+1]=ZRelative[row+1];
      YRelative[row+2]=ZRelative[row+2];
      YRelative[row+3]=ZRelative[row+3];
      YRelative[row+4]=ZRelative[row+4];
      YRelative[row+5]=ZRelative[row+5];
      YRelative[row+6]=ZRelative[row+6];
      YRelative[row+7]=ZRelative[row+7];
    }
  }


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
      while(RCofs<MaxRCofs){                                                       // for all nonzeros{
        uint64_t row = R[RCofs];                                                   // row (64b?)
        double y0=YRelative[0+row];                                              //   initialize vector
        double y1=YRelative[1+row];                                              //   initialize vector
        double y2=YRelative[2+row];                                              //   initialize vector
        double y3=YRelative[3+row];                                              //   initialize vector
        double y4=YRelative[4+row];                                              //   initialize vector
        double y5=YRelative[5+row];                                              //   initialize vector
        double y6=YRelative[6+row];                                              //   initialize vector
        double y7=YRelative[7+row];                                              //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[RCofs]];                               //     load a value of X
          const double X1 = XRelative[1+C[RCofs]];                               //     load a value of X
          const double X2 = XRelative[2+C[RCofs]];                               //     load a value of X
          const double X3 = XRelative[3+C[RCofs]];                               //     load a value of X
          const double X4 = XRelative[4+C[RCofs]];                               //     load a value of X
          const double X5 = XRelative[5+C[RCofs]];                               //     load a value of X
          const double X6 = XRelative[6+C[RCofs]];                               //     load a value of X
          const double X7 = XRelative[7+C[RCofs]];                               //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
        YRelative[0+row]=y0;                                                       //   store vector
        YRelative[1+row]=y1;                                                       //   store vector
        YRelative[2+row]=y2;                                                       //   store vector
        YRelative[3+row]=y3;                                                       //   store vector
        YRelative[4+row]=y4;                                                       //   store vector
        YRelative[5+row]=y5;                                                       //   store vector
        YRelative[6+row]=y6;                                                       //   store vector
        YRelative[7+row]=y7;                                                       //   store vector
      }                                                                            // }
  }
}

//==================================================================================================================================
