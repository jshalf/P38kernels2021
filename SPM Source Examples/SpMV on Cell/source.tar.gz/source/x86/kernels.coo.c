//==================================================================================================================================
void SpMV_b1x1_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x1_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                           Vofs+=1;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x2_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x2_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x4_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x4_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x8_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b1x8_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW;Y0QW = _mm_xor_pd(Y0QW,Y0QW);                                //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d  Y0QW = _mm_load_sd(&(YRelative[0+row]));                            //   initialize vector
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d  X0QW = _mm_load_sd(&(XRelative[0+C[RCofs]]));             //     load a value of X
          const __m128d  X1QW = _mm_load_sd(&(XRelative[1+C[RCofs]]));             //     load a value of X
          const __m128d  X2QW = _mm_load_sd(&(XRelative[2+C[RCofs]]));             //     load a value of X
          const __m128d  X3QW = _mm_load_sd(&(XRelative[3+C[RCofs]]));             //     load a value of X
          const __m128d  X4QW = _mm_load_sd(&(XRelative[4+C[RCofs]]));             //     load a value of X
          const __m128d  X5QW = _mm_load_sd(&(XRelative[5+C[RCofs]]));             //     load a value of X
          const __m128d  X6QW = _mm_load_sd(&(XRelative[6+C[RCofs]]));             //     load a value of X
          const __m128d  X7QW = _mm_load_sd(&(XRelative[7+C[RCofs]]));             //     load a value of X
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                         Y0QW = _mm_add_sd(_mm_mul_sd(X0QW,_mm_load_sd(&(V[0+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X1QW,_mm_load_sd(&(V[1+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X2QW,_mm_load_sd(&(V[2+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X3QW,_mm_load_sd(&(V[3+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X4QW,_mm_load_sd(&(V[4+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X5QW,_mm_load_sd(&(V[5+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X6QW,_mm_load_sd(&(V[6+Vofs]))),Y0QW);
                         Y0QW = _mm_add_sd(_mm_mul_sd(X7QW,_mm_load_sd(&(V[7+Vofs]))),Y0QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_sd(&(YRelative[0+row]),Y0QW);                                    //   store vector
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x1_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x1_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                           Vofs+=2;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x2_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x2_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x4_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x4_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x8_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b2x8_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[2+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[6+Vofs]))),Y01QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[10+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[14+Vofs]))),Y01QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x1_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x1_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                           Vofs+=4;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x2_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x2_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x4_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x4_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x8_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b4x8_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[4+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[6+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[12+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[14+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[20+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[22+Vofs]))),Y23QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[28+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[30+Vofs]))),Y23QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x1_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x1_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                           Vofs+=8;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x2_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x2_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                           Vofs+=16;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x4_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x4_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                           Vofs+=32;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x8_coo16b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint16_t * __restrict__ R = SpA->R16b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
void SpMV_b8x8_coo32b_sse(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const   double * __restrict__ XRelative = X + SpA->COffset;
  const   double * __restrict__ ZRelative = Z + SpA->ROffset;
          double * __restrict__ YRelative = Y + SpA->ROffset;
  const   double * __restrict__ V = SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint32_t * __restrict__ R = SpA->R32b;
  const uint64_t MaxRCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  __m128d ZeroPD;ZeroPD = _mm_xor_pd(ZeroPD,ZeroPD);
  uint64_t RCofs = 0;
  uint64_t Vofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector
    uint64_t row;
    if(Z==NULL)for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),ZeroPD);
      _mm_store_pd(&(YRelative[2+row]),ZeroPD);
      _mm_store_pd(&(YRelative[4+row]),ZeroPD);
      _mm_store_pd(&(YRelative[6+row]),ZeroPD);
    }
    else for(row=0;row<SpA->NRows;row+=8){
      _mm_store_pd(&(YRelative[0+row]),_mm_load_pd(&(ZRelative[0+row])));
      _mm_store_pd(&(YRelative[2+row]),_mm_load_pd(&(ZRelative[2+row])));
      _mm_store_pd(&(YRelative[4+row]),_mm_load_pd(&(ZRelative[4+row])));
      _mm_store_pd(&(YRelative[6+row]),_mm_load_pd(&(ZRelative[6+row])));
    }
  }

  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW;Y01QW = _mm_xor_pd(Y01QW,Y01QW);                                //   initialize vector (128b)
        __m128d Y23QW;Y23QW = _mm_xor_pd(Y23QW,Y23QW);                                //   initialize vector (128b)
        __m128d Y45QW;Y45QW = _mm_xor_pd(Y45QW,Y45QW);                                //   initialize vector (128b)
        __m128d Y67QW;Y67QW = _mm_xor_pd(Y67QW,Y67QW);                                //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
    else{                                                                          // Z=Ax+Y branch
      while(RCofs<MaxRCofs){                                           // for all nonzeros{
        uint64_t row = R[RCofs];                                       // row (64b?)
        __m128d Y01QW = _mm_load_pd(&(YRelative[0+row]));                            //   initialize vector (128b)
        __m128d Y23QW = _mm_load_pd(&(YRelative[2+row]));                            //   initialize vector (128b)
        __m128d Y45QW = _mm_load_pd(&(YRelative[4+row]));                            //   initialize vector (128b)
        __m128d Y67QW = _mm_load_pd(&(YRelative[6+row]));                            //   initialize vector (128b)
        do{                                                                        //   for all nonzeros left in the row
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&R[RCofs]));  //     prefetch column index into L1, don't evict to L2
                                 PREFETCH_NT((void*)(  PREFETCH_C+(uint64_t)&C[RCofs]));  //     prefetch column index into L1, don't evict to L2
          const __m128d X00QW = _mm_load1_pd(&(XRelative[0+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X11QW = _mm_load1_pd(&(XRelative[1+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X22QW = _mm_load1_pd(&(XRelative[2+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X33QW = _mm_load1_pd(&(XRelative[3+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X44QW = _mm_load1_pd(&(XRelative[4+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X55QW = _mm_load1_pd(&(XRelative[5+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X66QW = _mm_load1_pd(&(XRelative[6+C[RCofs]]));             //     load a value of X and replicate
          const __m128d X77QW = _mm_load1_pd(&(XRelative[7+C[RCofs]]));             //     load a value of X and replicate
                                 PREFETCH_NT((void*)(0+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[0+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[2+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[4+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X00QW,_mm_load_pd(&(V[6+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(64+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[8+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[10+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[12+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X11QW,_mm_load_pd(&(V[14+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(128+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[16+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[18+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[20+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X22QW,_mm_load_pd(&(V[22+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(192+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[24+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[26+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[28+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X33QW,_mm_load_pd(&(V[30+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(256+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[32+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[34+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[36+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X44QW,_mm_load_pd(&(V[38+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(320+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[40+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[42+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[44+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X55QW,_mm_load_pd(&(V[46+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(384+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[48+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[50+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[52+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X66QW,_mm_load_pd(&(V[54+Vofs]))),Y67QW);
                                 PREFETCH_NT((void*)(448+PREFETCH_V+(uint64_t)&V[Vofs]));            //     prefetch matrix values into L1, don't evict to L2
                        Y01QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[56+Vofs]))),Y01QW);
                        Y23QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[58+Vofs]))),Y23QW);
                        Y45QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[60+Vofs]))),Y45QW);
                        Y67QW = _mm_add_pd(_mm_mul_pd(X77QW,_mm_load_pd(&(V[62+Vofs]))),Y67QW);
                           Vofs+=64;                                                                 //     increment offset in V
                           RCofs++;                                                                 //     increment offset in R&C
        }while( (row==R[RCofs]) );                                                 //   }
                                 _mm_store_pd(&(YRelative[0+row]),Y01QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[2+row]),Y23QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[4+row]),Y45QW);                                    //   store vector (128b)
                                 _mm_store_pd(&(YRelative[6+row]),Y67QW);                                    //   store vector (128b)
      }}                                                                            // }
  }
}

//==================================================================================================================================
