#if defined(__GNUC__) && defined(__sparc)
inline volatile uint64_t CycleTime(){
  volatile uint64_t ret;
  __asm__ volatile("rd %%tick, %0" : "=r" (ret));
  return ret;
}
#elif defined(__SUNPRO_C) && defined (__sparcv9)
extern uint64_t CycleTime();
#endif
