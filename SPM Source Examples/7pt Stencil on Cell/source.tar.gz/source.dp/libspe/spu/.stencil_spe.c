#include <spu_mfcio.h>
#include <stdio.h>
#include <stdio.h>
#include <stdint.h>
//==============================================================================================================================
#define DMATag_Buf0         0
#define DMATag_Buf1         1
#define DMATag_parameters   2
#define DMATag_args         3
//==============================================================================================================================
const vector unsigned char ABCD_to_BC_ControlWord    = {0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F, 0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17};
//==============================================================================================================================
#define CacheLineSizeInBytes   128
#define CacheLineSizeInDoubles  16
#define CacheLineSizeInQWords    8
#define CacheLinesAvailable 1500
#define _CACHE_ALIGNMENT __attribute__ ((aligned(128)))
//==============================================================================================================================
#include "../../common/types.h"
#include "../kernels/kernels.h"
//==============================================================================================================================
#include "../../common/variables.c"
#include "../include/misc.c"
volatile               uint32_t MyLock[32]                                   __attribute__ ((aligned(128)));
volatile            uint64_t pthread_args[32]                                __attribute__ ((aligned(128)));
volatile    DMAListElement_t ReadList[2][128]                                __attribute__ ((aligned(128)));
volatile    DMAListElement_t WriteList[2][128]                               __attribute__ ((aligned(128)));

volatile double *  ReadZp2;
volatile double *  ReadZp1;
volatile double *  ReadZp0;
volatile double *  ReadZm1;
volatile double * WriteZp0;
volatile double * WriteZm1;

uint32_t DRAM_parameters;
uint32_t DRAM_G0;
uint32_t DRAM_G1;
uint32_t DRAM_ReadG;  // DRAM address of leading plane of current cache block of the read grid (-pencil-1 round down)
uint32_t DRAM_WriteG; // DRAM address of trailing plane of current cache block of the write grid (better be aligned)
uint32_t rank;
 int32_t StartX,EndX;
 int32_t StartY,EndY;
 int32_t StartZ,EndZ;
 int32_t maxCBYDim;
 int32_t chosenCBYDim;

vector double AlphaQW;
vector double  BetaQW;
vector double GammaQW;
vector double DeltaQW;

uint32_t Offset_0Rows_0Qwords,Offset_0Rows_1Qwords,Offset_0Rows_2Qwords,Offset_0Rows_3Qwords;
uint32_t Offset_1Rows_0Qwords,Offset_1Rows_1Qwords,Offset_1Rows_2Qwords,Offset_1Rows_3Qwords;
uint32_t Offset_2Rows_0Qwords,Offset_2Rows_1Qwords,Offset_2Rows_2Qwords,Offset_2Rows_3Qwords;
uint32_t Offset_3Rows_0Qwords,Offset_3Rows_1Qwords,Offset_3Rows_2Qwords,Offset_3Rows_3Qwords;
uint32_t Offset_4Rows_0Qwords,Offset_4Rows_1Qwords,Offset_4Rows_2Qwords,Offset_4Rows_3Qwords;
uint32_t Offset_5Rows_0Qwords,Offset_5Rows_1Qwords,Offset_5Rows_2Qwords,Offset_5Rows_3Qwords;
uint32_t Offset_6Rows_0Qwords,Offset_6Rows_1Qwords,Offset_6Rows_2Qwords,Offset_6Rows_3Qwords;
uint32_t Offset_7Rows_0Qwords,Offset_7Rows_1Qwords,Offset_7Rows_2Qwords,Offset_7Rows_3Qwords;
uint32_t Offset_8Rows_0Qwords,Offset_8Rows_1Qwords,Offset_8Rows_2Qwords,Offset_8Rows_3Qwords;
uint32_t Offset_9Rows_0Qwords,Offset_9Rows_1Qwords,Offset_9Rows_2Qwords,Offset_9Rows_3Qwords;
//==============================================================================================================================
volatile               qword Heap[CacheLineSizeInQWords*CacheLinesAvailable] __attribute__ ((aligned(128)));
//==============================================================================================================================
inline uint32_t AppendDMAList(DMAListElement_t *List, uint32_t EAL, uint32_t size){
  uint32_t stanzas = 0;
  while(size>16384){List[stanzas].Size = 16384;List[stanzas].EAL = EAL;stanzas++;size-=16384;EAL+=16384;}
                    List[stanzas].Size =  size;List[stanzas].EAL = EAL;stanzas++;
  return(stanzas);
}

inline void barrier(){
        MyLock[0] =1;
  while(MyLock[0]==1);
}

//==============================================================================================================================
#include "../kernels/variables.c"
#include "../kernels/kernels.c"
//==============================================================================================================================
void Stencil_CacheBlock(int32_t y){
  int32_t LoadZ    = StartZ-1; // DMA in flight
  int32_t ComputeZ = StartZ-3;
  int32_t StoreZ   = StartZ-4; // DMA in flight

  uint32_t IncrementBytes = Parameters.PlaneSize*sizeof(double);
  uint32_t  DRAM_LoadZ = DRAM_G0 + (( LoadZ*Parameters.PlaneSize + (y-1)*Parameters.PencilSize + 1)*sizeof(double)) - CacheLineSizeInBytes; // for previous ghost zone padding
  uint32_t DRAM_StoreZ = DRAM_G1 + ((StoreZ*Parameters.PlaneSize + (y  )*Parameters.PencilSize + 1)*sizeof(double));
  uint32_t   LoadBytes = (((chosenCBYDim+2)*Parameters.PencilSize)*sizeof(double)) + CacheLineSizeInBytes;
  uint32_t  StoreBytes = (((chosenCBYDim  )*Parameters.PencilSize)*sizeof(double));
  //printf("SPE:%02d: LoadPadding=%5d\n",rank,LoadPadding);
  //if(rank==0){
  //  printf("DRAM_StoreZ=%08x\n", DRAM_StoreZ);
  //  printf(" DRAM_LoadZ=%08x\n",  DRAM_LoadZ);
  //}

  // for all planes in a cache block
  uint32_t buf=0;
  while(StoreZ < EndZ){
    //printf("SPE:%02d: y=%3d, LoadZ=%3d, ComputeZ=%3d, StoreZ=%3d, EndZ=%3d \n",rank,y,LoadZ,ComputeZ,StoreZ,EndZ);
    //printf("SPE:%02d: DRAM_LoadZ=%08x(%5d), DRAM_StoreZ=%08x(%5d)\n",rank,DRAM_LoadZ,LoadBytes,DRAM_StoreZ,StoreBytes);
    mfc_write_tag_mask(1<<(buf^1));mfc_read_tag_status_all(); // wait for previous DMA's
    if( (   LoadZ>=(StartZ-1)) && ( LoadZ<(EndZ+1)) ){ // initiate DMA get
      uint32_t  ReadStanzas = AppendDMAList( (DMAListElement_t*)ReadList[buf^1], DRAM_LoadZ, LoadBytes);
      //spu_mfcdma32( (void*)&ReadZp2[0], (uint32_t)&ReadList[buf^1][0], ReadStanzas<<3,buf^1,MFC_GETL_CMD);
    }
    if( (  StoreZ>=(StartZ  )) && (StoreZ<(EndZ  )) ){ // initiate DMA put
      uint32_t WriteStanzas = AppendDMAList((DMAListElement_t*)WriteList[buf^1],DRAM_StoreZ,StoreBytes);
      spu_mfcdma32((void*)&WriteZm1[0],(uint32_t)&WriteList[buf^1][0],WriteStanzas<<3,buf^1,MFC_PUTL_CMD);
    }

    if( (ComputeZ>=(StartZ  )) && (StoreZ<(EndZ  )) ){ // compute on planes
      Stencil_Plane[3][chosenCBYDim & (UNROLLINGS-1)]();
      // FIX - fix up ghost zones
    }


    // increment Z's
    LoadZ++;
    ComputeZ++;
    StoreZ++;

    // increment DRAM addresses
    DRAM_LoadZ  += IncrementBytes;
    DRAM_StoreZ += IncrementBytes;


    // rotate pointers
    volatile double *temp;
    temp = ReadZm1;
    ReadZm1 = ReadZp0;
    ReadZp0 = ReadZp1;
    ReadZp1 = ReadZp2;
    ReadZp2 = temp;

    temp = WriteZm1;
    WriteZm1 = WriteZp0;
    WriteZp0 = temp;

    // toggle buffers
    buf^=1;
  }
  mfc_write_tag_mask(0x3);mfc_read_tag_status_all(); // wait for last store
}

void Stencil_Full3D(){
  int32_t y;
  // for all cache blocks in my grid
  for(y=StartY;y<EndY;y+=maxCBYDim){
    chosenCBYDim = min(EndY-y,maxCBYDim);
    //printf("SPE:%02d: y=%3d, chosenCBYDim=%3d\n",rank,y,chosenCBYDim);
    Stencil_CacheBlock(y);
  }
}
//==============================================================================================================================
int main(uint64_t spuid __attribute__ ((__unused__)), uint64_t argp, uint64_t envp __attribute__ ((__unused__))) {
  uint32_t i,tBarrier,tStart,tSpMV,minTime=0xFFFFFFFF;
  for(i=0;i<32;i++)MyLock[i]=0;
  spu_write_out_mbox((uint32_t)&MyLock[0]);
  //printf("Hello, I'm an SPE - argp=%016llx\n",argp);

  // Get Argument list (@argp) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  spu_mfcdma32(&pthread_args[0],argp,256,DMATag_args,MFC_GET_CMD);
  mfc_write_tag_mask(1<<DMATag_args);
  mfc_read_tag_status_all();
  DRAM_G0                  = pthread_args[ 0];
  DRAM_G1                  = pthread_args[ 1];
  DRAM_parameters          = pthread_args[ 2];
  rank                     = pthread_args[31];
  if(rank==0)printf("SPE:%02d: %08x->%08x\n",rank,DRAM_parameters, (uint32_t)&Parameters);

  // Get Parameters - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  spu_mfcdma32(&Parameters,DRAM_parameters,roundTo(sizeof(Parameters),7),DMATag_parameters,MFC_GET_CMD);
  mfc_write_tag_mask(1<<DMATag_parameters);
  mfc_read_tag_status_all();

  // Calculate Thread Specific Ranges - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  StartX = 1+((rank                    )%Parameters.XThreads)*Parameters.XDimPerThread;EndX = StartX+Parameters.XDimPerThread;
  StartY = 1+((rank/Parameters.XThreads)%Parameters.YThreads)*Parameters.YDimPerThread;EndY = StartY+Parameters.YDimPerThread;
  StartZ = 1+((rank/Parameters.XThreads)/Parameters.YThreads)*Parameters.ZDimPerThread;EndZ = StartZ+Parameters.ZDimPerThread;
  //printf("SPE:%02d: %3d..%3d, %3d..%3d, %3d..%3d\n",rank,StartX,EndX,StartY,EndY,StartZ,EndZ);
  AlphaQW = *((vector double*)Parameters.Alpha);
   BetaQW = *((vector double*) Parameters.Beta);
  DeltaQW = *((vector double*)Parameters.Delta);
  GammaQW = *((vector double*)Parameters.Gamma);

  // Calculate the max cache block size - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  uint32_t  ReadPlaneSizeInBytes;
  uint32_t WritePlaneSizeInBytes;
  uint32_t y;
  maxCBYDim = 0;
  uint32_t minCBs = 1000;
  //for(y=1;y<=Parameters.YDimPerThread;y++){
  for(y=1;y<=Parameters.YDimPerThread;y++){
     ReadPlaneSizeInBytes = sizeof(double)*Parameters.PencilSize*(y+2) + CacheLineSizeInBytes;
    WritePlaneSizeInBytes = sizeof(double)*Parameters.PencilSize*(y  );
    if((4*ReadPlaneSizeInBytes+2*WritePlaneSizeInBytes)<=CacheLineSizeInBytes*CacheLinesAvailable){
      if(((Parameters.YDimPerThread+y-1)/y)<minCBs){
        minCBs = (Parameters.YDimPerThread+y-1)/y;
        maxCBYDim=y;
    }}
  }
   ReadPlaneSizeInBytes = sizeof(double)*Parameters.PencilSize*(maxCBYDim+2) + CacheLineSizeInBytes;
  WritePlaneSizeInBytes = sizeof(double)*Parameters.PencilSize*(maxCBYDim  );
  if(maxCBYDim<1){if(rank==0)printf("problem cannot fit in the LS without blocking in X\n");exit(0);}
  if(rank==0)printf("SPE:%02d: maxCBYDim=%3d, ReadPlaneSizeInBytes=%5d, WritePlaneSizeInBytes=%5d\n",rank,maxCBYDim,ReadPlaneSizeInBytes,WritePlaneSizeInBytes);

  double *temp = (double*)&Heap[0];
   ReadZp2 = temp;temp+=( ReadPlaneSizeInBytes>>3);
   ReadZp1 = temp;temp+=( ReadPlaneSizeInBytes>>3);
   ReadZp0 = temp;temp+=( ReadPlaneSizeInBytes>>3);
   ReadZm1 = temp;temp+=( ReadPlaneSizeInBytes>>3);
  WriteZp0 = temp;temp+=(WritePlaneSizeInBytes>>3);
  WriteZm1 = temp;temp+=(WritePlaneSizeInBytes>>3);

  if(rank==0){
    printf(" ReadZp2 = %08x\n", ReadZp2);
    printf(" ReadZp1 = %08x\n", ReadZp1);
    printf(" ReadZp0 = %08x\n", ReadZp0);
    printf(" ReadZm1 = %08x\n", ReadZm1);
    printf("WriteZp0 = %08x\n",WriteZp0);
    printf("WriteZm1 = %08x\n",WriteZm1);
  }

  // offsets - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Offset_0Rows_0Qwords = 0*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_0Rows_1Qwords = 0*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_0Rows_2Qwords = 0*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_0Rows_3Qwords = 0*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_1Rows_0Qwords = 1*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_1Rows_1Qwords = 1*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_1Rows_2Qwords = 1*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_1Rows_3Qwords = 1*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_2Rows_0Qwords = 2*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_2Rows_1Qwords = 2*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_2Rows_2Qwords = 2*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_2Rows_3Qwords = 2*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_3Rows_0Qwords = 3*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_3Rows_1Qwords = 3*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_3Rows_2Qwords = 3*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_3Rows_3Qwords = 3*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_4Rows_0Qwords = 4*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_4Rows_1Qwords = 4*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_4Rows_2Qwords = 4*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_4Rows_3Qwords = 4*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_5Rows_0Qwords = 5*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_5Rows_1Qwords = 5*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_5Rows_2Qwords = 5*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_5Rows_3Qwords = 5*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_6Rows_0Qwords = 6*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_6Rows_1Qwords = 6*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_6Rows_2Qwords = 6*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_6Rows_3Qwords = 6*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_7Rows_0Qwords = 7*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_7Rows_1Qwords = 7*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_7Rows_2Qwords = 7*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_7Rows_3Qwords = 7*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_8Rows_0Qwords = 8*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_8Rows_1Qwords = 8*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_8Rows_2Qwords = 8*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_8Rows_3Qwords = 8*((Parameters.PencilSize)*sizeof(double)) + 48;

  Offset_9Rows_0Qwords = 9*((Parameters.PencilSize)*sizeof(double)) +  0;
  Offset_9Rows_1Qwords = 9*((Parameters.PencilSize)*sizeof(double)) + 16;
  Offset_9Rows_2Qwords = 9*((Parameters.PencilSize)*sizeof(double)) + 32;
  Offset_9Rows_3Qwords = 9*((Parameters.PencilSize)*sizeof(double)) + 48;

  // Run Stencil trials - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(i=0;i<maxTrials;i++){
    //if(rank==0){printf("new trial\n");}
    spu_writech(SPU_WrDec,0x7FFFFFFF);
    tStart=spu_readch(SPU_RdDec); // start timer
    barrier();
    Stencil_Full3D();
    tSpMV=tStart-spu_readch(SPU_RdDec); // stop timer
    barrier();
    tBarrier=spu_readch(SPU_RdDec); // stop timer
    if((tStart-tBarrier)<minTime){minTime=tStart-tBarrier;}
    //calculate things, swap pointers, etc...
    uint32_t DRAM_temp=DRAM_G0;DRAM_G0=DRAM_G1;DRAM_G1=DRAM_temp;
  }
  // Report back timings- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  //if(MyRank==0)printf("MinTime = %d cycles, GFlop/s=%0.3f(%0.3f)\n",minTime,0.0800f*2.0f*BlockedSpA.ActualNonZeros/(minTime),0.0143f*2.0f*BlockedSpA.ActualNonZeros/(minTime));
  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  return(0);
}
