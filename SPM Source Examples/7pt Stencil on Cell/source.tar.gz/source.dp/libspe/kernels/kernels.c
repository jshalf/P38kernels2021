//====================================================================
void _stencil3_u0(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
}
//====================================================================
void _stencil3_u1(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
}
//====================================================================
void _stencil3_u2(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
}
//====================================================================
void _stencil3_u3(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
}
//====================================================================
void _stencil3_u4(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
}
//====================================================================
void _stencil3_u5(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
}
//====================================================================
void _stencil3_u6(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
}
//====================================================================
void _stencil3_u7(){
  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  //     0 1 2 3 4 5  
  //         _ _      
  // 0   _ _|_:_|_ _  
  // 1  |_:_|_:_|_:_| 
  // 2  |_:_|_:_|_:_| 
  // 3  |_:_|_:_|_:_| 
  // 4  |_:_|_:_|_:_| 
  // 5  |_:_|_:_|_:_| 
  // 6  |_:_|_:_|_:_| 
  // 7  |_:_|_:_|_:_| 
  // 8  |_:_|_:_|_:_| 
  // 9      |_:_|     
  // z=0,1,2          
  // t=  curr,next          
  qword                    curr_z0_y1_x23_QW;
  qword                    curr_z0_y2_x23_QW;
  qword                    curr_z0_y3_x23_QW;
  qword                    curr_z0_y4_x23_QW;
  qword                    curr_z0_y5_x23_QW;
  qword                    curr_z0_y6_x23_QW;
  qword                    curr_z0_y7_x23_QW;
  qword                    curr_z0_y8_x23_QW;

  qword                    curr_z1_y0_x23_QW;
  qword curr_z1_y1_x01_QW, curr_z1_y1_x23_QW, curr_z1_y1_x45_QW;
  qword curr_z1_y2_x01_QW, curr_z1_y2_x23_QW, curr_z1_y2_x45_QW;
  qword curr_z1_y3_x01_QW, curr_z1_y3_x23_QW, curr_z1_y3_x45_QW;
  qword curr_z1_y4_x01_QW, curr_z1_y4_x23_QW, curr_z1_y4_x45_QW;
  qword curr_z1_y5_x01_QW, curr_z1_y5_x23_QW, curr_z1_y5_x45_QW;
  qword curr_z1_y6_x01_QW, curr_z1_y6_x23_QW, curr_z1_y6_x45_QW;
  qword curr_z1_y7_x01_QW, curr_z1_y7_x23_QW, curr_z1_y7_x45_QW;
  qword curr_z1_y8_x01_QW, curr_z1_y8_x23_QW, curr_z1_y8_x45_QW;
  qword                    curr_z1_y9_x23_QW;

  qword                    curr_z2_y1_x23_QW;
  qword                    curr_z2_y2_x23_QW;
  qword                    curr_z2_y3_x23_QW;
  qword                    curr_z2_y4_x23_QW;
  qword                    curr_z2_y5_x23_QW;
  qword                    curr_z2_y6_x23_QW;
  qword                    curr_z2_y7_x23_QW;
  qword                    curr_z2_y8_x23_QW;

  qword curr_z1_y1_x12_QW, curr_z1_y1_x34_QW;
  qword curr_z1_y2_x12_QW, curr_z1_y2_x34_QW;
  qword curr_z1_y3_x12_QW, curr_z1_y3_x34_QW;
  qword curr_z1_y4_x12_QW, curr_z1_y4_x34_QW;
  qword curr_z1_y5_x12_QW, curr_z1_y5_x34_QW;
  qword curr_z1_y6_x12_QW, curr_z1_y6_x34_QW;
  qword curr_z1_y7_x12_QW, curr_z1_y7_x34_QW;
  qword curr_z1_y8_x12_QW, curr_z1_y8_x34_QW;

  qword next_z1_y1_x23_QW;
  qword next_z1_y2_x23_QW;
  qword next_z1_y3_x23_QW;
  qword next_z1_y4_x23_QW;
  qword next_z1_y5_x23_QW;
  qword next_z1_y6_x23_QW;
  qword next_z1_y7_x23_QW;
  qword next_z1_y8_x23_QW;

  uint32_t curr_z0_y0_x00_ByteAddress;
  uint32_t curr_z1_y0_x00_ByteAddress;
  uint32_t curr_z2_y0_x00_ByteAddress;
  uint32_t next_z1_y0_x00_ByteAddress;
  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);

  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~(8-1);
  uint32_t x,y;
  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(y=0;y<floorCBYDim;y+=8){
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y8_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_0Qwords)); // really _x01
    curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords)); // really _x23
    curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x01_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = curr_z1_y8_x45_QW;
      curr_z1_y8_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_2Qwords));
      curr_z1_y9_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_9Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z0_y8_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));
      curr_z2_y8_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y8_x12_QW = curr_z1_y8_x34_QW;
      curr_z1_y8_x34_QW = si_shufb(curr_z1_y8_x23_QW,curr_z1_y8_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));

      next_z1_y8_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y8_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y8_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y9_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y8_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      si_stqx(next_z1_y8_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
  }
  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;
    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;
    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;
    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;
    curr_z1_y1_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_0Qwords)); // really _x01
    curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords)); // really _x23
    curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x01_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y2_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_0Qwords)); // really _x01
    curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords)); // really _x23
    curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x01_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y3_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_0Qwords)); // really _x01
    curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords)); // really _x23
    curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x01_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y4_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_0Qwords)); // really _x01
    curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords)); // really _x23
    curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x01_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y5_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_0Qwords)); // really _x01
    curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords)); // really _x23
    curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x01_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y6_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_0Qwords)); // really _x01
    curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords)); // really _x23
    curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x01_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12
    curr_z1_y7_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_0Qwords)); // really _x01
    curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords)); // really _x23
    curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x01_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12

    for(x=0;x<Parameters.XDimPerBlock;x+=2){
      curr_z1_y0_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      curr_z1_y1_x23_QW = curr_z1_y1_x45_QW;
      curr_z1_y1_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_2Qwords));
      curr_z1_y2_x23_QW = curr_z1_y2_x45_QW;
      curr_z1_y2_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_2Qwords));
      curr_z1_y3_x23_QW = curr_z1_y3_x45_QW;
      curr_z1_y3_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_2Qwords));
      curr_z1_y4_x23_QW = curr_z1_y4_x45_QW;
      curr_z1_y4_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_2Qwords));
      curr_z1_y5_x23_QW = curr_z1_y5_x45_QW;
      curr_z1_y5_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_2Qwords));
      curr_z1_y6_x23_QW = curr_z1_y6_x45_QW;
      curr_z1_y6_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_2Qwords));
      curr_z1_y7_x23_QW = curr_z1_y7_x45_QW;
      curr_z1_y7_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_2Qwords));
      curr_z1_y8_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_8Rows_1Qwords));

      curr_z0_y1_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z2_y1_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      curr_z0_y2_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z2_y2_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      curr_z0_y3_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z2_y3_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      curr_z0_y4_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z2_y4_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      curr_z0_y5_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z2_y5_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      curr_z0_y6_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z2_y6_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));
      curr_z0_y7_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));
      curr_z2_y7_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_7Rows_1Qwords));

      curr_z1_y1_x12_QW = curr_z1_y1_x34_QW;
      curr_z1_y1_x34_QW = si_shufb(curr_z1_y1_x23_QW,curr_z1_y1_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y2_x12_QW = curr_z1_y2_x34_QW;
      curr_z1_y2_x34_QW = si_shufb(curr_z1_y2_x23_QW,curr_z1_y2_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y3_x12_QW = curr_z1_y3_x34_QW;
      curr_z1_y3_x34_QW = si_shufb(curr_z1_y3_x23_QW,curr_z1_y3_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y4_x12_QW = curr_z1_y4_x34_QW;
      curr_z1_y4_x34_QW = si_shufb(curr_z1_y4_x23_QW,curr_z1_y4_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y5_x12_QW = curr_z1_y5_x34_QW;
      curr_z1_y5_x34_QW = si_shufb(curr_z1_y5_x23_QW,curr_z1_y5_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y6_x12_QW = curr_z1_y6_x34_QW;
      curr_z1_y6_x34_QW = si_shufb(curr_z1_y6_x23_QW,curr_z1_y6_x45_QW,(qword)ABCD_to_BC_ControlWord);
      curr_z1_y7_x12_QW = curr_z1_y7_x34_QW;
      curr_z1_y7_x34_QW = si_shufb(curr_z1_y7_x23_QW,curr_z1_y7_x45_QW,(qword)ABCD_to_BC_ControlWord);

      next_z1_y1_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y1_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y1_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y0_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y1_x23_QW)))))));

      next_z1_y2_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y2_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y2_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y1_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y2_x23_QW)))))));

      next_z1_y3_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y3_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y3_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y2_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y3_x23_QW)))))));

      next_z1_y4_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y4_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y4_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y3_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y4_x23_QW)))))));

      next_z1_y5_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y5_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y5_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y4_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y5_x23_QW)))))));

      next_z1_y6_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y6_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y6_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y5_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y6_x23_QW)))))));

      next_z1_y7_x23_QW = 
                          si_dfma((qword) BetaQW,curr_z2_y7_x23_QW, /* z+1 */ 
                          si_dfma((qword) BetaQW,curr_z0_y7_x23_QW, /* z-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y8_x23_QW, /* y+1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y6_x23_QW, /* y-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x34_QW, /* x-1 */ 
                          si_dfma((qword) BetaQW,curr_z1_y7_x12_QW, /* x+1 */ 
                           si_dfm((qword)AlphaQW,curr_z1_y7_x23_QW)))))));


      si_stqx(next_z1_y1_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_0Rows_1Qwords));
      si_stqx(next_z1_y2_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_1Rows_1Qwords));
      si_stqx(next_z1_y3_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_2Rows_1Qwords));
      si_stqx(next_z1_y4_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_3Rows_1Qwords));
      si_stqx(next_z1_y5_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_4Rows_1Qwords));
      si_stqx(next_z1_y6_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_5Rows_1Qwords));
      si_stqx(next_z1_y7_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_6Rows_1Qwords));

      curr_z0_y0_x00_ByteAddress += 16;
      curr_z1_y0_x00_ByteAddress += 16;
      curr_z2_y0_x00_ByteAddress += 16;
      next_z1_y0_x00_ByteAddress += 16;
    }
    YOffset += DeltaYOffset;
}
