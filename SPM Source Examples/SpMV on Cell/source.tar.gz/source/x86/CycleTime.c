//======================================================================================================================================
#ifdef __x86_64__
  inline uint64_t CycleTime(){
    uint64_t lo, hi;
    asm volatile("rdtsc" : "=a" (lo), "=d" (hi));
    return( (((uint64_t)hi) << 32) | ((uint64_t)lo) );
  }
#else
  inline unsigned long long int CycleTime(){
    unsigned long long int x;
    __asm__ volatile (".byte 0x0f, 0x31" : "=A" (x));
    return x;
  }
#endif
