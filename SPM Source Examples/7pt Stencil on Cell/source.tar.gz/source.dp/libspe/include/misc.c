#define roundTo(a,bits) ((((a)+(1<<(bits))-1)>>(bits))<<(bits))
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)>(b)?(b):(a))

uint32_t CheckFitsInLocalStore(){
  uint32_t LSCapacityRequired = 0;
  uint32_t LocalPencilSize = Parameters.PencilSize;
    LSCapacityRequired += 2*sizeof(double)*(Parameters.XDimPerBlock)*Parameters.YDimPerBlock; // output buffers
  if(Parameters.XBlocks!=1){
    LSCapacityRequired += 4*sizeof(double)*((Parameters.XDimPerBlock+2*CacheLineSizeInDoubles)*(Parameters.YDimPerBlock+2)); // 3 planes + buffer
  }else{
    LSCapacityRequired += 4*sizeof(double)*((Parameters.XDimPerBlock+1*CacheLineSizeInDoubles)*(Parameters.YDimPerBlock+2) + CacheLineSizeInDoubles); // 3 planes + buffer
  }

  if(LSCapacityRequired > CacheLinesAvailable*CacheLineSizeInBytes){
    printf("LSCapacityRequired(%6d) > LSCapacityAvailable(%6d)\n",LSCapacityRequired,CacheLinesAvailable*CacheLineSizeInBytes);
    exit(0);
  }
}
