//======================================================================================================================================
#ifdef __x86_64__
  inline uint64_t CycleTime(){
    uint64_t lo, hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return( (((uint64_t)hi) << 32) | ((uint64_t)lo) );
  }
#else
  inline unsigned long long int CycleTime(){ // 32b mode returning 64b data?
    unsigned long long int x;
    __asm__ __volatile__ (".byte 0x0f, 0x31" : "=A" (x));
    return x;
  }
#endif
