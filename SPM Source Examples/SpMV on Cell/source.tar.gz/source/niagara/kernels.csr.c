//==================================================================================================================================
void SpMV_b1x1_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x1_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          Vofs+=1;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x2_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x2_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x4_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x4_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x8_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b1x8_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<1*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }
  Rofs = 1*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y0 += V[1+Vofs]*X1;                                                      //
          y0 += V[2+Vofs]*X2;                                                      //
          y0 += V[3+Vofs]*X3;                                                      //
          y0 += V[4+Vofs]*X4;                                                      //
          y0 += V[5+Vofs]*X5;                                                      //
          y0 += V[6+Vofs]*X6;                                                      //
          y0 += V[7+Vofs]*X7;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        Rofs+=1;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      Rofs+=1;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      Rofs+=1;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x1_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x1_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          Vofs+=2;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x2_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x2_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x4_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x4_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x8_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b2x8_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<2*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }
  Rofs = 2*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y0 += V[2+Vofs]*X1;                                                      //
          y1 += V[3+Vofs]*X1;                                                      //
          y0 += V[4+Vofs]*X2;                                                      //
          y1 += V[5+Vofs]*X2;                                                      //
          y0 += V[6+Vofs]*X3;                                                      //
          y1 += V[7+Vofs]*X3;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X4;                                                      //
          y1 += V[9+Vofs]*X4;                                                      //
          y0 += V[10+Vofs]*X5;                                                      //
          y1 += V[11+Vofs]*X5;                                                      //
          y0 += V[12+Vofs]*X6;                                                      //
          y1 += V[13+Vofs]*X6;                                                      //
          y0 += V[14+Vofs]*X7;                                                      //
          y1 += V[15+Vofs]*X7;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        Rofs+=2;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      Rofs+=2;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      Rofs+=2;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x1_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x1_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          Vofs+=4;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x2_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x2_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x4_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x4_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x8_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b4x8_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<4*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }
  Rofs = 4*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y0 += V[4+Vofs]*X1;                                                      //
          y1 += V[5+Vofs]*X1;                                                      //
          y2 += V[6+Vofs]*X1;                                                      //
          y3 += V[7+Vofs]*X1;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X2;                                                      //
          y1 += V[9+Vofs]*X2;                                                      //
          y2 += V[10+Vofs]*X2;                                                      //
          y3 += V[11+Vofs]*X2;                                                      //
          y0 += V[12+Vofs]*X3;                                                      //
          y1 += V[13+Vofs]*X3;                                                      //
          y2 += V[14+Vofs]*X3;                                                      //
          y3 += V[15+Vofs]*X3;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X4;                                                      //
          y1 += V[17+Vofs]*X4;                                                      //
          y2 += V[18+Vofs]*X4;                                                      //
          y3 += V[19+Vofs]*X4;                                                      //
          y0 += V[20+Vofs]*X5;                                                      //
          y1 += V[21+Vofs]*X5;                                                      //
          y2 += V[22+Vofs]*X5;                                                      //
          y3 += V[23+Vofs]*X5;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X6;                                                      //
          y1 += V[25+Vofs]*X6;                                                      //
          y2 += V[26+Vofs]*X6;                                                      //
          y3 += V[27+Vofs]*X6;                                                      //
          y0 += V[28+Vofs]*X7;                                                      //
          y1 += V[29+Vofs]*X7;                                                      //
          y2 += V[30+Vofs]*X7;                                                      //
          y3 += V[31+Vofs]*X7;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        Rofs+=4;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      Rofs+=4;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      Rofs+=4;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x1_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x1_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          Vofs+=8;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x2_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x2_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          Vofs+=16;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x4_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x4_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          Vofs+=32;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x8_csr16b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint16_t * __restrict__ C = SpA->C16b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
void SpMV_b8x8_csr32b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){
  const double * __restrict__ XRelative = (double *)X + SpA->COffset;
  const double * __restrict__ ZRelative = (double *)Z + SpA->ROffset;
        double * __restrict__ YRelative = (double *)Y + SpA->ROffset;
  const uint32_t * __restrict__ P = SpA->P;
  const double * __restrict__ V = (double *)SpA->V;
  const uint32_t * __restrict__ C = SpA->C32b;
  const uint64_t MaxCofs = SpA->NTiles;
  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;
  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;
  uint64_t row = SpA->FirstRow;
  uint64_t Cofs = 0;
  uint64_t Vofs = 0;
  uint64_t Rofs = 0;

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<8*SpA->FirstRow){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }
  Rofs = 8*SpA->FirstRow;


  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }
  else {                                                                                     // PREFETCH_CV
    if(Z==NULL){                                                                   // Z=Ax branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0= (double)0.0;                                                  //   initialize vector
        double y1= (double)0.0;                                                  //   initialize vector
        double y2= (double)0.0;                                                  //   initialize vector
        double y3= (double)0.0;                                                  //   initialize vector
        double y4= (double)0.0;                                                  //   initialize vector
        double y5= (double)0.0;                                                  //   initialize vector
        double y6= (double)0.0;                                                  //   initialize vector
        double y7= (double)0.0;                                                  //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
    else{                                                                          // Z=Ax+Y branch
      while(Cofs<MaxCofs){                                                         // for all nonzeros{
        double y0=ZRelative[0+Rofs];                                             //   initialize vector
        double y1=ZRelative[1+Rofs];                                             //   initialize vector
        double y2=ZRelative[2+Rofs];                                             //   initialize vector
        double y3=ZRelative[3+Rofs];                                             //   initialize vector
        double y4=ZRelative[4+Rofs];                                             //   initialize vector
        double y5=ZRelative[5+Rofs];                                             //   initialize vector
        double y6=ZRelative[6+Rofs];                                             //   initialize vector
        double y7=ZRelative[7+Rofs];                                             //   initialize vector
        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row
          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2
          const double X0 = XRelative[0+C[Cofs]];                                //     load a value of X
          const double X1 = XRelative[1+C[Cofs]];                                //     load a value of X
          const double X2 = XRelative[2+C[Cofs]];                                //     load a value of X
          const double X3 = XRelative[3+C[Cofs]];                                //     load a value of X
          const double X4 = XRelative[4+C[Cofs]];                                //     load a value of X
          const double X5 = XRelative[5+C[Cofs]];                                //     load a value of X
          const double X6 = XRelative[6+C[Cofs]];                                //     load a value of X
          const double X7 = XRelative[7+C[Cofs]];                                //     load a value of X
          PREFETCH_NT(0+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[0+Vofs]*X0;                                                      //
          y1 += V[1+Vofs]*X0;                                                      //
          y2 += V[2+Vofs]*X0;                                                      //
          y3 += V[3+Vofs]*X0;                                                      //
          y4 += V[4+Vofs]*X0;                                                      //
          y5 += V[5+Vofs]*X0;                                                      //
          y6 += V[6+Vofs]*X0;                                                      //
          y7 += V[7+Vofs]*X0;                                                      //
          PREFETCH_NT(64+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[8+Vofs]*X1;                                                      //
          y1 += V[9+Vofs]*X1;                                                      //
          y2 += V[10+Vofs]*X1;                                                      //
          y3 += V[11+Vofs]*X1;                                                      //
          y4 += V[12+Vofs]*X1;                                                      //
          y5 += V[13+Vofs]*X1;                                                      //
          y6 += V[14+Vofs]*X1;                                                      //
          y7 += V[15+Vofs]*X1;                                                      //
          PREFETCH_NT(128+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[16+Vofs]*X2;                                                      //
          y1 += V[17+Vofs]*X2;                                                      //
          y2 += V[18+Vofs]*X2;                                                      //
          y3 += V[19+Vofs]*X2;                                                      //
          y4 += V[20+Vofs]*X2;                                                      //
          y5 += V[21+Vofs]*X2;                                                      //
          y6 += V[22+Vofs]*X2;                                                      //
          y7 += V[23+Vofs]*X2;                                                      //
          PREFETCH_NT(192+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[24+Vofs]*X3;                                                      //
          y1 += V[25+Vofs]*X3;                                                      //
          y2 += V[26+Vofs]*X3;                                                      //
          y3 += V[27+Vofs]*X3;                                                      //
          y4 += V[28+Vofs]*X3;                                                      //
          y5 += V[29+Vofs]*X3;                                                      //
          y6 += V[30+Vofs]*X3;                                                      //
          y7 += V[31+Vofs]*X3;                                                      //
          PREFETCH_NT(256+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[32+Vofs]*X4;                                                      //
          y1 += V[33+Vofs]*X4;                                                      //
          y2 += V[34+Vofs]*X4;                                                      //
          y3 += V[35+Vofs]*X4;                                                      //
          y4 += V[36+Vofs]*X4;                                                      //
          y5 += V[37+Vofs]*X4;                                                      //
          y6 += V[38+Vofs]*X4;                                                      //
          y7 += V[39+Vofs]*X4;                                                      //
          PREFETCH_NT(320+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[40+Vofs]*X5;                                                      //
          y1 += V[41+Vofs]*X5;                                                      //
          y2 += V[42+Vofs]*X5;                                                      //
          y3 += V[43+Vofs]*X5;                                                      //
          y4 += V[44+Vofs]*X5;                                                      //
          y5 += V[45+Vofs]*X5;                                                      //
          y6 += V[46+Vofs]*X5;                                                      //
          y7 += V[47+Vofs]*X5;                                                      //
          PREFETCH_NT(384+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[48+Vofs]*X6;                                                      //
          y1 += V[49+Vofs]*X6;                                                      //
          y2 += V[50+Vofs]*X6;                                                      //
          y3 += V[51+Vofs]*X6;                                                      //
          y4 += V[52+Vofs]*X6;                                                      //
          y5 += V[53+Vofs]*X6;                                                      //
          y6 += V[54+Vofs]*X6;                                                      //
          y7 += V[55+Vofs]*X6;                                                      //
          PREFETCH_NT(448+PREFETCH_V+(void*)&V[Vofs]);  //     prefetch matrix values into L1, don't evict to L2
          y0 += V[56+Vofs]*X7;                                                      //
          y1 += V[57+Vofs]*X7;                                                      //
          y2 += V[58+Vofs]*X7;                                                      //
          y3 += V[59+Vofs]*X7;                                                      //
          y4 += V[60+Vofs]*X7;                                                      //
          y5 += V[61+Vofs]*X7;                                                      //
          y6 += V[62+Vofs]*X7;                                                      //
          y7 += V[63+Vofs]*X7;                                                      //
          Vofs+=64;                                                                 //     increment offset in V
          Cofs++;                                                                  //     increment offset in C
        }                                                                          //   }
        YRelative[0+Rofs]=y0;                                                      //   store vector
        YRelative[1+Rofs]=y1;                                                      //   store vector
        YRelative[2+Rofs]=y2;                                                      //   store vector
        YRelative[3+Rofs]=y3;                                                      //   store vector
        YRelative[4+Rofs]=y4;                                                      //   store vector
        YRelative[5+Rofs]=y5;                                                      //   store vector
        YRelative[6+Rofs]=y6;                                                      //   store vector
        YRelative[7+Rofs]=y7;                                                      //   store vector
        Rofs+=8;                                                                   //   increment offset in Y,Z
        row++;                                                                     //   increment row
      }                                                                            // }
    }
  }

  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector
    if(Z==NULL)while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=(double)0.0;
      YRelative[Rofs+1]=(double)0.0;
      YRelative[Rofs+2]=(double)0.0;
      YRelative[Rofs+3]=(double)0.0;
      YRelative[Rofs+4]=(double)0.0;
      YRelative[Rofs+5]=(double)0.0;
      YRelative[Rofs+6]=(double)0.0;
      YRelative[Rofs+7]=(double)0.0;
      Rofs+=8;
    }
    else while(Rofs<SpA->NRows){
      YRelative[Rofs+0]=ZRelative[Rofs+0];
      YRelative[Rofs+1]=ZRelative[Rofs+1];
      YRelative[Rofs+2]=ZRelative[Rofs+2];
      YRelative[Rofs+3]=ZRelative[Rofs+3];
      YRelative[Rofs+4]=ZRelative[Rofs+4];
      YRelative[Rofs+5]=ZRelative[Rofs+5];
      YRelative[Rofs+6]=ZRelative[Rofs+6];
      YRelative[Rofs+7]=ZRelative[Rofs+7];
      Rofs+=8;
    }
  }

}

//==================================================================================================================================
