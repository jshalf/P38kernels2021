
//=====================================================================================================
#define FORMAT_BCSR 0
#define FORMAT_BCOO 1

#define  DENSE_VECTOR              0
#define SPARSE_VECTOR              1 // only count touched cache lines
#define SPARSE_VECTOR_FOR_DMA      2 // only count touched cache lines, create DMAList ( [address:stanza size] pairs ), recompress indices
#define SPARSE_VECTOR_FOR_COPY     3 // only count touched cache lines, create CacheLineList (addresses), recompress indices

#define OPTIMIZATION_THREAD        0x0001
#define OPTIMIZATION_PREFETCH      0x0002
#define OPTIMIZATION_REGISTER      0x0004
#define OPTIMIZATION_TLB_BLOCK_X   0x0008
#define OPTIMIZATION_CACHE_BLOCK_X 0x0010
#define OPTIMIZATION_CACHE_BLOCK_Y 0x0020
//=====================================================================================================
#define LOG_RegBlock_MaxR  3 // i.e. max allowed is 2^3 x 2^3 = 8x8
#define LOG_RegBlock_MaxC  3

//=====================================================================================================
#define VERBOSE_SUMMARY
