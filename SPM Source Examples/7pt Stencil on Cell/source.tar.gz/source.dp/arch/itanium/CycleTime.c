#include <ia64intrin.h>
inline uint64_t CycleTime(){
  return __getReg(_IA64_REG_AR_ITC);
}
