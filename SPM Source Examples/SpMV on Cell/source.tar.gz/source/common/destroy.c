// SpMV deallocation routines
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

void Destroy_SparseMatrix(SparseMatrix *SpA){
  if(SpA==NULL)return;

//  if(!(SpA->base0 || SpA->base1)){
//    if(SpA->R32b          != NULL)FREE(SpA->R32b         );SpA->R32b         =NULL;
//    if(SpA->R16b          != NULL)FREE(SpA->R16b         );SpA->R16b         =NULL;
//    if(SpA->P             != NULL)FREE(SpA->P            );SpA->P            =NULL;
//    if(SpA->C32b          != NULL)FREE(SpA->C32b         );SpA->C32b         =NULL;
//    if(SpA->C16b          != NULL)FREE(SpA->C16b         );SpA->C16b         =NULL;
//    if(SpA->V             != NULL)FREE(SpA->V            );SpA->V            =NULL;
//  }
  if(SpA->base0){     FREE(SpA->base0);}
  if(SpA->base1){NUMA_FREE(SpA->base1);}
  
  if(SpA->DMAList       != NULL)FREE(SpA->DMAList      );SpA->DMAList      =NULL;
  if(SpA->CacheLineList != NULL)FREE(SpA->CacheLineList);SpA->CacheLineList=NULL;

}

void Destroy_BlockedSparseMatrix(BlockedSparseMatrix *BlockedSpA){
  int32_t i;
  for(i=0;i<MaxThreads;i++){if(BlockedSpA->tempX[i])NUMA_FREE(BlockedSpA->tempX[i]);BlockedSpA->tempX[i]=NULL;}
  for(i=0;i<MaxThreads;i++){if(BlockedSpA->tempY[i])NUMA_FREE(BlockedSpA->tempY[i]);BlockedSpA->tempY[i]=NULL;}
  for(i=0;i<BlockedSpA->FirstBlockForThread[MaxThreads];i++)Destroy_SparseMatrix(BlockedSpA->blocks + i);FREE(BlockedSpA->blocks);
  FREE(BlockedSpA);
}
