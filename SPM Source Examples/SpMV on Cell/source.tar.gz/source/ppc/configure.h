//=====================================================================================================
#define MaxThreads             16

#define PageEntriesAvailable   1024
#define PageSizeInDoubles      512

#define MaxStanzaLength        10000000
#define MaxStanzas             10000000
#define CacheLinesAvailable    1000
#define CacheLineSizeInDoubles 16

#define RegBlock_MinR          1
#define RegBlock_MinC          1
#define RegBlock_MaxR          8
#define RegBlock_MaxC          8

#define PREFETCH_MIN_V            0
#define PREFETCH_MIN_C            0
#define PREFETCH_MAX_V          512
#define PREFETCH_MAX_C          128

#define ENABLE_FORMATS         0x0003 // bit mask for formats
#define ENABLE_16b             1

//#define EMULATE_PTHREAD_BARRIER
#define LOW_OVERHEAD_BARRIER
#define ENABLE_AFFINITY_VIA_SCHED
//#define ENABLE_AFFINITY_VIA_SOLARIS
