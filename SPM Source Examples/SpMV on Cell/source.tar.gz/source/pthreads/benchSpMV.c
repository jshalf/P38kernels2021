// SpMV benchmark 
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

  #define REALLOC(pointer,size) realloc((pointer),(size))
  #define  MALLOC(size)          malloc((size))
  #define    FREE(pointer)         free((pointer))
//#define    FREE(pointer)         printf("didn't FREE()\n")

//==============================================================================
//#define VERIFY
//==============================================================================
#if defined (__i386__) || defined(__x86_64__)
  #define _BEST_ALIGNMENT __attribute__ ((aligned (64)))
  #include "../x86/configure.h"
  //#include "../x86/configure.1.h"	// naive, parallel, NUMA
  //#include "../x86/configure.2.h"	// prefetch
  //#include "../x86/configure.3.h"	// compress

  //#ifdef __SSE__
    #include <xmmintrin.h>
    #include <emmintrin.h>
    #include <pmmintrin.h>
    #define PREFETCH_NT(address) _mm_prefetch((address),_MM_HINT_NTA)
  //#else
  //  #define PREFETCH_NT(address) ;
  //#endif

  #ifdef USE_PTHREAD_BARRIER
    typedef union{
      char __size[__SIZEOF_PTHREAD_BARRIER_T];
      long int __align;
    } pthread_barrier_t;
  #endif
//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   
#elif defined(__sparc) && defined (__sparcv9)
  #define _BEST_ALIGNMENT __attribute__ ((aligned (64)))
  //#define _BEST_ALIGNMENT
  #include "../niagara/configure.h"

  //#include "/opt/SUNWspro/prod/include/cc/sun_prefetch.h"
  //#include "sun_prefetch.h"
  //#define PREFETCH_NT(address) __sparc_strong_prefetch_read_once_intrinsic((address))
  #define PREFETCH_NT(address) __sparc_prefetch_read_once_intrinsic((address))
  //#define PREFETCH_NT(address) sparc_prefetch_read_once((address))
  // FIX - something seems screwy with __builtin_prefetch !!!
  // address, r:w, locality
  //#define PREFETCH_NT(address) __builtin_prefetch((address))
  //#define PREFETCH_NT(address) ;

  #ifdef __RESTRICT
    #define __restrict__ _Restrict
  #endif
//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   
#elif defined(__ppc__) || defined (__powerpc__)
  #define _BEST_ALIGNMENT __attribute__ ((aligned (128)))
  #include "../ppc/configure.h"
  // FIX - use prefetch intrinsic
  //#define PREFETCH_NT(address) __dcbt((address))
  #define PREFETCH_NT(address) __builtin_prefetch((address),0,1)
#endif
//------------------------------------------------------------------------------
#include "../common/defines.h"
#include "../common/types.h"
#include "../common/affinity.h"
//------------------------------------------------------------------------------
#include "../common/affinity.c"
//#include "../common/affinity.sles.c"
#include "../common/crt.c"
#include "../common/init.c"
#include "../common/destroy.c"
#include "../common/loader.c"
#include "../common/parallelize.c"
#include "../common/optimize.c"
//#include "../common/optimize.safe.c"
#include "../common/spyplot.c"
#include "../common/barrier.c"
//------------------------------------------------------------------------------
#if defined (__i386__) || defined(__x86_64__)
  #include "../x86/CycleTime.c"
  #include "../x86/kernels.csr.h"
  #include "../x86/kernels.coo.h"
  #include "../x86/variables.c"
  #include "../x86/kernels.csr.c"
  #include "../x86/kernels.coo.c"

#elif defined(__sparc) && defined (__sparcv9)
  #include "../niagara/CycleTime.c"
  #include "../niagara/kernels.csr.h"
  #include "../niagara/kernels.coo.h"
  #include "../niagara/variables.c"
  #include "../niagara/kernels.csr.c"
  #include "../niagara/kernels.coo.c"

#elif defined(__ppc__) || defined (__powerpc__)
  #include "../ppc/CycleTime.c"
  #include "../ppc/kernels.csr.h"
  #include "../ppc/kernels.coo.h"
  #include "../ppc/variables.c"
  #include "../ppc/kernels.csr.c"
  #include "../ppc/kernels.coo.c"
#endif
//==============================================================================
typedef struct {
  BlockedSparseMatrix *BlockedSpA;
  double *X,*Y,*Z;
  uint64_t ThreadID;
  uint64_t BestTime;
  double GFLOPs;
  double pad[CacheLineSizeInDoubles];
}WorkJob;
//==============================================================================
#define minTime 0.10 // seconds
#define minTrials 10
double frequency;
uint32_t RThreads = 1;
uint32_t CThreads = 1;
uint32_t ReachedTimeout = 0;
double AbsolutePeakGFLOPs = -1.0;
barrier_t MyBarrier;
//==============================================================================
void * bench_blocked_EachThread(void *arg){
  WorkJob *wj = arg;
  BlockedSparseMatrix *BlockedSpA = (BlockedSparseMatrix*)wj->BlockedSpA;
  double *X = (double*)wj->X;
  double *Y = (double*)wj->Y;
  double *Z = (double*)wj->Z; // Just doing Y=Ax
  uint32_t b,trials,bestTrial;
  //uint64_t tStart,tBarrier,tDone;

  Affinity_Bind_Thread(wj->ThreadID);

  double BEST_gflops = -1.0;
  //uint64_t MyBestTime = 0xFFFFFFFFFFFFFFFF;
  uint64_t MyBestTime = 0xFFFFFFFF;
  int32_t pv = -1;
  int32_t pc = -1;
  uint32_t BEST_V = pv;
  uint32_t BEST_C = pc;

  for(pc= PREFETCH_MIN_C;pc<=PREFETCH_MAX_C;pc+=(CacheLineSizeInDoubles<<3)){
  for(pv= PREFETCH_MIN_V;pv<=PREFETCH_MAX_V;pv+=(CacheLineSizeInDoubles<<3)){
    barrier_wait(&MyBarrier,wj->ThreadID);
    if(wj->ThreadID==0)ReachedTimeout = 0;
    uint64_t tStartTrials = CycleTime();
    barrier_wait(&MyBarrier,wj->ThreadID);
    //for(trials=0;(trials<minTrials)||(!ReachedTimeout);trials++){
    trials=0;
    while( (!ReachedTimeout) || (trials<minTrials) ){
      trials++;
      uint64_t tStart = CycleTime();
      barrier_wait(&MyBarrier,wj->ThreadID);
      double * WorkingY = Y;
      if(BlockedSpA->CThreads>1)WorkingY = BlockedSpA->tempY[wj->ThreadID];
      for(b=BlockedSpA->FirstBlockForThread[wj->ThreadID];b<BlockedSpA->FirstBlockForThread[wj->ThreadID+1];b++){
        double * WorkingZ = WorkingY;
        if(BlockedSpA->blocks[b].InitY)WorkingZ=NULL; // Y=Ax
        kernels_bfRC[BlockedSpA->blocks[b].Bits][BlockedSpA->blocks[b].Format][BlockedSpA->blocks[b].logR][BlockedSpA->blocks[b].logC](BlockedSpA->blocks+b,X,WorkingZ,WorkingY,pv,pc);
      }
      uint64_t tDone = CycleTime();
      barrier_wait(&MyBarrier,wj->ThreadID);
      uint64_t tBarrier = CycleTime();
      double *temp = X;X=Y;Y=temp;

      if(wj->ThreadID==0){
        double TotalTime = (double)(tBarrier-tStartTrials)/1e9/frequency;
	if(TotalTime > minTime)ReachedTimeout=1;
      }
      barrier_wait(&MyBarrier,wj->ThreadID);

      #ifdef VERIFY
        pthread_exit(NULL);
      #endif
    }
    uint64_t tDoneTrials = CycleTime();
    double gflops = trials*frequency * 2.0*BlockedSpA->ActualNonZeros / (double)(tDoneTrials-tStartTrials);

    if(gflops > 1.01 * BEST_gflops){
      //printf("Thread %d, time in barrier = %d\n",wj->ThreadID,tBarrier-tDone);
      BEST_gflops = gflops;
      BEST_V = pv;
      BEST_C = pc;
      MyBestTime = (tDoneTrials-tStartTrials)/trials;
      bestTrial = trials;
    }
    //printf("%d\n",trials);
    if(!(BlockedSpA->OptimizationMask & OPTIMIZATION_PREFETCH)){pv=PREFETCH_MAX_V+1;pc=PREFETCH_MAX_C+1;}
  }}

  wj->GFLOPs   = BEST_gflops;
  wj->BestTime = MyBestTime;

  if(wj->ThreadID==0){
    //printf("%d %d\n",bestTrial,trials);
    if(BEST_gflops > 1.01 * AbsolutePeakGFLOPs){AbsolutePeakGFLOPs=BEST_gflops;
       printf("[");
       if(BlockedSpA->OptimizationMask&OPTIMIZATION_THREAD       )printf("Thread,");else
                                                                  printf("       ");
       if(BlockedSpA->OptimizationMask&OPTIMIZATION_TLB_BLOCK_X  )printf("TLB,");else 
                                                                  printf("    ");
       if(BlockedSpA->OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X)printf("Cache,");else 
       if(BlockedSpA->OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y)printf("Cache,");else 
                                                                  printf("      ");
       if(BlockedSpA->OptimizationMask&OPTIMIZATION_REGISTER     )printf("Register,");else 
                                                                  printf("         ");
       printf("Prefetch]: %0.3f GFlop/s, %0.3f flop:byte ratio, (V=%4d, C=%4d)\n",BEST_gflops,BlockedSpA->FlopToByteRatio,BEST_V,BEST_C);
  }}

  if(wj->ThreadID!=(BlockedSpA->RThreads*BlockedSpA->CThreads-1)){
    pthread_exit(NULL);
  }

}

void bench_blocked_pthreads(BlockedSparseMatrix *BlockedSpA, SparseMatrix *SpA){
  Affinity_unBind();
  uint32_t r,c,t,rc,i;
  uint32_t vectorSize = BlockedSpA->NCols;if(BlockedSpA->NRows > BlockedSpA->NCols)vectorSize = BlockedSpA->NRows;
  Affinity_Bind_Memory(0);
  double *X = (double*)NUMA_MALLOC(vectorSize * sizeof(double),0);
  Affinity_Bind_Memory((BlockedSpA->RThreads*BlockedSpA->CThreads)-1);
  double *Y = (double*)NUMA_MALLOC(vectorSize * sizeof(double),(BlockedSpA->RThreads*BlockedSpA->CThreads)-1);
  double *Z = NULL;
  #ifdef VERIFY
    for(i=0;i<vectorSize;i++){X[i]=1.0*(rand()%1000);Y[i]=1.0*(rand()%1000);}
  #else
    for(i=0;i<vectorSize;i++){X[i]=1.0;Y[i]=0.0;}
  #endif

  pthread_t threads[MaxThreads];
  WorkJob workjobs[MaxThreads];

  //if(BlockedSpA->CThreads>1){printf("BlockedSpA->CThreads>1 not yet supported\n");exit(0);}
  printf("creating %d pthreads...\n",BlockedSpA->RThreads*BlockedSpA->CThreads);fflush(stdout);
  barrier_init(&MyBarrier,BlockedSpA->RThreads*BlockedSpA->CThreads); // wait for TotalThreads to wait

  t=0;
  for(r=0; r<BlockedSpA->RThreads; r++){
    for(c=0; c<BlockedSpA->CThreads; c++){
      workjobs[t].BlockedSpA = BlockedSpA;
      workjobs[t].ThreadID   =          t;
      workjobs[t].X          =          X;
      workjobs[t].Y          =          Y;
      workjobs[t].Z          =          Z;
      //printf("creating thread %d\n",t);fflush(stdout);
      if(t==(BlockedSpA->RThreads*BlockedSpA->CThreads-1)){
        bench_blocked_EachThread((void *)&workjobs[t]);
      }else{
        if((rc=pthread_create(&threads[t], NULL, bench_blocked_EachThread, (void *)&workjobs[t]))){
          printf("ERROR; return code from pthread_create() is %d\n", rc);
          exit(-1);
        }
      }
      t++;
  }}
  for(t=0; t<BlockedSpA->RThreads*BlockedSpA->CThreads-1; t++)pthread_join(threads[t], NULL);
  printf("joined %d threads\n",BlockedSpA->RThreads*BlockedSpA->CThreads);
  barrier_destroy(&MyBarrier);
  uint64_t AverageCycles=0;
  uint64_t   WorstCycles=0;
  int32_t  SlowestThread=-1;
  for(t=0; t<BlockedSpA->RThreads*BlockedSpA->CThreads; t++){
    AverageCycles+=workjobs[t].BestTime;
    if(workjobs[t].BestTime>WorstCycles){WorstCycles=workjobs[t].BestTime;SlowestThread=t;}
  }AverageCycles = AverageCycles / (BlockedSpA->RThreads*BlockedSpA->CThreads);
  printf("average=%ld worst=%ld(thread %2d) %3.2f\n",AverageCycles,WorstCycles,SlowestThread,(double)WorstCycles/(double)AverageCycles);

  #ifdef VERIFY
    printf("verifiying results...\n");
    double *YTrue = (double*)NUMA_MALLOC(vectorSize * sizeof(double),0);
    for(i=0;i<vectorSize;i++){YTrue[i]=1.0*(rand()%1000);}
    kernels_bfRC[SpA->Bits][SpA->Format][SpA->logR][SpA->logC](SpA,X,NULL,YTrue,0,0);
    for(i=0;i<SpA->NRows;i++){
      if(Y[i] != YTrue[i])
        printf("Y[%d]=%f !=  YTrue[%d]=%f\n",i,Y[i],i,YTrue[i]);
    }
  #endif

  NUMA_FREE(X);
  NUMA_FREE(Y);
}


void bench_blocked(BlockedSparseMatrix *BlockedSpA, SparseMatrix *SpA){
  uint32_t i,b;
  uint32_t trials;
  uint64_t t0,t1,t2,t3;
  printf("%d blocks\n",BlockedSpA->FirstBlockForThread[MaxThreads]);

  //if(ENABLE_NUMA){
  //  uint64_t mask = 1;if(sched_setaffinity(0, sizeof(mask), &mask)<0){printf("Couldn't move process to %04x\n",mask);exit(0);}
  //}

  Affinity_Bind_Thread(0);
  Affinity_Bind_Memory(0);
  uint32_t vectorSize = BlockedSpA->NCols;if(BlockedSpA->NRows > BlockedSpA->NCols)vectorSize = BlockedSpA->NRows;
  double *X = (double*)NUMA_MALLOC(vectorSize * sizeof(double),0);
  double *Y = (double*)NUMA_MALLOC(vectorSize * sizeof(double),0);
  double *Z = NULL; // Just doing Y=Ax
  for(i=0;i<vectorSize;i++){X[i]=1.0;Y[i]=0.0;}
  #ifdef VERIFY
    for(i=0;i<vectorSize;i++){X[i]=1.0*(rand()%1000);Y[i]=1.0*(rand()%1000);}
  #else
    for(i=0;i<vectorSize;i++){X[i]=1.0;Y[i]=0.0;}
  #endif

  double BEST_gflops = -1.0;
  int32_t pv = 0;
  int32_t pc = 0;
  uint32_t BEST_V = pv;
  uint32_t BEST_C = pc;

  for(pc= PREFETCH_MIN_C;pc<=PREFETCH_MAX_C;pc+=(CacheLineSizeInDoubles<<3)){
  for(pv= PREFETCH_MIN_V;pv<=PREFETCH_MAX_V;pv+=(CacheLineSizeInDoubles<<3)){
    t0 = CycleTime();t1=t0;
    trials=0;
    while( ( ((double)(t1-t0)/frequency/1e9) < minTime) || (trials < minTrials) ){
      t2 = CycleTime();
      double * WorkingY = Y;
      for(b=0;b<BlockedSpA->FirstBlockForThread[MaxThreads];b++){
        double * WorkingZ = WorkingY;
        if(BlockedSpA->blocks[b].InitY)WorkingZ=NULL; // Y=Ax
        kernels_bfRC[BlockedSpA->blocks[b].Bits][BlockedSpA->blocks[b].Format][BlockedSpA->blocks[b].logR][BlockedSpA->blocks[b].logC](BlockedSpA->blocks+b,X,WorkingZ,WorkingY,pv,pc);
      }
      t1 = CycleTime();
      #ifdef VERIFY
        trials=minTrials;
	t0 = 0;
	t1 = 0xFFFFFFFF;
	pc = PREFETCH_MAX_C+1;
	pv = PREFETCH_MAX_V+1;
      #endif

      double *temp = X;X=Y;Y=temp;
      trials++;

    }
    t3 = CycleTime();
    double gflops = trials*frequency * 2.0*BlockedSpA->ActualNonZeros / (t3-t0);
    if(gflops > 1.01 * BEST_gflops){
      BEST_gflops = gflops;
      BEST_V = pv;
      BEST_C = pc;
    }
    if(!(BlockedSpA->OptimizationMask & OPTIMIZATION_PREFETCH)){pv=PREFETCH_MAX_V+1;pc=PREFETCH_MAX_C+1;}
  }}

  if(BEST_gflops > 1.01 * AbsolutePeakGFLOPs){AbsolutePeakGFLOPs=BEST_gflops;
  printf("[");
  if(BlockedSpA->OptimizationMask&OPTIMIZATION_THREAD       )printf("Thread,");else
                                                             printf("       ");
  if(BlockedSpA->OptimizationMask&OPTIMIZATION_TLB_BLOCK_X  )printf("TLB,");else 
                                                             printf("    ");
  if(BlockedSpA->OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X)printf("Cache,");else 
  if(BlockedSpA->OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y)printf("Cache,");else 
                                                             printf("      ");
  if(BlockedSpA->OptimizationMask&OPTIMIZATION_REGISTER     )printf("Register,");else 
                                                             printf("         ");
  printf("Prefetch]: %0.3f GFlop/s, %0.3f flop:byte ratio, (V=%4d, C=%4d)\n",BEST_gflops,BlockedSpA->FlopToByteRatio,BEST_V,BEST_C);
  //printf("Prefetch]: %0.3f GFlop/s (V=%4d, C=%4d)\n",BEST_gflops,BEST_V,BEST_C);
  //printf("[       Cache,Regster,Prefetch]: %0.3f GFlop/s, %0.3f flop:byte ratio, (V=%4d, C=%4d)\n",BEST_gflops,BlockedSpA->FlopToByteRatio,BEST_V,BEST_C);
  }

  double *temp = X;X=Y;Y=temp;
  #ifdef VERIFY
    printf("verifiying results...\n");
    double *YTrue = (double*)NUMA_MALLOC(vectorSize * sizeof(double),0);
    for(i=0;i<vectorSize;i++){YTrue[i]=1.0*(rand()%1000);}
    kernels_bfRC[SpA->Bits][SpA->Format][SpA->logR][SpA->logC](SpA,X,NULL,YTrue,0,0);
    for(i=0;i<SpA->NRows;i++){
      if(Y[i] != YTrue[i])
        printf("Y[%d]=%f !=  YTrue[%d]=%f\n",i,Y[i],i,YTrue[i]);
    }
  #endif

  NUMA_FREE(X);
  NUMA_FREE(Y);
}

void bench_unblocked(SparseMatrix *SpA){
  uint32_t i;
  uint32_t trials;
  uint64_t t0,t1,t2,t3;

  Affinity_Bind_Thread(0);
  Affinity_Bind_Memory(0);
  uint32_t vectorSize = SpA->NCols;if(SpA->NRows > SpA->NCols)vectorSize = SpA->NRows;
  double *X = (double*)NUMA_MALLOC(vectorSize * sizeof(double),0);
  double *Y = (double*)NUMA_MALLOC(vectorSize * sizeof(double),0);
  double *Z = NULL; // Just doing Y=Ax
  for(i=0;i<vectorSize;i++){X[i]=1.0;Y[i]=0.0;}

  double BEST_gflops = -1.0;
  int32_t pv = 0;
  int32_t pc = 0;
  uint32_t BEST_V = pv;
  uint32_t BEST_C = pc;

    t0 = CycleTime();t1=t0;
    trials=0;
    while( ( ((double)(t1-t0)/frequency/1e9) < minTime) || (trials < minTrials) ){
      t2 = CycleTime();
      kernels_bfRC[SpA->Bits][SpA->Format][SpA->logR][SpA->logC](SpA,X,NULL,Y,pv,pc);
      t1 = CycleTime();
      double *temp = X;X=Y;Y=temp;
      trials++;
    }
    t3 = CycleTime();
    double gflops = trials*frequency * 2.0*SpA->ActualNonZeros / (t3-t0);
    if(gflops > 1.01 * BEST_gflops){
      BEST_gflops = gflops;
      BEST_V = pv;
      BEST_C = pc;
    }
  if(BEST_gflops > 1.01 * AbsolutePeakGFLOPs){AbsolutePeakGFLOPs=BEST_gflops;
  printf("[                                  ]: %0.3f GFlop/s, %0.3f flop:byte ratio, (V=%4d, C=%4d)\n",BEST_gflops,0.0,BEST_V,BEST_C);
  }
  double NAIVE_gflops = BEST_gflops;

  for(pc=             PREFETCH_MIN_C;pc<=PREFETCH_MAX_C;pc+=(CacheLineSizeInDoubles<<3)){
  for(pv=(CacheLineSizeInDoubles<<3);pv<=PREFETCH_MAX_V;pv+=(CacheLineSizeInDoubles<<3)){
    t0 = CycleTime();t1=t0;
    trials=0;
    //while( trials < minTrials ){
    while( ( ((double)(t1-t0)/frequency/1e9) < minTime) || (trials < minTrials) ){
      t2 = CycleTime();
      kernels_bfRC[SpA->Bits][SpA->Format][SpA->logR][SpA->logC](SpA,X,NULL,Y,pv,pc);
      t1 = CycleTime();
      double *temp = X;X=Y;Y=temp;
      trials++;
    }
    t3 = CycleTime();
    double gflops = frequency * 2.0*SpA->ActualNonZeros / (t3-t0);
    if(gflops > 1.01 * BEST_gflops){
      BEST_gflops = gflops;
      BEST_V = pv;
      BEST_C = pc;
    }
  }}

  if(BEST_gflops > 1.01 * AbsolutePeakGFLOPs){AbsolutePeakGFLOPs=BEST_gflops;
  printf("[                          Prefetch]: %0.3f GFlop/s, %0.3f flop:byte ratio, (V=%4d, C=%4d)\n",BEST_gflops,0.0,BEST_V,BEST_C);
  }
  NUMA_FREE(X);
  NUMA_FREE(Y);
}


int main(int argc, char **argv){
  int i,j;
  uint32_t OptimizationMask;


#ifdef __MMX__
  printf("MMX enabled\n");
#endif
#ifdef __SSE__
  printf("SSE enabled\n");
#endif
#ifdef __SSE2__
  printf("SSE2 enabled\n");
#endif
#ifdef __SSE3__
  printf("SSE3 enabled\n");
#endif
  
  //printf("FZ = 0x%08x\n",_MM_GET_FLUSH_ZERO_MODE());
  //printf("MXCSR = 0x%08x\n",_mm_getcsr());

  Affinity_Init();

       if(argc == 2){/* filename = argv[1]*/}
  else if(argc == 4){RThreads=atoi(argv[2]);CThreads=atoi(argv[3]);}
                else{printf("usage: ./a.out [matrix name] [RThreads] [CThreads]\n");exit(0);}

  if(CThreads*RThreads > MaxThreads){printf("Too many threads %d > %d\n",RThreads*CThreads,MaxThreads);exit(0);}

  SparseMatrix *SpA = LoadMatrix_HBF_to_CSR(argv[1],1);

  printf("calculating frequency\n");
  uint64_t t0 = CycleTime();
  sleep(1);
  uint64_t t1 = CycleTime();
  frequency = (t1-t0)/1e9;
  printf("%0.3f GHz\n",frequency);

  // for the base case - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  if(CThreads*RThreads==1){bench_unblocked(SpA);}

  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  BlockedSparseMatrix *BlockedSpA;

  // First, try just register blocking with threading - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  OptimizationMask=0;
  if(RThreads*CThreads>1)OptimizationMask |= OPTIMIZATION_THREAD;
  OptimizationMask |= OPTIMIZATION_REGISTER;
  OptimizationMask |= OPTIMIZATION_PREFETCH;
   
  BlockedSpA = Parallelize_and_Block_SparseMatrix(SpA,RThreads,CThreads,OptimizationMask,SPARSE_VECTOR);
  Optimize_BlockedSparseMatrix(BlockedSpA);
  if(BlockedSpA->RThreads*BlockedSpA->CThreads==1)bench_blocked(BlockedSpA,SpA);
                                             else bench_blocked_pthreads(BlockedSpA,SpA);
  Destroy_BlockedSparseMatrix(BlockedSpA);
  NUMA_Heap_Flush();

  // Now try adding cache blocking - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//  if(SpA->NCols > CacheLinesAvailable*CacheLineSizeInDoubles){
    OptimizationMask=0;
    if(RThreads*CThreads>1)OptimizationMask |= OPTIMIZATION_THREAD;
    OptimizationMask |= OPTIMIZATION_REGISTER;
    OptimizationMask |= OPTIMIZATION_PREFETCH;
    OptimizationMask |= OPTIMIZATION_CACHE_BLOCK_X;
    OptimizationMask |= OPTIMIZATION_CACHE_BLOCK_Y;
  
    BlockedSpA = Parallelize_and_Block_SparseMatrix(SpA,RThreads,CThreads,OptimizationMask,SPARSE_VECTOR);
    Optimize_BlockedSparseMatrix(BlockedSpA);
    if(BlockedSpA->RThreads*BlockedSpA->CThreads==1)bench_blocked(BlockedSpA,SpA);
                                               else bench_blocked_pthreads(BlockedSpA,SpA);
    Destroy_BlockedSparseMatrix(BlockedSpA);
    NUMA_Heap_Flush();
//  }

  // Finally, try both Cache and TLB blocking - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  if(SpA->NCols > PageEntriesAvailable*PageSizeInDoubles){
    OptimizationMask=0;
    if(RThreads*CThreads>1)OptimizationMask |= OPTIMIZATION_THREAD;
    OptimizationMask |= OPTIMIZATION_REGISTER;
    OptimizationMask |= OPTIMIZATION_PREFETCH;
    OptimizationMask |= OPTIMIZATION_TLB_BLOCK_X;
    OptimizationMask |= OPTIMIZATION_CACHE_BLOCK_X;
    OptimizationMask |= OPTIMIZATION_CACHE_BLOCK_Y;
  
    BlockedSpA = Parallelize_and_Block_SparseMatrix(SpA,RThreads,CThreads,OptimizationMask,SPARSE_VECTOR);
    Optimize_BlockedSparseMatrix(BlockedSpA);
    if(BlockedSpA->RThreads*BlockedSpA->CThreads==1)bench_blocked(BlockedSpA,SpA);
                                               else bench_blocked_pthreads(BlockedSpA,SpA);
    Destroy_BlockedSparseMatrix(BlockedSpA);
    NUMA_Heap_Flush();
  }

  return(0);
}
