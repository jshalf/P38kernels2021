#include <numa.h>
nodemask_t nodemask;
 int32_t NUMA_Sockets        = -1;
 int32_t NUMA_CoresPerSocket = -1;

void Affinity_Init(){ 
  if (numa_available() < 0) {
    fprintf(stderr, "your system does not support NUMA...\n");
  }else{
    printf("implementing NUMA via <numa.h>\n");
    NUMA_Sockets = numa_max_node()+1;

    // Cell Specific
    NUMA_CoresPerSocket = spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES,0);

    numa_set_strict(1);
    numa_set_bind_policy(1);

    printf("found %d nodes with %d cores each\n", NUMA_Sockets,NUMA_CoresPerSocket);
  }
  return;
}

void Affinity_Bind_Memory(uint32_t thread){
  nodemask_zero(&nodemask);
  nodemask_set(&nodemask,(thread/NUMA_CoresPerSocket));
  numa_set_membind(&nodemask);
  return;
}

void Affinity_Bind_Thread(uint32_t thread){
  nodemask_zero(&nodemask);
  nodemask_set(&nodemask,(thread/NUMA_CoresPerSocket));
  numa_run_on_node((thread/NUMA_CoresPerSocket));
  //numa_bind(&nodemask); // binds both memory and execution
  return;
}

void Affinity_unBind(){
  nodemask_zero(&nodemask);
  nodemask_set(&nodemask,0);
  numa_set_membind(&nodemask);
  numa_run_on_node(0);
  //numa_bind(&nodemask);
  //numa_set_membind(&numa_all_nodes);
  //numa_bind(&numa_all_nodes);
  return;
}
