//==================================================================================================================================
void (*kernels_bfRC[2][2][LOG_RegBlock_MaxR+1][LOG_RegBlock_MaxC+1])(const uint32_t, const double *__restrict__, const uint16_t * __restrict__, const uint16_t * __restrict__, const double *__restrict__, double *) =  // {16:32b}, {BCSR:BCOO}, logR, logC
{ 
  { // 16b sub array
    { // csr sub array
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  } 
    },
    { // coo sub array
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {    &SpMV_b2x1_coo16b,    &SpMV_b2x2_coo16b,    &SpMV_b2x4_coo16b,    &SpMV_b2x8_coo16b  },
      {    &SpMV_b4x1_coo16b,    &SpMV_b4x2_coo16b,    &SpMV_b4x4_coo16b,    &SpMV_b4x8_coo16b  },
      {    &SpMV_b8x1_coo16b,    &SpMV_b8x2_coo16b,    &SpMV_b8x4_coo16b,    &SpMV_b8x8_coo16b  } 
    } 
  },
  { // 32b sub array
    { // csr sub array
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  } 
    },
    { // coo sub array
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  },
      {                 NULL,                 NULL,                 NULL,                 NULL  } 
    } 
  } 
};
