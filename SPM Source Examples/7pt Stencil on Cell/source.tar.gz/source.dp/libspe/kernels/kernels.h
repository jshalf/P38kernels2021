void _stencil3_u0();
void _stencil3_u1();
void _stencil3_u2();
void _stencil3_u3();
void _stencil3_u4();
void _stencil3_u5();
void _stencil3_u6();
void _stencil3_u7();
