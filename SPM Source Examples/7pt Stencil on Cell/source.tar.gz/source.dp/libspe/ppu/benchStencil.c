#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>
#include <libspe2.h>

//#include    <free_align.h>
//#include  <malloc_align.h>
//#include <realloc_align.h>
//#define FREE(pointer)            _free_align(pointer)
//#define REALLOC(pointer,size) _realloc_align(pointer,size,7)
//#define  MALLOC(size)          _malloc_align(size,7)

#define _CACHE_ALIGNMENT __attribute__ ((aligned(128)))
#define MaxThreads 16
//------------------------------------------------------------------------------
#include "../../arch/generic/affinity.h"
#include "../../arch/cbe/configure.h"
//------------------------------------------------------------------------------
#include "../../common/variables.c"
#include "../include/misc.c"
#include "../../common/init.c"
//#include "../../arch/generic/affinity.c"
#include "../../arch/cbe/affinity.numa.c"
#include "../../arch/cbe/CycleTime.c"
#include "../../arch/cbe/barrier.c"
//==============================================================================
extern spe_program_handle_t stencil_spe;
//==============================================================================
void * bench_pthreads_SPE(void *arg){
  uint64_t *pthread_args = (uint64_t*)arg;
                      double *G0 =                 (double*)pthread_args[ 0];
                      double *G1 =                 (double*)pthread_args[ 1];
                   uint32_t rank =                          pthread_args[31];
  uint64_t bx,by,bz,bn;

  Affinity_Bind_Thread(rank);
  Affinity_Bind_Memory(rank);
  bn = 0;
  for(bz=0;bz<Parameters.ZBlocks;bz++){
    for(by=0;by<Parameters.YBlocks;by++){
      for(bx=0;bx<Parameters.XBlocks;bx++){
        if(((bn/Parameters.BlocksPerChunk) % Parameters.NThreads)==rank){
          uint64_t StartX = bx*Parameters.XDimPerBlock+1;uint64_t EndX = (bx+1)*Parameters.XDimPerBlock+1;
          uint64_t StartY = by*Parameters.YDimPerBlock+1;uint64_t EndY = (by+1)*Parameters.YDimPerBlock+1;
          uint64_t StartZ = bz*Parameters.ZDimPerBlock+1;uint64_t EndZ = (bz+1)*Parameters.ZDimPerBlock+1;
          Init_Grid(G0,StartX,EndX,StartY,EndY,StartZ,EndZ);
          Init_Grid(G1,StartX,EndX,StartY,EndY,StartZ,EndZ);
        }bn++;
  }}}
  Affinity_Bind_Thread(rank);
  Affinity_Bind_Memory(rank);

  uint32_t rc,entry = SPE_DEFAULT_ENTRY;
  if((rc = spe_context_run(*((spe_context_ptr_t*)pthread_args[29]), &entry, 0, pthread_args, NULL, NULL)) < 0) {
    fprintf(stderr, "Failed spe_context_run(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
    exit(0);
  }
  pthread_exit(NULL);
}

//==============================================================================
void bench_pthreads(double *G0,double *G1){
  uint32_t t,i,rc,trial;
  double GFlops = 0.0;
  Affinity_unBind();

  pthread_t     pthreadIDs[MaxThreads];
  spe_context_ptr_t speIDs[MaxThreads];
             void * speLSs[MaxThreads];
   uint64_t pthread_args[MaxThreads][32] _CACHE_ALIGNMENT;

  uint32_t nSPEs = spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES, -1);
  if(nSPEs < Parameters.NThreads) {
    fprintf(stderr, "System only has %d working SPEs, requested %d.\n",nSPEs,Parameters.NThreads);
    exit(0);
  }

  //barrier_init(&MyBarrier,Parameters.NThreads); // wait for TotalThreads to wait
  for(t=0; t<Parameters.NThreads; t++){
    //Affinity_Bind_Thread(t);
    //Affinity_Bind_Memory(t);
    pthread_args[t][ 0] = (uint64_t)                   G0; // grid[0]
    pthread_args[t][ 1] = (uint64_t)                   G1; // grid[1]
    pthread_args[t][ 2] = (uint64_t)          &Parameters; // ...

    pthread_args[t][ 3] = (uint64_t)                    0; // ...
    pthread_args[t][ 4] = (uint64_t)                    0; // ...
    pthread_args[t][ 5] = (uint64_t)                    0; // ...
    pthread_args[t][ 6] = (uint64_t)                    0; // ...
    pthread_args[t][ 7] = (uint64_t)                    0; // ...
    pthread_args[t][ 8] = (uint64_t)                    0; // ...
    pthread_args[t][ 9] = (uint64_t)                    0; // ...
    pthread_args[t][10] = (uint64_t)                    0; // ...
    pthread_args[t][11] = (uint64_t)                    0; // ...
    pthread_args[t][12] = (uint64_t)                    0; // ...
    pthread_args[t][13] = (uint64_t)                    0; // ...
    pthread_args[t][14] = (uint64_t)                    0; // ...
    pthread_args[t][15] = (uint64_t)                    0; // ...
    pthread_args[t][16] = (uint64_t)                    0; // ...
    pthread_args[t][17] = (uint64_t)                    0; // ...
    pthread_args[t][18] = (uint64_t)                    0; // ...
    pthread_args[t][19] = (uint64_t)                    0; // ...
    pthread_args[t][20] = (uint64_t)                    0; // ...
    pthread_args[t][21] = (uint64_t)                    0; // ...
    pthread_args[t][22] = (uint64_t)                    0; // ...
    pthread_args[t][23] = (uint64_t)                    0; // ...
    pthread_args[t][24] = (uint64_t)                    0; // ...
    pthread_args[t][25] = (uint64_t)                    0; // ...
    pthread_args[t][26] = (uint64_t)                    0; // ...
    pthread_args[t][27] = (uint64_t)                    0; // ...
    pthread_args[t][28] = (uint64_t)                    0; // ...
    pthread_args[t][29] = (uint64_t)           &speIDs[t]; // speID (context)
    pthread_args[t][30] = (uint64_t)       &pthreadIDs[t]; // pthread_t
    pthread_args[t][31] = (uint64_t)                    t; // rank
    if((speIDs[t] = spe_context_create(0,NULL)) == NULL) {
      fprintf(stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit(0);
    }
    if((rc = spe_program_load(speIDs[t], &stencil_spe)) != 0) {
      fprintf(stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit(0);
    }
    if((rc=pthread_create(&pthreadIDs[t], NULL, bench_pthreads_SPE, (void *)&pthread_args[t]))){
      printf("pthread_create() failed (%d)\n", rc);
      exit(0);
    }
    if((speLSs[t]=spe_ls_area_get(speIDs[t])) == NULL){
      fprintf(stderr, "Failed spe_ls_area_get(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit(0);
    }
    //uint32_t LockAddress=0;
    //while(spe_out_mbox_status(speIDs[t])<=0){_sleep_ticks(100);}
    //spe_out_mbox_read(speIDs[t],&LockAddress,1); // FIX error checking
    //spe_locks[t]=(int32_t *)(speLSs[t]+LockAddress);
  }
  for(t=0; t<Parameters.NThreads; t++){
    uint32_t LockAddress=0;
    while(spe_out_mbox_status(speIDs[t])<=0){_sleep_ticks(1000);}
    spe_out_mbox_read(speIDs[t],&LockAddress,1); // FIX error checking
    spe_locks[t]=(int32_t *)(speLSs[t]+LockAddress);
  }
  // stencil bench is off and running
  for(trial=0;trial<maxTrials;trial++){
    uint64_t _tTrial = CycleTime();
    barrier_wait(Parameters.NThreads);
    // do Stencil on SPEs
    barrier_wait(Parameters.NThreads);
    uint64_t _tBarrier = CycleTime();

    double CyclesPerPoint = ((double)(_tBarrier-_tTrial))/(Parameters.XDim*Parameters.YDim*Parameters.ZDim);
    double GPointsPerSecond = FrequencyGHz/CyclesPerPoint;
    double _GFlops = 8.0*GPointsPerSecond;
    //printf("trial GFlop/s = %3.3f\n",_GFlops);
    if(_GFlops>=GFlops){
      GFlops=_GFlops;
    }
  }
  // stencil bench is done
  for(t=0; t<Parameters.NThreads; t++){
    if((rc = pthread_join(pthreadIDs[t], NULL)) != 0) {
      fprintf(stderr, "Failed pthread_join(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
      exit(0);
    }
    if((rc = spe_context_destroy(speIDs[t])) != 0) {
      fprintf(stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
      exit(0);
    }
  }
  printf("Peak GFlop/s = %3.3f\n",GFlops);
  printf("joined %d threads\n",Parameters.NThreads);
}

//==============================================================================
int main(int argc, char **argv){
  int i,j;
  uint32_t OptimizationMask;

  Affinity_Init();
  Parameters.XDimPerBlock=64;Parameters.XBlocks=1;
  Parameters.YDimPerBlock=64;Parameters.YBlocks=1;
  Parameters.ZDimPerBlock=64;Parameters.ZBlocks=1;
  Parameters.NThreads = 1;
  Parameters.BlocksPerChunk = 1;
  Parameters.Compute = 1;
  Parameters.DMA = 1;

//     if(argc ==  4){Parameters.XDimPerBlock  =atoi(argv[1]);Parameters.YDimPerBlock  =atoi(argv[2]);Parameters.ZDimPerBlock  =atoi(argv[3]);}
//else if(argc ==  7){Parameters.XDimPerBlock  =atoi(argv[1]);Parameters.YDimPerBlock  =atoi(argv[2]);Parameters.ZDimPerBlock  =atoi(argv[3]);
//                    Parameters.XBlocks       =atoi(argv[4]);Parameters.YBlocks       =atoi(argv[5]);Parameters.ZBlocks       =atoi(argv[6]);}
       if(argc ==  8){Parameters.XDimPerBlock  =atoi(argv[1]);Parameters.YDimPerBlock  =atoi(argv[2]);Parameters.ZDimPerBlock  =atoi(argv[3]);
                      Parameters.XBlocks       =atoi(argv[4]);Parameters.YBlocks       =atoi(argv[5]);Parameters.ZBlocks       =atoi(argv[6]);
                      Parameters.NThreads      =atoi(argv[7]);}
  else if(argc ==  9){Parameters.XDimPerBlock  =atoi(argv[1]);Parameters.YDimPerBlock  =atoi(argv[2]);Parameters.ZDimPerBlock  =atoi(argv[3]);
                      Parameters.XBlocks       =atoi(argv[4]);Parameters.YBlocks       =atoi(argv[5]);Parameters.ZBlocks       =atoi(argv[6]);
                      Parameters.NThreads      =atoi(argv[7]);Parameters.BlocksPerChunk=atoi(argv[8]);}
  else if(argc == 11){Parameters.XDimPerBlock  =atoi(argv[1]);Parameters.YDimPerBlock  =atoi(argv[2]);Parameters.ZDimPerBlock  =atoi(argv[3]);
                      Parameters.XBlocks       =atoi(argv[4]);Parameters.YBlocks       =atoi(argv[5]);Parameters.ZBlocks       =atoi(argv[6]);
                      Parameters.NThreads      =atoi(argv[7]);Parameters.BlocksPerChunk=atoi(argv[8]);
                      Parameters.Compute       =atoi(argv[9]);Parameters.DMA           =atoi(argv[10]);}
                 else{printf("usage: ./a.out [XDimPerBlock YDimPerBlock ZDimPerBlock] [XBlocks YBlocks ZBlocks] [NThreads] [BlocksPerChunk] [Compute DMA]\n");exit(0);}

  if(Parameters.XDimPerBlock % CacheLineSizeInDoubles){printf("XDimPerBlock(%3d) must be a multiple of CacheLineSizeInDoubles(%3d)\n",Parameters.XDimPerBlock,CacheLineSizeInDoubles);exit(0);}
  CheckFitsInLocalStore();
  Parameters.XDim = Parameters.XBlocks*Parameters.XDimPerBlock;
  Parameters.YDim = Parameters.YBlocks*Parameters.YDimPerBlock;
  Parameters.ZDim = Parameters.ZBlocks*Parameters.ZDimPerBlock;
  Parameters.PencilSize = (Parameters.XDim+2 + CacheLineSizeInDoubles-1 ) & ~(CacheLineSizeInDoubles-1); 
  Parameters.PlaneSize  = (Parameters.YDim+2)*Parameters.PencilSize;
  Parameters.VolumeSize = (Parameters.ZDim+2)*Parameters.PlaneSize;
  printf("block size:     %3d %3d %3d\n",Parameters.XDimPerBlock,Parameters.YDimPerBlock,Parameters.ZDimPerBlock);
  printf("blocks:         %3d %3d %3d\n",Parameters.XBlocks,Parameters.YBlocks,Parameters.ZBlocks);
  printf("problem:        %3d %3d %3d\n",Parameters.XDim,Parameters.YDim,Parameters.ZDim);
  printf("problem(ghost): %3d %3d %3d\n",Parameters.XDim+2,Parameters.YDim+2,Parameters.ZDim+2);
  printf("problem(pad):   %3d %3d %3d\n",Parameters.PencilSize,Parameters.YDim+2,Parameters.ZDim+2);
  printf("(Pencil,Plane,Volume) = %d %d %d\n",Parameters.PencilSize,Parameters.PlaneSize,Parameters.VolumeSize);


  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  printf("calculating frequency...");fflush(stdout);
  uint64_t t0 = CycleTime();
  sleep(1);
  uint64_t t1 = CycleTime();
  FrequencyGHz = (t1-t0)/1e9;
  printf("%0.3f GHz\n",FrequencyGHz);

  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  double *Grid_base[2];
  double *Grid[2];
  for(i=0;i<2;i++){
   printf("Allocating a grid of %ld bytes : (%d(unit) x %d x %d) grid\n",sizeof(double)*Parameters.VolumeSize,Parameters.PencilSize,Parameters.YDim+2,Parameters.ZDim+2);
   Grid_base[i] = (double*)malloc((Parameters.VolumeSize+0x10000)*sizeof(double));
   // now pad element 1,1,1 so that its cache line aligned
   uint64_t PaddingInDoubles = 0;
   while( ((uint64_t)(Grid_base[i] + Parameters.PlaneSize + Parameters.PencilSize + 1 + PaddingInDoubles)) & (0x10000-1) )PaddingInDoubles++;
   Grid[i] = Grid_base[i] + PaddingInDoubles;

   //printf("%016llx + %016llx -> %016llx\n",(uint64_t)Grid_base[i],PaddingInDoubles<<3,(uint64_t)Grid[i]);
   //printf("1,1,1 = %016llx\n",((uint64_t)(Grid_base[i] + Parameters.PlaneSize + Parameters.PencilSize + 1 + PaddingInDoubles)));
   //printf("1,1,1 = %016llx\n",((uint64_t)(Grid[i] + Parameters.PlaneSize + Parameters.PencilSize + 1)));
  };

  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  bench_pthreads(Grid[0],Grid[1]);
  free(Grid_base[0]);
  free(Grid_base[1]);
}
