// SpMV barrier routines
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

#include <stdio.h>
#include <stdlib.h>

//=================================================================================================================================
#if defined(USE_PTHREAD_BARRIER)
  #include <pthread.h>
  #define _REENTRANT
  #define barrier_t pthread_barrier_t
  #define barrier_init(barrier,count)  pthread_barrier_init(barrier,NULL,count)
  #define barrier_destroy(barrier)     pthread_barrier_destroy(barrier)
  #define barrier_wait(barrier,thread) pthread_barrier_wait(barrier)
#endif

//=================================================================================================================================
#if defined(EMULATE_PTHREAD_BARRIER)
  #include <pthread.h>
  #define _REENTRANT
  #define barrier_init(barrier,count)  mutex_barrier_init(barrier,count)
  #define barrier_destroy(barrier)     mutex_barrier_destroy(barrier)
  #define barrier_wait(barrier,thread) mutex_barrier_wait(barrier)

  typedef struct barrier_tag {
      pthread_mutex_t     lock[2];
      pthread_cond_t      cv[2];
      int                 ThreadsStillRunning[2];
      int                 WaitFor;
      int                 even;
  } barrier_t;

  // like the ones on docs.sun.com ================================================================
  void mutex_barrier_init(barrier_t *barrier, int count){
    int i;
    barrier->WaitFor=count;
    barrier->even=0;
    for(i=0;i<2;i++){
      barrier->ThreadsStillRunning[i]=count;
      pthread_mutex_init(&barrier->lock[i], NULL);
      pthread_cond_init(&barrier->cv[i], NULL);
    }
  }
  
  void mutex_barrier_destroy(barrier_t *barrier){
    int i;
    for(i=0;i<2;i++){
      pthread_mutex_destroy(&barrier->lock[i]);
      pthread_cond_destroy(&barrier->cv[i]);
    }
  }
  
  void mutex_barrier_wait(barrier_t *barrier){
    register int even = barrier->even;
    if(barrier->WaitFor==1)return;
    pthread_mutex_lock(&barrier->lock[even]);
    if(barrier->ThreadsStillRunning[even]==1){
      barrier->ThreadsStillRunning[even]=barrier->WaitFor;
      barrier->even^=1;
      pthread_cond_broadcast(&barrier->cv[even]);
    }else{
      barrier->ThreadsStillRunning[even]--;
      while(barrier->ThreadsStillRunning[even]!=barrier->WaitFor){ // i.e. last thread hasn't reset ThreadsStillRunning
        pthread_cond_wait(&barrier->cv[even], &barrier->lock[even]);
      }
    }
    pthread_mutex_unlock(&barrier->lock[even]);
  }
#endif

//=================================================================================================================================
#if defined(LOW_OVERHEAD_BARRIER)
  // the ones sumti @ sun provided (similar to Cell version)
  // Only one thread is responsible for releasing all threads (not the last to enter the barrier)
  #include <strings.h>
  #define barrier_init(barrier,count)  low_overhead_barrier_init(barrier,count)
  #define barrier_destroy(barrier)     low_overhead_barrier_destroy(barrier)
  #define barrier_wait(barrier,thread) low_overhead_barrier_wait(barrier,thread)

  typedef struct barrier_tag {
      volatile uint16_t ThreadIsWaiting[MaxThreads] __attribute__ ((aligned(64)));
               double                 x[MaxThreads] __attribute__ ((aligned(64)));
      int WaitFor;
  } barrier_t;

  void low_overhead_barrier_init(barrier_t *barrier, int count){
    int i;
    barrier->WaitFor=count;
    for(i=0;i<MaxThreads;i++){
      barrier->ThreadIsWaiting[i]=0;
      barrier->x[i]=2.0;
    }
  }

  void low_overhead_barrier_destroy(barrier_t *barrier){
  }

  void low_overhead_barrier_wait(barrier_t *barrier, int threadID){
    double x = 2.0;
    int i;
    if(barrier->WaitFor==1)return; // 1 thread waiting for itself

    barrier->ThreadIsWaiting[threadID] = 1; // threadID

    if(threadID==0){ // thread 0 is the master thread (it has sole write control on the barrier)
      int ThreadsWaiting = 0;
      while(ThreadsWaiting != barrier->WaitFor) { // not all threads are done
        //ThreadsWaiting = 0;for(i=0;i<MaxThreads;i++)ThreadsWaiting+=barrier->ThreadIsWaiting[i]; // how many threads are done
        ThreadsWaiting = 0;for(i=0;i<barrier->WaitFor;i++)ThreadsWaiting+=barrier->ThreadIsWaiting[i]; // how many threads are done
      }
      for(i=0;i<barrier->WaitFor;i++)barrier->ThreadIsWaiting[i]=0; // master thread now resets all other threads (same way PPE does it on cell)
      //for(i=0;i<MaxThreads;i++)barrier->ThreadIsWaiting[i]=0; // master thread now resets all other threads (same way PPE does it on cell)
      //memset((unsigned char*)barrier->ThreadIsWaiting, 0, sizeof(barrier->ThreadIsWaiting[0])*MaxThreads); // master thread now resets all other threads (same way PPE does it on cell)
      //bzero((unsigned char*)barrier->ThreadIsWaiting, MaxThreads); // master thread now resets all other threads (same way PPE does it on cell)
    }else{ // other threads just wait for the master thread to release them
      //while(barrier->ThreadIsWaiting[threadID]){} 
      //while(barrier->ThreadIsWaiting[threadID]){barrier->x[threadID]=1.0/barrier->x[threadID];} 
      while(barrier->ThreadIsWaiting[threadID]){x=1.0/x;} 
    }
  }
#endif
