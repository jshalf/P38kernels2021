// SpMV safe state initialization routines
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

void Init_SparseMatrix(SparseMatrix *SpA){
  SpA->CacheLineList=NULL;
  SpA->DMAList      =NULL;
  SpA->V            =NULL;
  SpA->P            =NULL;
  SpA->C16b         =NULL;
  SpA->C32b         =NULL;
  SpA->R16b         =NULL;
  SpA->R32b         =NULL;

  SpA->base0        =NULL;SpA->base0Size=0;
  SpA->base1        =NULL;SpA->base0Size=0;
}

void Init_BlockedSparseMatrix(BlockedSparseMatrix *BlockedSpA){
  int32_t i;
  for(i=0;i<MaxThreads;i++)BlockedSpA->tempY[i]=NULL;
  for(i=0;i<MaxThreads;i++)BlockedSpA->tempX[i]=NULL;
  BlockedSpA->blocks=NULL;
}
