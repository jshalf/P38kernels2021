//==================================================================================================================================
void (*kernels_bfRC[2][2][LOG_RegBlock_MaxR+1][LOG_RegBlock_MaxC+1])(SparseMatrix *, const double *__restrict__, const double *__restrict__, double *, int64_t, int64_t) =  // {16:32b}, {BCSR:BCOO}, logR, logC
{ 
  { // 16b sub array
    { // csr sub array
      {         &SpMV_b1x1_csr16b,         &SpMV_b1x2_csr16b,         &SpMV_b1x4_csr16b,         &SpMV_b1x8_csr16b  },
      {         &SpMV_b2x1_csr16b,         &SpMV_b2x2_csr16b,         &SpMV_b2x4_csr16b,         &SpMV_b2x8_csr16b  },
      {         &SpMV_b4x1_csr16b,         &SpMV_b4x2_csr16b,         &SpMV_b4x4_csr16b,         &SpMV_b4x8_csr16b  },
      {         &SpMV_b8x1_csr16b,         &SpMV_b8x2_csr16b,         &SpMV_b8x4_csr16b,         &SpMV_b8x8_csr16b  } 
    },
    { // coo sub array
      {         &SpMV_b1x1_coo16b,         &SpMV_b1x2_coo16b,         &SpMV_b1x4_coo16b,         &SpMV_b1x8_coo16b  },
      {         &SpMV_b2x1_coo16b,         &SpMV_b2x2_coo16b,         &SpMV_b2x4_coo16b,         &SpMV_b2x8_coo16b  },
      {         &SpMV_b4x1_coo16b,         &SpMV_b4x2_coo16b,         &SpMV_b4x4_coo16b,         &SpMV_b4x8_coo16b  },
      {         &SpMV_b8x1_coo16b,         &SpMV_b8x2_coo16b,         &SpMV_b8x4_coo16b,         &SpMV_b8x8_coo16b  } 
    } 
  },
  { // 32b sub array
    { // csr sub array
      {         &SpMV_b1x1_csr32b,         &SpMV_b1x2_csr32b,         &SpMV_b1x4_csr32b,         &SpMV_b1x8_csr32b  },
      {         &SpMV_b2x1_csr32b,         &SpMV_b2x2_csr32b,         &SpMV_b2x4_csr32b,         &SpMV_b2x8_csr32b  },
      {         &SpMV_b4x1_csr32b,         &SpMV_b4x2_csr32b,         &SpMV_b4x4_csr32b,         &SpMV_b4x8_csr32b  },
      {         &SpMV_b8x1_csr32b,         &SpMV_b8x2_csr32b,         &SpMV_b8x4_csr32b,         &SpMV_b8x8_csr32b  } 
    },
    { // coo sub array
      {         &SpMV_b1x1_coo32b,         &SpMV_b1x2_coo32b,         &SpMV_b1x4_coo32b,         &SpMV_b1x8_coo32b  },
      {         &SpMV_b2x1_coo32b,         &SpMV_b2x2_coo32b,         &SpMV_b2x4_coo32b,         &SpMV_b2x8_coo32b  },
      {         &SpMV_b4x1_coo32b,         &SpMV_b4x2_coo32b,         &SpMV_b4x4_coo32b,         &SpMV_b4x8_coo32b  },
      {         &SpMV_b8x1_coo32b,         &SpMV_b8x2_coo32b,         &SpMV_b8x4_coo32b,         &SpMV_b8x8_coo32b  } 
    } 
  } 
};
