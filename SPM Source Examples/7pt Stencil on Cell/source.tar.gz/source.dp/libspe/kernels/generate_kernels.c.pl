eval 'exec perl $0 $*'
        if 0;

$SSE=0;
$DoubleHummer=0;

$NumArgs = $#ARGV+1;

$ARGV0 = $ARGV[0];
$ARGV0 =~ tr/A-Z/a-z/;

if($NumArgs > 1){
  print "max one architecture per invocation - ./generate_kernels.pl [arch]\n";
  exit(0);
}

#                                                                       print "Generating c kernels in ./generic\n";
#if($NumArgs == 1){
#     if($ARGV0 eq "sse"         ){$PATH="./x86/";    $SSE          = 1;print "Generating sse kernels in ./x86\n";}
#  elsif($ARGV0 eq "doublehummer"){$PATH="./bgl/";    $DoubleHummer = 1;print "Generating double hummer kernels in ./bgl\n";}
#  else                           {print "unknown argument - $ARGV0\n";exit(0);}
#}
#
#if(!(-d $PATH)){
#  print "$PATH does not exist\n";
#  exit(0);
#}

$MaxU = 8;
#require "./collision.naive.pl";
#================================================================================
open(H,">./kernels.h");open(F,">./kernels.c");
for($GlobalO=0;$GlobalO<16;$GlobalO++){for($GlobalU=0;$GlobalU<$MaxU;$GlobalU++){$PTF[$GlobalO][$GlobalU]="NULL";}}
for($GlobalO=0;$GlobalO<16;$GlobalO++){for($GlobalU=0;$GlobalU<$MaxU;$GlobalU++){&kernels($GlobalO,$GlobalU,@PTF);}}
close(F);close(H);

#================================================================================
open(F,">./variables.c");
print F "#define    UNROLLINGS $MaxU\n";
print F "void (*Stencil_Plane[16][UNROLLINGS])() = {\n";
#print F "  {\n";
for($GlobalO=0;$GlobalO<16;$GlobalO++){print F"    {";
  for($GlobalU=0;$GlobalU<$MaxU;$GlobalU++){
    printf(F"%15s",     $PTF[$GlobalO][$GlobalU]);
    if($GlobalU!=$MaxU-1){print F ", ";}
  }print F "}";if($GlobalO!=15){print F",";}print F "\n";
}
#print F "  }\n";
print F "};\n";
close(F);
#================================================================================

# A = center
# B = faces
# G = edges
# D = vertices

# DGBA
# 0000 =  0
# 000x =  1
# 00x0 =  2
# 00xx =  3
# 0x00 =  4
# 0x0x =  5
# 0xx0 =  6
# 0xxx =  7
# x000 =  8
# x00x =  9
# x0x0 = 10
# x0xx = 11
# xx00 = 12
# xx0x = 13
# xxx0 = 14
# xxxx = 15

        

sub kernels{
  local($O,$U,@PTF)=@_;
  if($O!=3){return;}

  $BaseName =  "_stencil".$O."_u".$U;
  $PTF[$O][$U] = "&$BaseName";

  # heat equation
  print F "//====================================================================\n";
  print H "void $BaseName();\n";
  print F "void $BaseName(){\n";
  print F "  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n";
  print F "  //     0 1 2 3 4 5  \n";
  print F "  //       _    \n";  
  print F "  // 0   _|_|_  \n";
  for($y=1;$y<$MaxU+1;$y++){
  print F "  // $y  |_|_|_| \n";
  }
  print F "  // $y    |_|   \n";
  print F "  // z=0,1,2          \n";
  print F "  // t=  curr,next          \n";
  for($y=1;$y<$MaxU+1;$y++){print F "  double                curr_z0_y".$y."_x1;\n";}
  print F "\n";
                      $y=0;{print F "  double                curr_z1_y".$y."_x1;\n";}
  for($y=1;$y<$MaxU+1;$y++){print F "  double curr_z1_y".$y."_x0, curr_z1_y".$y."_x1, curr_z1_y".$y."_x2;\n";}
                $y=$MaxU+1;{print F "  double                curr_z1_y".$y."_x1;\n";}
  print F "\n";
  for($y=1;$y<$MaxU+1;$y++){print F "  double                curr_z2_y".$y."_x1;\n";}
  print F "\n";
  print F "  double* curr_z0_y0_x1_Pointer;\n";
  print F "  double* curr_z1_y0_x1_Pointer;\n";
  print F "  double* curr_z2_y0_x1_Pointer;\n";
  print F "  double* next_z1_y1_x1_Pointer;\n";
  print F "  uint32_t YOffset = 0, DeltaYOffset = 8*LocalPencilSize;\n";
  print F "\n";
  print F "  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~($MaxU-1);\n";
 #print F "  if(rank==0)printf(\"\%d\\n\",$U);\n";
  print F "  uint32_t x,y;\n";

  $max = 2;
  if($U==0){$max=1;}
  for($p=0;$p<$max;$p++){

  if($p==0){
  print F "  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
  print F "  for(y=0;y<floorCBYDim;y+=$MaxU){\n";
  $TempU = $MaxU;
  }else{
  print F "  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
  $TempU = $U;
  }

  print F "    curr_z0_y0_x1_Pointer = (double*)ReadZm1  + YOffset + 16 + 1;\n";
  print F "    curr_z1_y0_x1_Pointer = (double*)ReadZp0  + YOffset + 16 + 1;\n";
  print F "    curr_z2_y0_x1_Pointer = (double*)ReadZp1  + YOffset + 16 + 1;\n";
  print F "    next_z1_y1_x1_Pointer = (double*)WriteZp0 + YOffset      + 1;\n";

  print F "    for(x=0;x<Parameters.XDimPerBlock;x++){\n";

  # same z
  $y=       0;print F "      curr_z1_y".$y."_x1 = *(curr_z1_y0_x1_Pointer + ".$y."*LocalPencilSize   );\n";
  for($y=1;$y<$TempU+1;$y++){
              print F "      curr_z1_y".$y."_x0 = *(curr_z1_y0_x1_Pointer + ".$y."*LocalPencilSize -1);\n";
              print F "      curr_z1_y".$y."_x1 = *(curr_z1_y0_x1_Pointer + ".$y."*LocalPencilSize   );\n";
              print F "      curr_z1_y".$y."_x2 = *(curr_z1_y0_x1_Pointer + ".$y."*LocalPencilSize +1);\n";
  }
  $y=$TempU+1;print F "      curr_z1_y".$y."_x1 = *(curr_z1_y0_x1_Pointer + ".$y."*LocalPencilSize   );\n";
  print F "\n";

  # other z's
  for($y=1;$y<$TempU+1;$y++){
  print F "      curr_z0_y".$y."_x1 = *(curr_z0_y0_x1_Pointer + ".$y."*LocalPencilSize);\n";
  print F "      curr_z2_y".$y."_x1 = *(curr_z2_y0_x1_Pointer + ".$y."*LocalPencilSize);\n";
  }print F "\n";

  # stencils
  for($y=1;$y<$TempU+1;$y++){
  $ym = $y-1;
  $yp = $y+1;
  print F "      double next_z1_y".$y."_x1 = \n";
  print F "                          Parameters.Beta[0] *curr_z2_y".$y ."_x1 + /* z+1 */ \n";
  print F "                          Parameters.Beta[0] *curr_z0_y".$y ."_x1 + /* z-1 */ \n";
  print F "                          Parameters.Beta[0] *curr_z1_y".$yp."_x1 + /* y+1 */ \n";
  print F "                          Parameters.Beta[0] *curr_z1_y".$ym."_x1 + /* y-1 */ \n";
  print F "                          Parameters.Beta[0] *curr_z1_y".$y ."_x0 + /* x-1 */ \n";
  print F "                          Parameters.Beta[0] *curr_z1_y".$y ."_x2 + /* x+1 */ \n";
  print F "                          Parameters.Alpha[0]*curr_z1_y".$y ."_x1;\n\n";
  }print F "\n";

  # stores
  for($y=1;$y<$TempU+1;$y++){
  $ym = $y-1;
  print F "      *(next_z1_y1_x1_Pointer + ".$ym."*LocalPencilSize) = next_z1_y".$y."_x1;\n";
  }print F "\n";

  # increments
  print F "      curr_z0_y0_x1_Pointer++;\n";
  print F "      curr_z1_y0_x1_Pointer++;\n";
  print F "      curr_z2_y0_x1_Pointer++;\n";
  print F "      next_z1_y1_x1_Pointer++;\n";

  print F "    }\n";
  print F "    YOffset += DeltaYOffset;\n";

  if($p==0){
  print F "  }\n";
  }

  }

  print F "}\n";
}
