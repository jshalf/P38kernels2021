struct _CACHE_ALIGNMENT {  // Constants - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  double  Alpha[2];
  double   Beta[2];
  double  Delta[2];
  double  Gamma[2];
  // Problem Characteristics - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  uint32_t XDimPerBlock,YDimPerBlock,ZDimPerBlock;   // core of problem per thread
  uint32_t XBlocks,YBlocks,ZBlocks;   // blocks in each dimension
  uint32_t XDim,  YDim,  ZDim;   // core of entire problem
  uint32_t PencilSize, PlaneSize, VolumeSize;
  uint32_t NThreads;
  uint32_t BlocksPerChunk;
  uint32_t Compute;
  uint32_t DMA;
} Parameters _CACHE_ALIGNMENT;

// Benchmark Information - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
double FrequencyGHz=1.0;         
uint32_t AutoTune = 1;
uint32_t maxTrials = 10;
