eval 'exec perl $0 $*'
        if 0;

#$BITWISE=1;
#$FPType = "uint64_t";$FPZero = "(uint64_t)0";
$FPType = "double";$FPZero = "(double)0.0";


$CacheLineSizeBytes = 64;
$CacheLineSizeDoubles = $CacheLineSizeBytes/8;
$RMax=8;
$CMax=8;

open(H,">configure.h");
print H "//=====================================================================================================\n";
print H "#define MaxThreads             128\n";
print H "\n";
print H "#define PageEntriesAvailable   32\n";
print H "#define PageSizeInDoubles      10000000\n";
print H "\n";
print H "#define MaxStanzaLength        10000000\n";
print H "#define MaxStanzas             10000000\n";
print H "#define CacheLinesAvailable    1000\n";
print H "#define CacheLineSizeInDoubles $CacheLineSizeDoubles\n";
print H "\n";
print H "#define RegBlock_MinR          1\n";
print H "#define RegBlock_MinC          1\n";
print H "#define RegBlock_MaxR          $RMax\n";
print H "#define RegBlock_MaxC          $CMax\n";
print H "\n";
print H "#define PREFETCH_MIN_V            0\n";
print H "#define PREFETCH_MIN_C            0\n";
print H "#define PREFETCH_MAX_V          512\n";
print H "#define PREFETCH_MAX_C          128\n";
print H "\n";
print H "#define ENABLE_FORMATS         0x0003 // bit mask for formats\n";
print H "#define ENABLE_16b             1\n";
print H "\n";
print H "//#define EMULATE_PTHREAD_BARRIER\n";
print H "#define LOW_OVERHEAD_BARRIER\n";
print H "#define ENABLE_AFFINITY_VIA_SOLARIS\n";
close(H);


open(H,">kernels.csr.h");
open(F,">kernels.csr.c");
for($GlobalR=1;$GlobalR<=$RMax;$GlobalR*=2){
  for($GlobalC=1;$GlobalC<=$CMax;$GlobalC*=2){
    for($bits=16;$bits<=32;$bits*=2){
      &CSR_RxC_bits_optimized($GlobalR,$GlobalC,"$bits");
}}}
print F "//==================================================================================================================================\n";
close(F);
close(H);

open(H,">kernels.coo.h");
open(F,">kernels.coo.c");
for($GlobalR=1;$GlobalR<=$RMax;$GlobalR*=2){
  for($GlobalC=1;$GlobalC<=$CMax;$GlobalC*=2){
    for($bits=16;$bits<=32;$bits*=2){
      &COO_RxC_bits_optimized($GlobalR,$GlobalC,"$bits");
}}}
print F "//==================================================================================================================================\n";
close(F);
close(H);



open(F,">variables.c");
print F "//==================================================================================================================================\n";
print F "void (*kernels_bfRC[2][2][LOG_RegBlock_MaxR+1][LOG_RegBlock_MaxC+1])(SparseMatrix *, const double *__restrict__, const double *__restrict__, double *, int64_t, int64_t) =  // {16:32b}, {BCSR:BCOO}, logR, logC\n";
print F "{ \n";
for($bits=16,$logbits=0;$bits<=32;$bits*=2,$logbits++){
  print F "  { // $bits"."b sub array\n";
  for($f=0;$f<=1;$f++){
    if($f==0){$format="csr";}
    if($f==1){$format="coo";}
    print F "    { // $format sub array\n";
    for($r=1,$logr=0;$r<=8;$r*=2,$logr++){
      print F "      { ";
      for($c=1,$logc=0;$c<=8;$c*=2,$logc++){
           if(($r>$RMax)||($c>$CMax)){printf(F "%25s","NULL");}
        elsif($f==0){                 printf(F "%25s","&SpMV_b$r"."x"."$c"."_$format".$bits."b");}
        elsif($f==1){                 printf(F "%25s","&SpMV_b$r"."x"."$c"."_$format".$bits."b");}
        elsif($f> 1){                 printf(F "%25s","NULL");}
        if($c==8){print F "  ";}
             else{print F ", ";}
      }
      if($r==8){print F "} \n";}
           else{print F "},\n";}
    }
    if($f==1){print F "    } \n";}
         else{print F "    },\n";}
  }
  if($bits==32){print F "  } \n";}
           else{print F "  },\n";}
}
print F "};\n";
close(F);



#================================================================================
#
#================================================================================
sub CSR_RxC_bits_optimized{
  local($R,$C,$bits)=@_;


  $RC = $R*$C;



print F "//==================================================================================================================================\n";
                                                  print H "void SpMV_b$R"."x"."$C"."_csr".$bits."b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C);\n";
                                                  print F "void SpMV_b$R"."x"."$C"."_csr".$bits."b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){\n";
                                                  print F "  const $FPType * __restrict__ XRelative = ($FPType *)X + SpA->COffset;\n";
                                                  print F "  const $FPType * __restrict__ ZRelative = ($FPType *)Z + SpA->ROffset;\n";
                                                  print F "        $FPType * __restrict__ YRelative = ($FPType *)Y + SpA->ROffset;\n";
                                                  print F "  const uint32_t * __restrict__ P = SpA->P;\n";
                                                  print F "  const $FPType * __restrict__ V = ($FPType *)SpA->V;\n";
                                                  print F "  const uint".$bits."_t * __restrict__ C = SpA->C".$bits."b;\n";
                                                 #print F "  const uint".$bits."_t * __restrict__ R = SpA->R".$bits."b;\n";
                                                  print F "  const uint64_t MaxCofs = SpA->NTiles;\n";
                                                  print F "  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;\n";
                                                  print F "  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;\n";
                                                  print F "  uint64_t row = SpA->FirstRow;\n";
                                                  print F "  uint64_t Cofs = 0;\n";
                                                  print F "  uint64_t Rofs = 0;\n";
						  print F "\n";
						  print F "  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector\n";
						  print F "    if(Z==NULL)while(Rofs<$R*SpA->FirstRow){\n";
                            for($r=0;$r<$R;$r+=1){print F "      YRelative[Rofs+$r]=$FPZero;\n";}
                                                  print F "      Rofs+=$R;\n";
                                                  print F "    }\n";
                                                  print F "    else while(Rofs<$R*SpA->FirstRow){\n";
                            for($r=0;$r<$R;$r+=1){print F "      YRelative[Rofs+$r]=ZRelative[Rofs+$r];\n";}
                                                  print F "      Rofs+=$R;\n";
						  print F "    }\n";
						  print F "  }\n";
                                                  print F "  Rofs = $R*SpA->FirstRow;\n";
						  print F "\n";
						  print F "\n";

for($PREFETCH_C=0;$PREFETCH_C<2;$PREFETCH_C++){
for($PREFETCH_V=0;$PREFETCH_V<2;$PREFETCH_V++){
if(($PREFETCH_V==1) || ($PREFETCH_C==0)){
     if(($PREFETCH_C==0)&&($PREFETCH_V==0)){	  print F "  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch\n";}
  elsif(($PREFETCH_C==0)&&($PREFETCH_V==1)){	  print F "  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V\n";}
  elsif(($PREFETCH_C==1)&&($PREFETCH_V==1)){	  print F "  else {                                                                                     // PREFETCH_CV\n";}

for($Z=0;$Z<2;$Z++){
  if($Z==0){					  print F "    if(Z==NULL){                                                                   // Z=Ax branch\n";
  }else{					  print F "    else{                                                                          // Z=Ax+Y branch\n";
  }
                                                  print F "      while(Cofs<MaxCofs){                                                         // for all nonzeros{\n";
  if($Z){
                            for($r=0;$r<$R;$r+=1){print F "        $FPType y".$r."=ZRelative[$r+Rofs];                                             //   initialize vector\n";}
  }else{
                            for($r=0;$r<$R;$r+=1){print F "        $FPType y".$r."= $FPZero;                                                  //   initialize vector\n";}
  }
                                                  print F "        while(Cofs<P[row+1]){                                                      //   for all nonzeros left in the row\n";
################################################  print F "          PREFETCH((void*)XRelative[C[10+Cofs]]);\n";
  if($PREFETCH_C){                                print F "          PREFETCH_NT(  PREFETCH_C+(void*)(&C[Cofs]));   //     prefetch column index into L1, don't evict to L2\n";}
  $vofs=0;$vofsByte=0;
  for($c=0;$c<$C;$c++){
                                                  print F "          const $FPType X".$c." = XRelative[$c+C[Cofs]];                                //     load a value of X\n";
  }
  $vofs=0;$vofsByte=0;
  for($c=0;$c<$C;$c++){
    for($r=0;$r<$R;$r+=1){
      if(($PREFETCH_V)&&(($vofsByte%$CacheLineSizeBytes)==0)){print F "          PREFETCH_NT($vofsByte+PREFETCH_V+(void*)&V[0]);  //     prefetch matrix values into L1, don't evict to L2\n";}
                                     if($BITWISE){print F "          y".$r." |= V[$vofs]&X".$c.";                                                      //\n";}
                                             else{print F "          y".$r." += V[$vofs]*X".$c.";                                                      //\n";}
      $vofs++;$vofsByte+=8;
  }}
                                                  print F "          V+=$RC;                                                                 //     increment offset in V\n";
                                                  print F "          Cofs++;                                                                  //     increment offset in C\n";
                                                  print F "        }                                                                          //   }\n";
                            for($r=0;$r<$R;$r+=1){print F "        YRelative[$r+Rofs]=y".$r.";                                                      //   store vector\n";}
                                                  print F "        Rofs+=$R;                                                                   //   increment offset in Y,Z\n";
                                                  print F "        row++;                                                                     //   increment row\n";
                                                  print F "      }                                                                            // }\n";
                                                  print F "    }\n";
} # for z
                                                  print F "  }\n";
}}}
                                                  print F "\n";
						  print F "  if(SpA->InitY){  // if on the first cache block, must initialize the remaining elements of the destination vector\n";
						  print F "    if(Z==NULL)while(Rofs<SpA->NRows){\n";
                            for($r=0;$r<$R;$r+=1){print F "      YRelative[Rofs+$r]=$FPZero;\n";} 
                                                  print F "      Rofs+=$R;\n"; 
                                                  print F "    }\n";
                                                  print F "    else while(Rofs<SpA->NRows){\n";                                                    
                            for($r=0;$r<$R;$r+=1){print F "      YRelative[Rofs+$r]=ZRelative[Rofs+$r];\n";}
                                                  print F "      Rofs+=$R;\n";
						  print F "    }\n";
						  print F "  }\n";
						  print F "\n";
                                                  print F "}\n\n";
} # function

#================================================================================
#
#================================================================================
sub COO_RxC_bits_optimized{
  local($R,$C,$bits)=@_;


  $RC = $R*$C;



print F "//==================================================================================================================================\n";
                                                  print H "void SpMV_b$R"."x"."$C"."_coo".$bits."b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C);\n";
                                                  print F "void SpMV_b$R"."x"."$C"."_coo".$bits."b(SparseMatrix *SpA, const double * __restrict__ X, const double * __restrict__ Z, double * __restrict__ Y, int64_t OverridePrefetch_V, int64_t OverridePrefetch_C){\n";
                                                  print F "  const $FPType * __restrict__ XRelative = ($FPType *)X + SpA->COffset;\n";
                                                  print F "  const $FPType * __restrict__ ZRelative = ($FPType *)Z + SpA->ROffset;\n";
                                                  print F "        $FPType * __restrict__ YRelative = ($FPType *)Y + SpA->ROffset;\n";
                                                  print F "  const $FPType * __restrict__ V = ($FPType *)SpA->V;\n";
                                                  print F "  const uint".$bits."_t * __restrict__ C = SpA->C".$bits."b;\n";
                                                  print F "  const uint".$bits."_t * __restrict__ R = SpA->R".$bits."b;\n";
                                                  print F "  const uint64_t MaxRCofs = SpA->NTiles;\n";
                                                  print F "  uint64_t PREFETCH_V = OverridePrefetch_V;if(OverridePrefetch_V<0)PREFETCH_V=256;\n";
                                                  print F "  uint64_t PREFETCH_C = OverridePrefetch_C;if(OverridePrefetch_C<0)PREFETCH_C= 64;\n";
                                                  print F "  uint64_t RCofs = 0;\n";
						  print F "\n";
						  print F "  if(SpA->InitY){  // if on the first cache block, must initialize the all elements of the destination vector\n";
						  print F "    uint64_t row;\n";
                                                  print F "    if(Z==NULL)for(row=0;row<SpA->NRows;row+=$R){\n";
                            for($r=0;$r<$R;$r+=1){print F "      YRelative[row+$r]=$FPZero;\n";}
                                                  print F "    }\n";
                                                  print F "    else for(row=0;row<SpA->NRows;row+=$R){\n";
                            for($r=0;$r<$R;$r+=1){print F "      YRelative[row+$r]=ZRelative[row+$r];\n";}
						  print F "    }\n";
						  print F "  }\n";
						  print F "\n";
						  print F "\n";

for($PREFETCH_C=0;$PREFETCH_C<2;$PREFETCH_C++){
for($PREFETCH_V=0;$PREFETCH_V<2;$PREFETCH_V++){
if(($PREFETCH_V==1) || ($PREFETCH_C==0)){
     if(($PREFETCH_C==0)&&($PREFETCH_V==0)){	  print F "  if(!PREFETCH_C && !PREFETCH_V){                                                  // no prefetch\n";}
  elsif(($PREFETCH_C==0)&&($PREFETCH_V==1)){	  print F "  else if(!PREFETCH_C &&  PREFETCH_V){                                             // PREFETCH_V\n";}
  elsif(($PREFETCH_C==1)&&($PREFETCH_V==1)){	  print F "  else {                                                                                     // PREFETCH_CV\n";}

for($Z=1;$Z<2;$Z++){
                                                  print F "      while(RCofs<MaxRCofs){                                                       // for all nonzeros{\n";
                                                  print F "        uint64_t row = R[RCofs];                                                   // row (64b?)\n";
  if($Z){
                            for($r=0;$r<$R;$r+=1){print F "        $FPType y".$r."=YRelative[$r+row];                                              //   initialize vector\n";}
  }else{
                            for($r=0;$r<$R;$r+=1){print F "        $FPType y".$r."=$FPZero;                                                   //   initialize vector\n";}
  }
                                                  print F "        do{                                                                        //   for all nonzeros left in the row\n";
  if($PREFETCH_C){                                print F "          PREFETCH_NT(  PREFETCH_C+(void*)(&R[RCofs]));  //     prefetch column index into L1, don't evict to L2\n";}
  if($PREFETCH_C){                                print F "          PREFETCH_NT(  PREFETCH_C+(void*)(&C[RCofs]));  //     prefetch column index into L1, don't evict to L2\n";}
  $vofs=0;$vofsByte=0;
  for($c=0;$c<$C;$c++){
                                                  print F "          const $FPType X".$c." = XRelative[$c+C[RCofs]];                               //     load a value of X\n";
  }
  $vofs=0;$vofsByte=0;
  for($c=0;$c<$C;$c++){
    for($r=0;$r<$R;$r+=1){
      if(($PREFETCH_V)&&(($vofsByte%$CacheLineSizeBytes)==0)){print F "          PREFETCH_NT($vofsByte+PREFETCH_V+(void*)&V[0]);  //     prefetch matrix values into L1, don't evict to L2\n";}
                                     if($BITWISE){print F "          y".$r." |= V[$vofs]&X".$c.";                                                      //\n";}
                                             else{print F "          y".$r." += V[$vofs]*X".$c.";                                                      //\n";}
      $vofs++;$vofsByte+=8;
  }}
                                                  print F "          V+=$RC;                                                                 //     increment offset in V\n";
                                                  print F "          RCofs++;                                                                 //     increment offset in R&C\n";
                                                  print F "        }while( (row==R[RCofs]) );                                                 //   }\n";
                            for($r=0;$r<$R;$r+=1){print F "        YRelative[$r+row]=y".$r.";                                                       //   store vector\n";}
                                                  print F "      }                                                                            // }\n";
} # for z
                                                  print F "  }\n";
}}}
                                                  print F "}\n\n";



} # function
