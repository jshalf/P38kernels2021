#include <spu_mfcio.h>
#include <stdio.h>
#include <stdio.h>
#include <stdint.h>
//==============================================================================================================================
#define DMATag_Buf0         0
#define DMATag_Buf1         1
#define DMATag_LoadX        2
#define DMATag_LoadZ        3
#define DMATag_StoreY       4
#define DMATag_DMAList0     5
#define DMATag_DMAList1     6
#define DMATag_CacheBlock0  7
#define DMATag_CacheBlock1  8
#define DMATag_CacheBlock2  9
#define DMATag_BlockedSpA  10
#define DMATag_args        11
//==============================================================================================================================
const vector        double DPZeroQW         = {(double)0.0,(double)0.0};
const vector unsigned char ZeroQW           = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
const vector unsigned char ByteCountQW      = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07, 0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07};

const vector unsigned char ReplicateByte0QW = {0x00, 0x00, 0x00,0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
const vector unsigned char ReplicateByte1QW = {0x01, 0x01, 0x01,0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01};
const vector unsigned char ReplicateByte2QW = {0x02, 0x02, 0x02,0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02};
const vector unsigned char ReplicateByte3QW = {0x03, 0x03, 0x03,0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03};

const vector unsigned char ReplicateHalf0QW = {0x00,0x01,  0x00,0x01,  0x00,0x01,  0x00,0x01,  0x00,0x01,  0x00,0x01,  0x00,0x01,  0x00,0x01};
const vector unsigned char ReplicateHalf1QW = {0x02,0x03,  0x02,0x03,  0x02,0x03,  0x02,0x03,  0x02,0x03,  0x02,0x03,  0x02,0x03,  0x02,0x03};
const vector unsigned char ReplicateHalf2QW = {0x04,0x05,  0x04,0x05,  0x04,0x05,  0x04,0x05,  0x04,0x05,  0x04,0x05,  0x04,0x05,  0x04,0x05};
const vector unsigned char ReplicateHalf3QW = {0x06,0x07,  0x06,0x07,  0x06,0x07,  0x06,0x07,  0x06,0x07,  0x06,0x07,  0x06,0x07,  0x06,0x07};
const vector unsigned char ReplicateHalf4QW = {0x08,0x09,  0x08,0x09,  0x08,0x09,  0x08,0x09,  0x08,0x09,  0x08,0x09,  0x08,0x09,  0x08,0x09};
const vector unsigned char ReplicateHalf5QW = {0x0A,0x0B,  0x0A,0x0B,  0x0A,0x0B,  0x0A,0x0B,  0x0A,0x0B,  0x0A,0x0B,  0x0A,0x0B,  0x0A,0x0B};
const vector unsigned char ReplicateHalf6QW = {0x0C,0x0D,  0x0C,0x0D,  0x0C,0x0D,  0x0C,0x0D,  0x0C,0x0D,  0x0C,0x0D,  0x0C,0x0D,  0x0C,0x0D};
const vector unsigned char ReplicateHalf7QW = {0x0E,0x0F,  0x0E,0x0F,  0x0E,0x0F,  0x0E,0x0F,  0x0E,0x0F,  0x0E,0x0F,  0x0E,0x0F,  0x0E,0x0F};

const vector unsigned char ReplicateWord0QW = {0x00,0x01,0x02,0x03,  0x00,0x01,0x02,0x03,  0x00,0x01,0x02,0x03,  0x00,0x01,0x02,0x03};
const vector unsigned char ReplicateWord1QW = {0x04,0x05,0x06,0x07,  0x04,0x05,0x06,0x07,  0x04,0x05,0x06,0x07,  0x04,0x05,0x06,0x07};
const vector unsigned char ReplicateWord2QW = {0x08,0x09,0x0A,0x0B,  0x08,0x09,0x0A,0x0B,  0x08,0x09,0x0A,0x0B,  0x08,0x09,0x0A,0x0B};
const vector unsigned char ReplicateWord3QW = {0x0C,0x0D,0x0E,0x0F,  0x0C,0x0D,0x0E,0x0F,  0x0C,0x0D,0x0E,0x0F,  0x0C,0x0D,0x0E,0x0F};

const vector unsigned char ReplicateDouble0QW = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,  0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07};
const vector unsigned char ReplicateDouble1QW = {0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,  0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F};
//==============================================================================================================================
#define _BEST_ALIGNMENT __attribute__ ((aligned(128)))
#define BUFFER_SIZE 1024
//==============================================================================================================================
#include "../include/configure.h"
#include "../../common/defines.h"
#include "../../common/types.h"
#include "../include/kernels.coo.h"
#include "../include/variables.c"
#include "../include/kernels.coo.c"
//==============================================================================================================================
volatile               uint32_t MyLock[32]                __attribute__ ((aligned(128)));
volatile               qword Heap[CacheLinesAvailable<<3] __attribute__ ((aligned(128)));
volatile                 double Local_V[2][BUFFER_SIZE]   __attribute__ ((aligned(128))); // nonzero values
volatile               uint16_t Local_R[2][BUFFER_SIZE]   __attribute__ ((aligned(128))); // nonzero row indices
volatile               uint16_t Local_C[2][BUFFER_SIZE]   __attribute__ ((aligned(128))); // nonzero column indices
volatile BlockedSparseMatrix BlockedSpA                   __attribute__ ((aligned(128)));
volatile        SparseMatrix CacheBlocks[3]               __attribute__ ((aligned(128))); // current, next, one after next
volatile      DMAListElement XLists[2][MaxStanzas]        __attribute__ ((aligned(128))); // current, next
volatile      DMAListElement YList[32]                    __attribute__ ((aligned(128)));
volatile            uint64_t pthread_args[16]             __attribute__ ((aligned(128)));
//==============================================================================================================================
uint32_t minTrials       = 0; // pthread_args[2]
uint32_t MyRank          = 0; // pthread_args[3]
uint32_t DRAM_BlockedSpA = 0; // pthread_args[4]
uint32_t DRAM_X          = 0; // pthread_args[5]
uint32_t DRAM_Y          = 0; // pthread_args[6]
uint32_t DRAM_Z          = 0; // pthread_args[7]

volatile        double * Local_X; // pointer into heap
volatile        double * Local_Y; // pointer into heap
volatile unsigned long * Local_P; // pointer into heap

int32_t Current_DMAList,Next_DMAList; // indices : [0,1]
int32_t Current_CacheBlock,Next_CacheBlock,CacheBlock_After_Next; // indices : [0,1,2]

uint32_t WaitMask = 0;

//==============================================================================================================================
//
//  +-----+
//  | B+2 |
//  +-----+-----+
//  | B+1 | L+1 |
//  +-----+-----+-----------+
//  |  B  |  L  | X,buf,... |
//  +-----+-----+-----------+
//
//  wait for B+2, L+1, X,buf,....
//
// misc functions ==============================================================================================================
//#define roundTo16(a)  ((((a)+ 15)>>4)<<4)
//#define roundTo128(a) ((((a)+127)>>7)<<7)
#define roundTo(a,bits) ((((a)+(1<<(bits))-1)>>(bits))<<(bits))
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)>(b)?(b):(a))
//==============================================================================================================================
inline uint32_t AppendDMAList(DMAListElement *List, uint32_t EAL, uint32_t size){
  uint32_t stanzas = 0;
  while(size>16384){List[stanzas].Size = 16384;List[stanzas].EAL = EAL;stanzas++;size-=16384;EAL+=16384;}
                    List[stanzas].Size =  size;List[stanzas].EAL = EAL;stanzas++;
  return(stanzas);
}

inline void barrier(){
        MyLock[0] =1;
  while(MyLock[0]==1);
}

inline void InitY_R16(uint32_t NRows){
  uint32_t i;
  uint32_t WriteByteAddress = 0;
  
  double *Yp000 = (double *)Local_Y+ 0;
  double *Yp016 = (double *)Local_Y+ 2;
  double *Yp032 = (double *)Local_Y+ 4;
  double *Yp048 = (double *)Local_Y+ 6;
  double *Yp064 = (double *)Local_Y+ 8;
  double *Yp080 = (double *)Local_Y+10;
  double *Yp096 = (double *)Local_Y+12;
  double *Yp112 = (double *)Local_Y+14;

  for(i=0;i<NRows;i+=16){
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp000),si_from_uint(WriteByteAddress));
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp016),si_from_uint(WriteByteAddress));
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp032),si_from_uint(WriteByteAddress));
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp048),si_from_uint(WriteByteAddress));
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp064),si_from_uint(WriteByteAddress));
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp080),si_from_uint(WriteByteAddress));
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp096),si_from_uint(WriteByteAddress));
    si_stqx((qword)DPZeroQW,si_from_ptr(Yp112),si_from_uint(WriteByteAddress));
    WriteByteAddress += 128;
  } 
}

void SpMV_MyPart_SingleCacheBlock(uint32_t InitY, uint32_t LoadZ, uint32_t StoreY){
  uint32_t LogTileValueSize = 3+CacheBlocks[Current_CacheBlock].logR+CacheBlocks[Current_CacheBlock].logC;
  uint32_t LogTileRCSize    = 1;
  int32_t CurrentValueBuffer = 0;int32_t    NextValueBuffer = 1;
  int32_t CurrentRCBuffer    = 0;int32_t    NextRCBuffer    = 1;
  int32_t MaxTilesInValueBuffer = BUFFER_SIZE >> CacheBlocks[Current_CacheBlock].logR >> CacheBlocks[Current_CacheBlock].logC;
  int32_t MaxTilesInRCBuffer    = BUFFER_SIZE;
  int32_t TilesLeft            = CacheBlocks[Current_CacheBlock].NTiles;
  int32_t TilesLeftInValueDRAM = CacheBlocks[Current_CacheBlock].NTiles;
  int32_t TilesLeftInRCDRAM    = CacheBlocks[Current_CacheBlock].NTiles;
  int32_t TilesLeftInNextValueBuffer    = 0;
  int32_t TilesLeftInNextRCBuffer       = 0;
  int32_t TilesLeftInCurrentValueBuffer = 0;
  int32_t TilesLeftInCurrentRCBuffer    = 0;
  uint32_t CurrentOffsetInValueBuffer   = 0;
  uint32_t CurrentOffsetInRCBuffer      = 0;
  uint32_t DRAM_V = (uint32_t)CacheBlocks[Current_CacheBlock].V;
  uint32_t DRAM_R = (uint32_t)CacheBlocks[Current_CacheBlock].R16b;
  uint32_t DRAM_C = (uint32_t)CacheBlocks[Current_CacheBlock].C16b;
  
  // initiate load of first buffers(V,R,C) worth of nonzeros
  TilesLeftInNextValueBuffer = min(TilesLeftInValueDRAM,MaxTilesInValueBuffer);
  TilesLeftInNextRCBuffer    = min(TilesLeftInRCDRAM   ,MaxTilesInRCBuffer   );
  TilesLeftInValueDRAM-=TilesLeftInNextValueBuffer;
  TilesLeftInRCDRAM   -=TilesLeftInNextRCBuffer   ;
  spu_mfcdma32((void*)&Local_V[NextValueBuffer][0],DRAM_V,roundTo(TilesLeftInNextValueBuffer<<LogTileValueSize,7),DMATag_Buf0+NextValueBuffer,MFC_GET_CMD);
  spu_mfcdma32((void*)&Local_R[   NextRCBuffer][0],DRAM_R,roundTo(TilesLeftInNextRCBuffer   <<LogTileRCSize   ,7),DMATag_Buf0+   NextRCBuffer,MFC_GET_CMD);
  spu_mfcdma32((void*)&Local_C[   NextRCBuffer][0],DRAM_C,roundTo(TilesLeftInNextRCBuffer   <<LogTileRCSize   ,7),DMATag_Buf0+   NextRCBuffer,MFC_GET_CMD);
  DRAM_V+=TilesLeftInNextValueBuffer<<LogTileValueSize;
  DRAM_R+=TilesLeftInNextRCBuffer   <<LogTileRCSize   ;
  DRAM_C+=TilesLeftInNextRCBuffer   <<LogTileRCSize   ;
  WaitMask |= 1<<(DMATag_Buf0+NextValueBuffer);
  WaitMask |= 1<<(DMATag_Buf0+   NextRCBuffer);
  // wait for store of: Y (may fall thru) - can't initiate new X gets until this finishes since heap partitioning might change
  if(InitY || LoadZ){mfc_write_tag_mask(1<<DMATag_StoreY);mfc_read_tag_status_all();}
  // initiate load of: X@list
  uint32_t i;for(i=0;i<CacheBlocks[Current_CacheBlock].DMAStanzas;i++)XLists[Current_DMAList][i].EAL+=DRAM_X; // FIX !!! - Make calculation of EAL Faster
  spu_mfcdma32((void*)&Local_X[0],(uint32_t)&XLists[Current_DMAList][0],CacheBlocks[Current_CacheBlock].DMAStanzas<<3,DMATag_LoadX,MFC_GETL_CMD);
  WaitMask |= 1<<(DMATag_LoadX);
  // now double buffer and process nonzeros
  while(TilesLeft>0){
    // if(Z needs to be loaded) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    if(LoadZ){
    }
    // if(Y needs to be initialized) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    if(InitY){
      InitY_R16(CacheBlocks[Current_CacheBlock].NRows);
      InitY=0;
    }
    // wait for DMAs to finish - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(TilesLeftInCurrentValueBuffer<=0)WaitMask |= 1<<(DMATag_Buf0+NextValueBuffer);
    if(TilesLeftInCurrentRCBuffer   <=0)WaitMask |= 1<<(DMATag_Buf0+NextRCBuffer   );
    mfc_write_tag_mask(WaitMask);mfc_read_tag_status_all();WaitMask=0;
    // if current value buffer is empty, swap pointers, and initiate new get - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    if(TilesLeftInCurrentValueBuffer<=0){ 
      CurrentValueBuffer^=1;
         NextValueBuffer^=1;
      TilesLeftInCurrentValueBuffer = TilesLeftInNextValueBuffer;
      CurrentOffsetInValueBuffer=0;
      if(TilesLeftInValueDRAM>0){
        TilesLeftInNextValueBuffer = min(TilesLeftInValueDRAM,MaxTilesInValueBuffer);
        TilesLeftInValueDRAM-=TilesLeftInNextValueBuffer;
        spu_mfcdma32((void*)&Local_V[NextValueBuffer][0],DRAM_V,roundTo(TilesLeftInNextValueBuffer<<LogTileValueSize,7),DMATag_Buf0+NextValueBuffer,MFC_GET_CMD);
        DRAM_V+=TilesLeftInNextValueBuffer<<LogTileValueSize;
      }
    }
    // if current RC buffer is empty, swap pointers, and initiate new get - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    if(TilesLeftInCurrentRCBuffer<=0){ 
      CurrentRCBuffer^=1;
         NextRCBuffer^=1;
      TilesLeftInCurrentRCBuffer = TilesLeftInNextRCBuffer;
      CurrentOffsetInRCBuffer=0;
      if(TilesLeftInRCDRAM>0){
        TilesLeftInNextRCBuffer = min(TilesLeftInRCDRAM,MaxTilesInRCBuffer);
        TilesLeftInRCDRAM-=TilesLeftInNextRCBuffer;
        spu_mfcdma32((void*)&Local_R[NextRCBuffer][0],DRAM_R,roundTo(TilesLeftInNextRCBuffer<<LogTileRCSize,7),DMATag_Buf0+NextRCBuffer,MFC_GET_CMD);
        spu_mfcdma32((void*)&Local_C[NextRCBuffer][0],DRAM_C,roundTo(TilesLeftInNextRCBuffer<<LogTileRCSize,7),DMATag_Buf0+NextRCBuffer,MFC_GET_CMD);
        DRAM_R+=TilesLeftInNextRCBuffer<<LogTileRCSize;
        DRAM_C+=TilesLeftInNextRCBuffer<<LogTileRCSize;
      }
    }
    // now process nonzeros in buffer - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    //printf("spu%02d: processing - offsets=%08lx,%08lx\n",MyRank,(uint32_t)(Local_R[CurrentRCBuffer   ]+CurrentOffsetInRCBuffer),(uint32_t)(Local_C[CurrentRCBuffer   ]+CurrentOffsetInRCBuffer));
    //printf("spu%02d: processing - Bits=%4d, Format=%4d, logR=%d, logC=%d\n",MyRank,CacheBlocks[Current_CacheBlock].Bits,CacheBlocks[Current_CacheBlock].Format,CacheBlocks[Current_CacheBlock].logR,CacheBlocks[Current_CacheBlock].logC);

    
    kernels_bfRC[CacheBlocks[Current_CacheBlock].Bits][CacheBlocks[Current_CacheBlock].Format][CacheBlocks[Current_CacheBlock].logR][CacheBlocks[Current_CacheBlock].logC](
      TilesLeftInCurrentValueBuffer,
      (const   double *)Local_V[CurrentValueBuffer]+CurrentOffsetInValueBuffer,
      (const uint16_t *)Local_R[CurrentRCBuffer   ]+CurrentOffsetInRCBuffer,
      (const uint16_t *)Local_C[CurrentRCBuffer   ]+CurrentOffsetInRCBuffer,
      (const   double *)Local_X,
      (        double *)Local_Y
    );
    
     
    // empty buffers - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    CurrentOffsetInValueBuffer   +=BUFFER_SIZE;
    CurrentOffsetInRCBuffer      +=MaxTilesInValueBuffer;
    TilesLeft                    -=MaxTilesInValueBuffer;
    TilesLeftInCurrentValueBuffer-=MaxTilesInValueBuffer;
    TilesLeftInCurrentRCBuffer   -=MaxTilesInValueBuffer;
  }
  if(StoreY){
    uint32_t DRAM_WorkingY = DRAM_Y;
    if(BlockedSpA.CThreads>1)DRAM_WorkingY = (uint32_t)BlockedSpA.tempY[MyRank];
    uint32_t YStanzas = AppendDMAList((DMAListElement*)YList,DRAM_WorkingY+(CacheBlocks[Current_CacheBlock].ROffset<<3),(CacheBlocks[Current_CacheBlock].NRows<<3));
    spu_mfcdma32((void*)&Local_Y[0],(uint32_t)&YList[0],YStanzas<<3,DMATag_StoreY,MFC_PUTL_CMD);
  }
}

void SpMV_MyPart(){
  Current_DMAList=0;
     Next_DMAList=1;

  Current_CacheBlock           =0;
     Next_CacheBlock           =1;
          CacheBlock_After_Next=2;

  int32_t b;
  int32_t bStart = BlockedSpA.FirstBlockForThread[MyRank  ];
  int32_t bEnd   = BlockedSpA.FirstBlockForThread[MyRank+1];

  uint32_t LastRowOffset = 0xFFFFFFFF;
  //printf("spu%02d: block %d..%d\n",MyRank,bStart,bEnd);
  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(b=bStart;b<(bEnd+2);b++){
    WaitMask = 0;

    if((b>=bStart  )&&(b<bEnd  )){ // load block after next
      spu_mfcdma32((void *)&CacheBlocks[CacheBlock_After_Next],((uint32_t)BlockedSpA.blocks)+b*sizeof(SparseMatrix),sizeof(SparseMatrix),DMATag_CacheBlock0+CacheBlock_After_Next,MFC_GET_CMD);
      WaitMask |= 1<<(DMATag_CacheBlock0+CacheBlock_After_Next);
    }

    if((b>=bStart+1)&&(b<bEnd+1)){ // load next list from next cache block
      spu_mfcdma32((void *)&XLists[Next_DMAList],((uint32_t)CacheBlocks[Next_CacheBlock].DMAList),roundTo(CacheBlocks[Next_CacheBlock].DMAStanzas<<3,4),DMATag_DMAList0+Next_DMAList,MFC_GET_CMD);
      WaitMask |= 1<<(DMATag_DMAList0+Next_DMAList);
    }

    if((b>=bStart+2)&&(b<bEnd+2)){ // process cache block
      Local_P=NULL;Local_Y=(volatile double *)Heap;Local_X=((volatile double *)Heap)+CacheBlocks[Current_CacheBlock].NRows; // repartition heap
      uint32_t InitY = CacheBlocks[Current_CacheBlock].ROffset != LastRowOffset;
      uint32_t StoreY = 0;
      if(b > bEnd)StoreY=1;else if(CacheBlocks[Current_CacheBlock].ROffset != CacheBlocks[Next_CacheBlock].ROffset)StoreY=1;
      SpMV_MyPart_SingleCacheBlock(InitY,0,StoreY);
      LastRowOffset=CacheBlocks[Current_CacheBlock].ROffset;
    }else{
      mfc_write_tag_mask(WaitMask);mfc_read_tag_status_all();
    }

    Current_DMAList^=1;Next_DMAList^=1;
         if(Current_CacheBlock==0){Current_CacheBlock=1;Next_CacheBlock=2;CacheBlock_After_Next=0;}
    else if(Current_CacheBlock==1){Current_CacheBlock=2;Next_CacheBlock=0;CacheBlock_After_Next=1;}
    else if(Current_CacheBlock==2){Current_CacheBlock=0;Next_CacheBlock=1;CacheBlock_After_Next=2;}
  }
  mfc_write_tag_mask(1<<DMATag_StoreY);mfc_read_tag_status_all(); // wait for store of: Y (may fall thru)
  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
}
//==============================================================================================================================
int main(uint64_t spuid __attribute__ ((__unused__)), uint64_t argp, uint64_t envp __attribute__ ((__unused__))) {
  uint32_t i,tBarrier,tStart,tSpMV,minTime=0xFFFFFFFF;
  for(i=0;i<32;i++)MyLock[i]=0;
  spu_write_out_mbox((uint32_t)&MyLock[0]);
  //printf("Hello, I'm an SPE - argp=%016llx\n",argp);

  // Get Argument list (@argp) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  spu_mfcdma32(&pthread_args[0],argp,128,DMATag_args,MFC_GET_CMD);
  mfc_write_tag_mask(1<<DMATag_args);
  mfc_read_tag_status_all();
  minTrials       = pthread_args[2];
  MyRank          = pthread_args[3];
  DRAM_BlockedSpA = pthread_args[4];
  DRAM_X          = pthread_args[5];
  DRAM_Y          = pthread_args[6];
  DRAM_Z          = pthread_args[7];
  // Get BlockedSpA (@DRAM_BlockedSpA) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  spu_mfcdma32(&BlockedSpA,DRAM_BlockedSpA,sizeof(BlockedSparseMatrix),DMATag_BlockedSpA,MFC_GET_CMD);
  mfc_write_tag_mask(1<<DMATag_BlockedSpA);
  mfc_read_tag_status_all();
  // Run SpMV trials - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(i=0;i<minTrials;i++){
    spu_writech(SPU_WrDec,0x7FFFFFFF);
    tStart=spu_readch(SPU_RdDec); // start timer
    barrier();
    SpMV_MyPart();
    tSpMV=tStart-spu_readch(SPU_RdDec); // stop timer
    barrier();
    tBarrier=spu_readch(SPU_RdDec); // stop timer
    if((tStart-tBarrier)<minTime){minTime=tStart-tBarrier;}
    //calculate things, swap pointers, etc...
    uint32_t DRAM_temp=DRAM_X;DRAM_X=DRAM_Y;DRAM_Y=DRAM_temp;
  }
  // Report back timings- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  if(MyRank==0)printf("MinTime = %d cycles\nGFlop/s=%0.3f @ 80MHz\nGFlop/s=%0.3f @ 14.3MHz\nGFlop/s=%0.3f @ 26.67MHz\n",minTime,0.0800f*2.0f*BlockedSpA.ActualNonZeros/(minTime),0.0143f*2.0f*BlockedSpA.ActualNonZeros/(minTime),0.026666f*2.0f*BlockedSpA.ActualNonZeros/(minTime));
  //if(MyRank==0)printf("MinTime = %d cycles, GFlop/s=%0.3f(%0.3f)\n",minTime,0.0800f*2.0f*BlockedSpA.ActualNonZeros/(tSpMV),0.0143f*2.0f*BlockedSpA.ActualNonZeros/(tSpMV));
  //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  return(0);
}
