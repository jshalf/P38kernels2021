// SpMV parallelization routines
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

#define min(a,b) ((a)>(b)?(b):(a))
#define max(a,b) ((a)>(b)?(a):(b))

uint32_t totalBlocksAllocated;
uint32_t BlocksAllocatedAtATime=1000; // FIX - realloc has problems !!!
uint32_t *CompressedColumnOfColumn;

void ChooseBlockingForCacheBlockedRow(
    uint32_t OptimizationMask, uint32_t SourceCompression, 
    uint32_t MinRow, 
    uint32_t ThreadMinRow, uint32_t ThreadMaxRow,
    uint32_t ThreadMinColumn, uint32_t ThreadMaxColumn,
    uint32_t *MaxCachedRows, uint32_t *MaxCachedColumns, uint32_t *MaxCachedPages
  ){

  *MaxCachedPages = 1000000;
  if(OptimizationMask&OPTIMIZATION_TLB_BLOCK_X){ // TLB BLOCK SOURCE
    *MaxCachedPages = PageEntriesAvailable;
  }

  if((OptimizationMask&(OPTIMIZATION_CACHE_BLOCK_X | OPTIMIZATION_CACHE_BLOCK_Y)) == 0 ){ // NEITHER
    *MaxCachedRows    = ThreadMaxRow    - ThreadMinRow;
    *MaxCachedColumns = ThreadMaxColumn - ThreadMinColumn;
  }else
  if((OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X)&&(OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y)){ // BOTH

    // default option - CSR (12bytes per row = 8 for vector, 4 for pointers, 8bytes per column. => 20 bytes total
    *MaxCachedRows    = CacheLineSizeInDoubles*(( 8*CacheLinesAvailable)/20);
    *MaxCachedColumns = CacheLineSizeInDoubles*(( 8*CacheLinesAvailable)/20);
    if( *MaxCachedRows > (ThreadMaxRow - ThreadMinRow) ){
      *MaxCachedRows = ThreadMaxRow - ThreadMinRow;
      *MaxCachedColumns = CacheLineSizeInDoubles*CacheLinesAvailable - (12*(*MaxCachedRows))/8;
      *MaxCachedColumns = CacheLineSizeInDoubles*(*MaxCachedColumns/CacheLineSizeInDoubles);
    }
    if(ENABLE_FORMATS == (1<<FORMAT_BCOO)){ // only BCOO is supported
      *MaxCachedRows    = CacheLineSizeInDoubles*((CacheLinesAvailable)/2);
      *MaxCachedColumns = CacheLineSizeInDoubles*((CacheLinesAvailable)/2);
      //*MaxCachedRows    = CacheLineSizeInDoubles*((66*CacheLinesAvailable)/100);
      //*MaxCachedColumns = CacheLineSizeInDoubles*((33*CacheLinesAvailable)/100);
      if( *MaxCachedRows > (ThreadMaxRow - ThreadMinRow) ){
        *MaxCachedRows = ThreadMaxRow - ThreadMinRow;
        *MaxCachedColumns = CacheLineSizeInDoubles*CacheLinesAvailable - *MaxCachedRows;
        *MaxCachedColumns = CacheLineSizeInDoubles*(*MaxCachedColumns/CacheLineSizeInDoubles);
      }
    }
  }else 
  if(OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X){ // SOURCE ONLY
    *MaxCachedRows    = ThreadMaxRow    - ThreadMinRow;
    *MaxCachedColumns = CacheLineSizeInDoubles*CacheLinesAvailable;
  }else{
    printf("Unknow cacheblocking strategy - 0x%08x\n",OptimizationMask);exit(0);
  }
}



uint32_t CacheBlockMatrix(uint32_t thread,BlockedSparseMatrix *BlockedSpA, uint32_t b, SparseMatrix *SpA, 
		          uint32_t ThreadMinRow,    uint32_t ThreadMaxRow, 
			  uint32_t ThreadMinColumn, uint32_t ThreadMaxColumn, 
			  uint32_t OptimizationMask, uint32_t SourceCompression){
  // FIX what if given an empty block (no rows or no columns)

  //printf("Cache block matrix called\n");fflush(stdout);
  uint32_t y,x,z,globalRow;
  uint32_t MaxCachedRows, MaxCachedColumns, MaxCachedPages;
  uint32_t NRows=ThreadMaxRow-ThreadMinRow,NCols=ThreadMaxColumn-ThreadMinColumn;

  uint32_t *   NonZerosInColumn = (uint32_t *)MALLOC((NCols+1) * sizeof(uint32_t));
  uint32_t * NonZerosUpToColumn = (uint32_t *)MALLOC((NCols+1) * sizeof(uint32_t));
  uint32_t *      NonZerosInRow = (uint32_t *)MALLOC((NRows+1) * sizeof(uint32_t));
  uint32_t *    NonZerosUpToRow = (uint32_t *)MALLOC((NRows+1) * sizeof(uint32_t));
  

  // Note:  DMAList uses absolute (not cache block relative) EAL's
  DMAListElement * DMAList = (DMAListElement *)MALLOC((((ThreadMaxColumn-ThreadMinColumn)/CacheLineSizeInDoubles)+1) * sizeof(DMAListElement));

  for(x=0;x<=NRows;x++)NonZerosInRow[x]=0;
  for(z=0,globalRow=ThreadMinRow;globalRow<ThreadMaxRow;globalRow++){
    NonZerosInRow[globalRow-ThreadMinRow]=0;
    for(x=SpA->P[globalRow];x<SpA->P[globalRow+1];x++){
      uint32_t c = SpA->C32b[x];
      if((c>=ThreadMinColumn)&&(c<ThreadMaxColumn)){
        NonZerosInRow[globalRow-ThreadMinRow]++;
      }
  }}
  NonZerosUpToRow[0]=0;for(x=1;x<=NRows;x++)NonZerosUpToRow[x]=NonZerosUpToRow[x-1]+NonZerosInRow[x-1]; 

  // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  uint32_t _MinRow = 0xFFFFFFF;
  uint32_t MinRow;
  uint32_t MaxRow = ThreadMinRow;
  while(NonZerosUpToRow[MaxRow-ThreadMinRow] < NonZerosUpToRow[ThreadMaxRow-ThreadMinRow]){
    //printf("  another blocked row\n");fflush(stdout);

    // Find first non empty row in this thread block
    MinRow = MaxRow;
    while((MinRow<ThreadMaxRow)&&(NonZerosUpToRow[MinRow-ThreadMinRow]==NonZerosUpToRow[MinRow-ThreadMinRow+CacheLineSizeInDoubles]))MinRow+=CacheLineSizeInDoubles; // prune leading empty rows

    // Find last non empty row in this thread block that is at most MaxCachedRows ahead
    ChooseBlockingForCacheBlockedRow(OptimizationMask,SourceCompression,MinRow,ThreadMinRow,ThreadMaxRow,ThreadMinColumn,ThreadMaxColumn,&MaxCachedRows,&MaxCachedColumns,&MaxCachedPages);
    MaxRow=MinRow+MaxCachedRows;if(MaxRow>ThreadMaxRow)MaxRow=ThreadMaxRow;
    while((MaxRow>      MinRow)&&(NonZerosUpToRow[MaxRow-ThreadMinRow]==NonZerosUpToRow[MaxRow-ThreadMinRow-CacheLineSizeInDoubles]))MaxRow-=CacheLineSizeInDoubles; // prune trailing empty rows

    uint32_t MinColumn;
    uint32_t MaxColumn = ThreadMinColumn;

    // now, count the number of nonzeros in each column between rows MinRow and MaxRow, but also between columns ThreadMinColumn and ThreadMaxColumn
    for(x=0;x<=NCols;x++)NonZerosInColumn[x]=0;
    for(x=SpA->P[MinRow];x<SpA->P[MaxRow];x++){
      uint32_t c = SpA->C32b[x];
      if((c>=ThreadMinColumn)&&(c<ThreadMaxColumn)){
        NonZerosInColumn[c-ThreadMinColumn]++;
    }}
    // make it cumulative - i.e. total nonzeros between column 0 and x(relative) and between rows MinRow and MaxRow
    NonZerosUpToColumn[0]=0;for(x=1;x<=NCols;x++)NonZerosUpToColumn[x]=NonZerosUpToColumn[x-1]+NonZerosInColumn[x-1]; 


    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    while(NonZerosUpToColumn[MaxColumn-ThreadMinColumn] < NonZerosUpToColumn[ThreadMaxColumn-ThreadMinColumn]){
      //printf("    another blocked column: ");fflush(stdout);

      // Find first non empty column in this cache blocked row
      MinColumn = MaxColumn;
      while((MinColumn<ThreadMaxColumn)&&(NonZerosUpToColumn[MinColumn-ThreadMinColumn]==NonZerosUpToColumn[MinColumn-ThreadMinColumn+CacheLineSizeInDoubles]))MinColumn+=CacheLineSizeInDoubles;

      uint32_t DMAStanzas = 0;
      uint32_t CachedColumns = 0;
      uint32_t CachedPages = 0;

      if(SourceCompression==DENSE_VECTOR){// Find last non empty column in this cache blocked row that is at most MaxCachedColumns ahead
        MaxColumn=MinColumn+MaxCachedColumns;if(MaxColumn>ThreadMaxColumn)MaxColumn=ThreadMaxColumn;
        while((MaxColumn>      MinColumn)&&(NonZerosUpToColumn[MaxColumn-ThreadMinColumn]==NonZerosUpToColumn[MaxColumn-ThreadMinColumn-CacheLineSizeInDoubles]))MaxColumn-=CacheLineSizeInDoubles;
	CachedColumns = MaxColumn-MinColumn;
      }else{
        uint32_t TLB_MaxColumn = ThreadMaxColumn;

	if(OptimizationMask & OPTIMIZATION_TLB_BLOCK_X){
          TLB_MaxColumn = MinColumn;
          while((TLB_MaxColumn<ThreadMaxColumn)&&(CachedPages<MaxCachedPages)){
            if((NonZerosUpToColumn[min(ThreadMaxColumn,TLB_MaxColumn+PageSizeInDoubles)-ThreadMinColumn]-NonZerosUpToColumn[TLB_MaxColumn-ThreadMinColumn])>0)CachedPages++;
            TLB_MaxColumn += PageSizeInDoubles;if(TLB_MaxColumn>ThreadMaxColumn)TLB_MaxColumn=ThreadMaxColumn;
	  }
	}

        uint32_t    lastLineNotEmpty=0;
        uint32_t currentLineNotEmpty=0;
        MaxColumn = MinColumn;
        //while((MaxColumn<ThreadMaxColumn)&&(CachedColumns<MaxCachedColumns)){
        while( (MaxColumn<TLB_MaxColumn) && (CachedColumns<MaxCachedColumns) && ( (SourceCompression!=SPARSE_VECTOR_FOR_DMA)||(DMAStanzas<MaxStanzas) ) ){
             lastLineNotEmpty = currentLineNotEmpty;
          currentLineNotEmpty = (NonZerosUpToColumn[MaxColumn+CacheLineSizeInDoubles-ThreadMinColumn]-NonZerosUpToColumn[MaxColumn-ThreadMinColumn])>0;
	  if(currentLineNotEmpty){CachedColumns+=CacheLineSizeInDoubles;
            if((DMAStanzas>0)&&(DMAList[DMAStanzas-1].Size>=MaxStanzaLength)){DMAStanzas++;DMAList[DMAStanzas-1].EAL=8*MaxColumn;DMAList[DMAStanzas-1].Size =8*CacheLineSizeInDoubles;}
	                                            else if(lastLineNotEmpty){                                                   DMAList[DMAStanzas-1].Size+=8*CacheLineSizeInDoubles;}
		                                                         else{DMAStanzas++;DMAList[DMAStanzas-1].EAL=8*MaxColumn;DMAList[DMAStanzas-1].Size =8*CacheLineSizeInDoubles;}
	    //if(lastLineNotEmpty){                                                   DMAList[DMAStanzas-1].Size+=8*CacheLineSizeInDoubles;}
  	    //                else{DMAStanzas++;DMAList[DMAStanzas-1].EAL=8*MaxColumn;DMAList[DMAStanzas-1].Size =8*CacheLineSizeInDoubles;}
	  }
          MaxColumn += CacheLineSizeInDoubles;if(MaxColumn>ThreadMaxColumn)MaxColumn=ThreadMaxColumn;
	}
	//printf("%6d vs %6d\n",TLB_MaxColumn,MaxColumn);
      }

      // allocate arrays
      if(BlockedSpA->blocks!=NULL){
        Init_SparseMatrix(BlockedSpA->blocks+b);
        BlockedSpA->blocks[b].FirstRow      = 0;
        BlockedSpA->blocks[b].LastRow       = MaxRow    - MinRow;
        BlockedSpA->blocks[b].NRows         = MaxRow    - MinRow;
        BlockedSpA->blocks[b].NCols         = MaxColumn - MinColumn;
        BlockedSpA->blocks[b].ActualNonZeros = NonZerosUpToColumn[MaxColumn-ThreadMinColumn]-NonZerosUpToColumn[MinColumn-ThreadMinColumn];
        BlockedSpA->blocks[b].ROffset       = MinRow;
        BlockedSpA->blocks[b].COffset       = MinColumn;
        BlockedSpA->blocks[b].ColumnsTransfered      = CachedColumns;
        BlockedSpA->blocks[b].DMAStanzas    = DMAStanzas;
        BlockedSpA->blocks[b].DMAList       = NULL;
        BlockedSpA->blocks[b].CacheLines    = CachedColumns/CacheLineSizeInDoubles;
        BlockedSpA->blocks[b].CacheLineList = NULL;
        BlockedSpA->blocks[b].Bits          = 1;
        BlockedSpA->blocks[b].Format        = FORMAT_BCOO;
        BlockedSpA->blocks[b].logR          = 0;
        BlockedSpA->blocks[b].logC          = 0;
        BlockedSpA->blocks[b].NTiles        = NonZerosUpToColumn[MaxColumn-ThreadMinColumn]-NonZerosUpToColumn[MinColumn-ThreadMinColumn];
        BlockedSpA->blocks[b].SourceCompression = SourceCompression;

        BlockedSpA->blocks[b].base0Size=10*CacheLineSizeInDoubles*sizeof(double); // enough pad to align 10 pointers
	BlockedSpA->blocks[b].base0Size += (  BlockedSpA->blocks[b].NTiles)*sizeof(  double);
	BlockedSpA->blocks[b].base0Size += (1+BlockedSpA->blocks[b].NTiles)*sizeof(uint32_t);
	BlockedSpA->blocks[b].base0Size += (1+BlockedSpA->blocks[b].NTiles)*sizeof(uint32_t);
	// FIX - include DMA list??
         

        //BlockedSpA->blocks[b].base0 = (void*)NUMA_MALLOC(BlockedSpA->blocks[b].base0Size,thread);
        BlockedSpA->blocks[b].base0 = (void*)MALLOC(BlockedSpA->blocks[b].base0Size);
        void*_base0=BlockedSpA->blocks[b].base0;
        _base0 =(void*)(((uint64_t)_base0 + CacheLineSizeInDoubles*sizeof(double) - 1) & ~(CacheLineSizeInDoubles*sizeof(double)-1));
        BlockedSpA->blocks[b].V             = (  double*)_base0;_base0+=((  BlockedSpA->blocks[b].NTiles)*sizeof(  double));
        _base0 =(void*)(((uint64_t)_base0 + CacheLineSizeInDoubles*sizeof(double) - 1) & ~(CacheLineSizeInDoubles*sizeof(double)-1));
        BlockedSpA->blocks[b].C32b          = (uint32_t*)_base0;_base0+=((1+BlockedSpA->blocks[b].NTiles)*sizeof(uint32_t));
        _base0 =(void*)(((uint64_t)_base0 + CacheLineSizeInDoubles*sizeof(double) - 1) & ~(CacheLineSizeInDoubles*sizeof(double)-1));
        BlockedSpA->blocks[b].R32b          = (uint32_t*)_base0;_base0+=((1+BlockedSpA->blocks[b].NTiles)*sizeof(uint32_t));
        BlockedSpA->blocks[b].P             = NULL;
        BlockedSpA->blocks[b].C16b          = NULL;
        BlockedSpA->blocks[b].R16b          = NULL;
 
        
        //printf("malloc done\n");fflush(stdout);


                            BlockedSpA->blocks[b].InitY = 0;
        if(MinRow !=_MinRow)BlockedSpA->blocks[b].InitY = 1;
	_MinRow = MinRow;

	if(SourceCompression==SPARSE_VECTOR_FOR_COPY){
	  // Create list
	  BlockedSpA->blocks[b].CacheLineList = (uint32_t *)MALLOC(BlockedSpA->blocks[b].CacheLines * sizeof(uint32_t));
  	  uint32_t c=0,l=0;
	  for(x=0;x<DMAStanzas;x++){for(z=0;z<(DMAList[x].Size>>3);z+=CacheLineSizeInDoubles){
	    BlockedSpA->blocks[b].CacheLineList[l++]=(DMAList[x].EAL>>3)+z-MinColumn;
	    for(y=z;y<z+CacheLineSizeInDoubles;y++){
              CompressedColumnOfColumn[(DMAList[x].EAL>>3)+y-MinColumn] = c;
              c++;
            }
	  }}
	  printf("%d cache lines\n",l);
	}else
	if(SourceCompression==SPARSE_VECTOR_FOR_DMA){
	  // Create list
	  BlockedSpA->blocks[b].DMAList = (DMAListElement *)MALLOC(DMAStanzas * sizeof(DMAListElement));
	  for(x=0;x<DMAStanzas;x++){BlockedSpA->blocks[b].DMAList[x].Size=DMAList[x].Size;BlockedSpA->blocks[b].DMAList[x].EAL=DMAList[x].EAL-8*MinColumn;}
	  //recompress indices
  	  uint32_t c=0; // compressed index
	  for(x=0;x<BlockedSpA->blocks[b].DMAStanzas;x++)for(z=0;z<(BlockedSpA->blocks[b].DMAList[x].Size>>3);z++){
            //printf("%d -> %d\n",(BlockedSpA->blocks[b].DMAList[x].EAL>>3)+z,c);
            CompressedColumnOfColumn[(BlockedSpA->blocks[b].DMAList[x].EAL>>3)+z] = c;
            c++;
	  }
	}
        //printf("lists done\n");fflush(stdout);

        for(z=0,globalRow=MinRow;globalRow<MaxRow;globalRow++){
          for(x=SpA->P[globalRow];x<SpA->P[globalRow+1];x++){
            uint32_t c = SpA->C32b[x];
            if((c>=MinColumn)&&(c<MaxColumn)){
  	      uint32_t rRelative = globalRow-MinRow;
  	      uint32_t cRelative =         c-MinColumn;
	      if((SourceCompression==SPARSE_VECTOR_FOR_DMA)||(SourceCompression==SPARSE_VECTOR_FOR_COPY)){
                cRelative = CompressedColumnOfColumn[cRelative];
                //printf("%d -> %d\n",c,cRelative);
		// cRelative better be less than the max number of doubles
              }
	      BlockedSpA->blocks[b].V[z]   =SpA->V[x];
	      BlockedSpA->blocks[b].C32b[z]=cRelative;
	      BlockedSpA->blocks[b].R32b[z]=rRelative;
	      z++;
            }
        }}
        BlockedSpA->blocks[b].C32b[z]=-1;
        BlockedSpA->blocks[b].R32b[z]=-1;
        //printf("copy done\n");fflush(stdout);


      }
      b++;
      if(b>=totalBlocksAllocated){
        //printf("WARNING - REALLOC might have problems\n");fflush(stdout);
        totalBlocksAllocated+=BlocksAllocatedAtATime;
	SparseMatrix *SpTemp = NULL;
	SpTemp = (SparseMatrix *)REALLOC(BlockedSpA->blocks,totalBlocksAllocated * sizeof(SparseMatrix));
	if(SpTemp==NULL){printf("realloc returned NULL\n");exit(0);}
        BlockedSpA->blocks = SpTemp;
      }
      //printf("done\n");fflush(stdout);
    } // for all columns in this blocked row
    //printf("  done\n");fflush(stdout);
  } // for all blocked rows in this thread block
  //printf("preparing to FREE()\n");fflush(stdout);

  FREE(           DMAList);
  FREE(     NonZerosInRow);
  FREE(   NonZerosUpToRow);
  FREE(  NonZerosInColumn);
  FREE(NonZerosUpToColumn);


  //printf("Cache block matrix done\n");fflush(stdout);
  return(b);
}

double WorkPerThreadBlockedRow(SparseMatrix *SpA, uint32_t RowStart, uint32_t RowEnd){
  double val = 0.0;
  val += 12.0*(SpA->P[RowEnd]-SpA->P[RowStart]);
  val +=  0.0*(RowEnd-RowStart);
  return(val);
}

BlockedSparseMatrix * Parallelize_and_Block_SparseMatrix(SparseMatrix *SpA, uint32_t RThreads, uint32_t CThreads, uint32_t OptimizationMask, uint32_t SourceCompression){
  //               SpA : input sparse matrix in CSR
  //          RThreads = # of row groups
  //          CThreads = # of threads per row group
  // SourceCompression : 0 = Source vector of cache block is dense
  //                     1 = Source vector of cache block is sparse (i.e. can have up to ColumnCacheLines used cache lines of the source vector in the cache block)
  //                     3 = "" + create a DMA list to accelerate Cell via DMA_GETL


  uint32_t x,rt,ct;

  uint32_t    FirstRowForThread[MaxThreads];
  uint32_t     LastRowForThread[MaxThreads];
  uint32_t FirstColumnForThread[MaxThreads];
  uint32_t  LastColumnForThread[MaxThreads];

  BlockedSparseMatrix * BlockedSpA = (BlockedSparseMatrix *)MALLOC(sizeof(BlockedSparseMatrix));
  Init_BlockedSparseMatrix(BlockedSpA);

  printf("%s",CRT_RESET);

  uint32_t *   NonZerosInColumn = (uint32_t *)MALLOC((SpA->NCols+1) * sizeof(uint32_t));
  uint32_t * NonZerosUpToColumn = (uint32_t *)MALLOC((SpA->NCols+1) * sizeof(uint32_t));
  BlockedSpA->NRows            = SpA->NRows;
  BlockedSpA->NCols            = SpA->NCols;
  BlockedSpA->RThreads         = RThreads;
  BlockedSpA->CThreads         = CThreads;
  BlockedSpA->ActualNonZeros   = SpA->ActualNonZeros;
  BlockedSpA->OptimizationMask = OptimizationMask;

  double TotalWork = WorkPerThreadBlockedRow(SpA,0,SpA->NRows);
  uint32_t TargetWorkPerBlock      = SpA->P[SpA->NRows] / RThreads / CThreads;
  uint32_t ThreadMaxRow=0,ThreadMinRow,ThreadMaxColumn,ThreadMinColumn;
  uint32_t block = 0;
  uint32_t thread = 0;

  printf("Parallelizing on a %d by %d processor grid...",RThreads,CThreads);fflush(stdout);

  // determine block sizes (balanced by nonzeros) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  for(rt=0;rt<RThreads;rt++){

    // Determine the number of rows in the next blocked row
    ThreadMinRow=ThreadMaxRow;
    ThreadMaxRow+=CacheLineSizeInDoubles;
    if(ThreadMaxRow>SpA->NRows)ThreadMaxRow=SpA->NRows;
    while( (ThreadMaxRow<SpA->NRows) && (WorkPerThreadBlockedRow(SpA,0,ThreadMaxRow) < ((double)(rt+1.0)*(double)TotalWork)/(double)RThreads) ){
      ThreadMaxRow+=CacheLineSizeInDoubles;
    }
    if(ThreadMaxRow>SpA->NRows)ThreadMaxRow=SpA->NRows;
    if(rt==(RThreads-1)){
      ThreadMaxRow = SpA->NRows; // last ThreadBlockedRow goes to end
    }else if( (ThreadMaxRow-ThreadMinRow) >= 2*CacheLineSizeInDoubles ){ // What if we gave it too much
      double OverShotBy  = (WorkPerThreadBlockedRow(SpA,0,ThreadMaxRow) - ((double)(rt+1.0)*(double)TotalWork)/(double)RThreads);
      double UnderShotBy = (((double)(rt+1.0)*(double)TotalWork)/(double)RThreads - WorkPerThreadBlockedRow(SpA,0,ThreadMaxRow-CacheLineSizeInDoubles));
      if( (UnderShotBy>0) && (OverShotBy>UnderShotBy) )ThreadMaxRow-=CacheLineSizeInDoubles;
    }

    // now, count the number of nonzeros in each column between rows MinRow and ThreadMaxRow
    for(x=0;x<=SpA->NCols;x++)NonZerosInColumn[x]=0;
    if(ThreadMaxRow>ThreadMinRow)for(x=SpA->P[ThreadMinRow];x<SpA->P[ThreadMaxRow];x++)NonZerosInColumn[SpA->C32b[x]]++;
    // make it cumulative - i.e. total nonzeros between column 0 and x and between rows MinRow and ThreadMaxRow
    NonZerosUpToColumn[0]=0;for(x=1;x<=SpA->NCols;x++)NonZerosUpToColumn[x]=NonZerosUpToColumn[x-1]+NonZerosInColumn[x-1]; 

    ThreadMaxColumn=0;
    for(ct=0;ct<CThreads;ct++){

      // determine the number of columns in each block
      ThreadMinColumn = ThreadMaxColumn;
      while((ThreadMaxColumn<SpA->NCols)&&((NonZerosUpToColumn[ThreadMaxColumn]-NonZerosUpToColumn[ThreadMinColumn]) < TargetWorkPerBlock))ThreadMaxColumn+=CacheLineSizeInDoubles;
      if(ct==(CThreads-1))ThreadMaxColumn = SpA->NCols;
      while((ThreadMinColumn<ThreadMaxColumn)&&(NonZerosUpToColumn[ThreadMinColumn]==NonZerosUpToColumn[ThreadMinColumn+CacheLineSizeInDoubles]))ThreadMinColumn+=CacheLineSizeInDoubles;
      while((ThreadMaxColumn>ThreadMinColumn)&&(NonZerosUpToColumn[ThreadMaxColumn]==NonZerosUpToColumn[ThreadMaxColumn-CacheLineSizeInDoubles]))ThreadMaxColumn-=CacheLineSizeInDoubles; // FIX be careful

         FirstRowForThread[thread] = ThreadMinRow;
          LastRowForThread[thread] = ThreadMaxRow;
      FirstColumnForThread[thread] = ThreadMinColumn;
       LastColumnForThread[thread] = ThreadMaxColumn;

      thread++;

    }
  }
  printf("%sdone%s\n",CRT_DONE,CRT_RESET);


  CompressedColumnOfColumn = NULL;
  CompressedColumnOfColumn = (uint32_t *)MALLOC((SpA->NCols+1)*sizeof(uint32_t));
  for(x=0;x<=SpA->NCols;x++)CompressedColumnOfColumn[x]=x;

  if( (!OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X) && (SourceCompression == SPARSE_VECTOR_FOR_COPY) ){
    printf("SPARSE_VECTOR_FOR_COPY can only be used if cache blocking X\n");
    exit(0);
  } else 
  if( ((OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X) && !(OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y)) && (SourceCompression == SPARSE_VECTOR_FOR_DMA) ){
    printf("SPARSE_VECTOR_FOR_DMA can only be used if cache blocking both X & Y \n");
    exit(0);
  } else 
  if( ( !(OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X) && (OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y)) && (SourceCompression == SPARSE_VECTOR_FOR_DMA) ){
    printf("SPARSE_VECTOR_FOR_DMA can only be used if cache blocking both X & Y \n");
    exit(0);
  } else 
  if( (OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X)&&(OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y)&&(SourceCompression == SPARSE_VECTOR_FOR_DMA) ){
    printf("Cache blocking rows and columns for DMA...");fflush(stdout);
  } else
  if( ((OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X)||(OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y))&& !(OptimizationMask&OPTIMIZATION_TLB_BLOCK_X) ){
    if(SourceCompression == SPARSE_VECTOR_FOR_COPY)printf("Cache blocking with an explicit local copy...");else
                                                   printf("Cache blocking...");
    fflush(stdout);
  } else
  if( ((OptimizationMask&OPTIMIZATION_CACHE_BLOCK_X)||(OptimizationMask&OPTIMIZATION_CACHE_BLOCK_Y))&&(OptimizationMask&OPTIMIZATION_TLB_BLOCK_X) ){
    if(SourceCompression == SPARSE_VECTOR_FOR_COPY)printf("Cache and TLB blocking with an explicit local copy...");else
                                                   printf("Cache and TLB blocking...");
    fflush(stdout);
  } else
  if( (OptimizationMask&OPTIMIZATION_TLB_BLOCK_X) ){
    printf("TLB blocking...");fflush(stdout);
  } else
  {
    printf("Not cache or TLB blocking...");fflush(stdout);
  }

  
  // now convert matrix - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  totalBlocksAllocated = BlocksAllocatedAtATime;
  BlockedSpA->blocks = (SparseMatrix *)MALLOC(totalBlocksAllocated * sizeof(SparseMatrix));

  block=0;
  for(thread=0;thread<RThreads*CThreads;thread++){

    Affinity_Bind_Memory(thread);

    BlockedSpA->FirstBlockForThread[thread]=block;
    ThreadMinRow    =    FirstRowForThread[thread];
    ThreadMaxRow    =     LastRowForThread[thread];
    ThreadMinColumn = FirstColumnForThread[thread];
    ThreadMaxColumn =  LastColumnForThread[thread];

    // add cache blocks
    uint32_t _block = block;
    block = CacheBlockMatrix(thread,BlockedSpA,block,SpA,ThreadMinRow,ThreadMaxRow,ThreadMinColumn,ThreadMaxColumn,OptimizationMask,SourceCompression); 
    BlockedSpA->blocks[_block].InitY = 1; // Must Initialize if first block of a thread

  }
  thread = RThreads*CThreads;
  for(x=thread;x<=MaxThreads;x++){
    BlockedSpA->FirstBlockForThread[x]=block;
  }

  uint32_t TNZ=0;
  uint32_t TDMAs=0;
  uint32_t TCOLs=0;

  #ifdef VERBOSE_SUMMARY
  printf("\nSummary:\n");
  #endif
  for(thread=0,x=0;x<block;x++){
    //if(BlockedSpA->blocks[x].InitY)printf(" *");else printf("  ");
    if(x==BlockedSpA->FirstBlockForThread[thread]){
      #ifdef VERBOSE_SUMMARY
      printf("  thread %3d: ",thread);
      #endif
      thread++;
    }else{
      #ifdef VERBOSE_SUMMARY
      printf("              ");
      #endif
    }
    #ifdef VERBOSE_SUMMARY
    printf("cache block: %7d x %7d(%7d doubles in %5d stanzas) @ (%7d,%7d) : %9d nonzeros\n",BlockedSpA->blocks[x].NRows,BlockedSpA->blocks[x].NCols,BlockedSpA->blocks[x].ColumnsTransfered,BlockedSpA->blocks[x].DMAStanzas,BlockedSpA->blocks[x].ROffset,BlockedSpA->blocks[x].COffset,BlockedSpA->blocks[x].ActualNonZeros);
    #endif
    TNZ+=BlockedSpA->blocks[x].ActualNonZeros;
    TCOLs+=BlockedSpA->blocks[x].ColumnsTransfered;
    TDMAs+=BlockedSpA->blocks[x].DMAStanzas;
  }
  #ifdef VERBOSE_SUMMARY
  printf("                                            (%7d doubles in %5d stanzas)                       %9d nonzeros total\n",TCOLs,TDMAs,TNZ);
  #endif

  BlockedSpA->FlopToByteRatio = 2.0*(double)TNZ / (sizeof(SparseMatrix)*block + 16*TNZ + 8*TCOLs + 8*SpA->NRows + 8*TDMAs);
  printf("%s~%3.3f%s flop:byte ratio\n",CRT_DONE,BlockedSpA->FlopToByteRatio,CRT_RESET);

  // Create temp arrays
  if(CThreads>1){ 
    printf("Allocating temporary destination vectors (for reductions)...");fflush(stdout);
    for(thread=0;thread<RThreads*CThreads;thread++){
      Affinity_Bind_Memory(thread);
      BlockedSpA->tempY[thread] = (double *)NUMA_MALLOC((BlockedSpA->NRows)*sizeof(double),thread);
      for(x=0;x<BlockedSpA->NRows;x++)BlockedSpA->tempY[thread][x]=0.0; // Init to 0
    }
    printf("%sdone%s\n",CRT_DONE,CRT_RESET);
  }

  if(SourceCompression==SPARSE_VECTOR_FOR_COPY){
    printf("Allocating temporary explicit cache block vectors...");fflush(stdout);
    for(thread=0;thread<RThreads*CThreads;thread++){
      Affinity_Bind_Memory(thread);
      BlockedSpA->tempX[thread] = (double *)NUMA_MALLOC((CacheLinesAvailable*CacheLineSizeInDoubles)*sizeof(double),thread);
      for(x=0;x<(CacheLinesAvailable*CacheLineSizeInDoubles);x++)BlockedSpA->tempX[thread][x]=0.0; // Init to 0
    }
    printf("%sdone%s\n",CRT_DONE,CRT_RESET);
  }


  //printf("\n");

  Affinity_unBind();
  if(CompressedColumnOfColumn)FREE(CompressedColumnOfColumn);
  FREE(NonZerosUpToColumn);
  FREE(  NonZerosInColumn);
  return(BlockedSpA);
}
