//=====================================================================================================
#define MaxThreads             16

#define PageEntriesAvailable   255
#define PageSizeInDoubles      2000000

#define MaxStanzaLength        16384
#define MaxStanzas             256
#define CacheLinesAvailable    1600
#define CacheLineSizeInDoubles 16

#define RegBlock_MinR          2
#define RegBlock_MinC          1
#define RegBlock_MaxR          8
#define RegBlock_MaxC          8

#define PREFETCH_MAX_V         0
#define PREFETCH_MAX_C         0

#define ENABLE_FORMATS         0x0002 // bit mask for formats
#define ENABLE_16b             1

#define ENABLE_AFFINITY_VIA_NUMA
