// SpMV spyplot routines (needs work)
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab
//==================================================================================================================

#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)>(b)?(b):(a))

// Image Processing ==============================================================================================================================
void MakeSpyplot(char *fn, SparseMatrix *SpA, int64_t imageMax){
  int64_t imagex, imagey;

  if(SpA->NRows>SpA->NCols){imagex=(imageMax*SpA->NCols)/SpA->NRows;imagey=imageMax;}
  if(SpA->NRows<SpA->NCols){imagey=(imageMax*SpA->NRows)/SpA->NCols;imagex=imageMax;}
                       else{imagey=imageMax;                        imagex=imageMax;}

  printf("%d->%ld x %d->%ld\n",SpA->NRows,imagey,SpA->NCols,imagex);
  int64_t i,j,row,maxdensity=0,scale=16;
  int64_t x,y;
  printf("Creating Image...\n");fflush(stdout);
  int64_t * density = MALLOC(imagex*imagey*sizeof(int64_t));
  for(i=0;i<imagex*imagey;i++)density[i]=0;

  // create density map
  for(row=0;row<SpA->NRows;row++){
    for(i=SpA->P[row];i<SpA->P[row+1];i++){
      //printf("%d %d %d\n",row,i);
      x=(imagex*(SpA->C32b[i]))/SpA->NCols;
      y=(imagey*(row         ))/SpA->NRows;
      j = x+imagex*y;
      density[j]++;
      maxdensity=max(density[j],maxdensity);
  }}

  printf("writing file\n");
  FILE *fp = fopen(fn,"w");
  fprintf(fp,"P3\n");
  fprintf(fp,"# density plot\n");
  fprintf(fp,"%ld %ld\n",imagex,imagey);
  fprintf(fp,"%d\n",255);
  for(y=0;y<imagey;y++){
    for(x=0;x<imagex;x++){
      j = x+imagex*y;
      int32_t color = 0;
      color = 0;
      if(density[j]){color = scale*((256)*density[j])/maxdensity;}
      color = 255-color;
      color = min(255,color);
      color = max(  0,color);

      fprintf(fp,"%d %d %d\n",color,color,color);
  }}
  fclose(fp);

  // free map
  FREE(density);
  printf("done\n");fflush(stdout);

}
