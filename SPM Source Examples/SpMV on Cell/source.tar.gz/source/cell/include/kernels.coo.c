//==================================================================================================================================
void SpMV_b2x1_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  qword _Z0QW;
  qword  Z0QW;
  qword  Y0QW;
  qword  V0QW;
  qword  X01QW;
  qword XccQW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
          VByteOffset += 16;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(XccQW,V0QW,_Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
          VByteOffset += 16;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(XccQW,V0QW,_Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
          VByteOffset += 16;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b2x2_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  qword _Z0QW;
  qword  Z0QW;
  qword  Y0QW;
  qword  V0QW;
  qword  V2QW;
  qword  X01QW;
  qword  X00QW;
  qword  X11QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
          VByteOffset += 32;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z0QW = si_dfma(X11QW,V2QW, Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
          VByteOffset += 32;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z0QW = si_dfma(X11QW,V2QW, Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
          VByteOffset += 32;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b2x4_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  double * __restrict__ X2 = (double * __restrict__)X + 2;
  qword _Z0QW;
  qword  Z0QW;
  qword  Y0QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  X01QW;
  qword  X23QW;
  qword  X00QW;
  qword  X11QW;
  qword  X22QW;
  qword  X33QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z0QW = si_dfma(X11QW,V2QW, Z0QW);
                  Z0QW = si_dfma(X22QW,V4QW, Z0QW);
                  Z0QW = si_dfma(X33QW,V6QW, Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z0QW = si_dfma(X11QW,V2QW, Z0QW);
                  Z0QW = si_dfma(X22QW,V4QW, Z0QW);
                  Z0QW = si_dfma(X33QW,V6QW, Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b2x8_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ V8 = (double * __restrict__)V + 8;
  double * __restrict__ V10 = (double * __restrict__)V + 10;
  double * __restrict__ V12 = (double * __restrict__)V + 12;
  double * __restrict__ V14 = (double * __restrict__)V + 14;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  double * __restrict__ X2 = (double * __restrict__)X + 2;
  double * __restrict__ X4 = (double * __restrict__)X + 4;
  double * __restrict__ X6 = (double * __restrict__)X + 6;
  qword _Z0QW;
  qword  Z0QW;
  qword  Y0QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  V8QW;
  qword  V10QW;
  qword  V12QW;
  qword  V14QW;
  qword  X01QW;
  qword  X23QW;
  qword  X45QW;
  qword  X67QW;
  qword  X00QW;
  qword  X11QW;
  qword  X22QW;
  qword  X33QW;
  qword  X44QW;
  qword  X55QW;
  qword  X66QW;
  qword  X77QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z0QW = si_dfma(X11QW,V2QW, Z0QW);
                  Z0QW = si_dfma(X22QW,V4QW, Z0QW);
                  Z0QW = si_dfma(X33QW,V6QW, Z0QW);
                  Z0QW = si_dfma(X44QW,V8QW, Z0QW);
                  Z0QW = si_dfma(X55QW,V10QW, Z0QW);
                  Z0QW = si_dfma(X66QW,V12QW, Z0QW);
                  Z0QW = si_dfma(X77QW,V14QW, Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z0QW = si_dfma(X11QW,V2QW, Z0QW);
                  Z0QW = si_dfma(X22QW,V4QW, Z0QW);
                  Z0QW = si_dfma(X33QW,V6QW, Z0QW);
                  Z0QW = si_dfma(X44QW,V8QW, Z0QW);
                  Z0QW = si_dfma(X55QW,V10QW, Z0QW);
                  Z0QW = si_dfma(X66QW,V12QW, Z0QW);
                  Z0QW = si_dfma(X77QW,V14QW, Z0QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b4x1_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  qword _Z0QW;
  qword _Z2QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  V0QW;
  qword  V2QW;
  qword  X01QW;
  qword XccQW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
          VByteOffset += 32;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(XccQW,V0QW,_Z0QW);
                  Z2QW = si_dfma(XccQW,V2QW,_Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
          VByteOffset += 32;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(XccQW,V0QW,_Z0QW);
                  Z2QW = si_dfma(XccQW,V2QW,_Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
          VByteOffset += 32;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b4x2_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  qword _Z0QW;
  qword _Z2QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  X01QW;
  qword  X00QW;
  qword  X11QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z0QW = si_dfma(X11QW,V4QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V6QW, Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z0QW = si_dfma(X11QW,V4QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V6QW, Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b4x4_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ V8 = (double * __restrict__)V + 8;
  double * __restrict__ V10 = (double * __restrict__)V + 10;
  double * __restrict__ V12 = (double * __restrict__)V + 12;
  double * __restrict__ V14 = (double * __restrict__)V + 14;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  double * __restrict__ X2 = (double * __restrict__)X + 2;
  qword _Z0QW;
  qword _Z2QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  V8QW;
  qword  V10QW;
  qword  V12QW;
  qword  V14QW;
  qword  X01QW;
  qword  X23QW;
  qword  X00QW;
  qword  X11QW;
  qword  X22QW;
  qword  X33QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z0QW = si_dfma(X11QW,V4QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V6QW, Z2QW);
                  Z0QW = si_dfma(X22QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V10QW, Z2QW);
                  Z0QW = si_dfma(X33QW,V12QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V14QW, Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z0QW = si_dfma(X11QW,V4QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V6QW, Z2QW);
                  Z0QW = si_dfma(X22QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V10QW, Z2QW);
                  Z0QW = si_dfma(X33QW,V12QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V14QW, Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b4x8_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ V8 = (double * __restrict__)V + 8;
  double * __restrict__ V10 = (double * __restrict__)V + 10;
  double * __restrict__ V12 = (double * __restrict__)V + 12;
  double * __restrict__ V14 = (double * __restrict__)V + 14;
  double * __restrict__ V16 = (double * __restrict__)V + 16;
  double * __restrict__ V18 = (double * __restrict__)V + 18;
  double * __restrict__ V20 = (double * __restrict__)V + 20;
  double * __restrict__ V22 = (double * __restrict__)V + 22;
  double * __restrict__ V24 = (double * __restrict__)V + 24;
  double * __restrict__ V26 = (double * __restrict__)V + 26;
  double * __restrict__ V28 = (double * __restrict__)V + 28;
  double * __restrict__ V30 = (double * __restrict__)V + 30;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  double * __restrict__ X2 = (double * __restrict__)X + 2;
  double * __restrict__ X4 = (double * __restrict__)X + 4;
  double * __restrict__ X6 = (double * __restrict__)X + 6;
  qword _Z0QW;
  qword _Z2QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  V8QW;
  qword  V10QW;
  qword  V12QW;
  qword  V14QW;
  qword  V16QW;
  qword  V18QW;
  qword  V20QW;
  qword  V22QW;
  qword  V24QW;
  qword  V26QW;
  qword  V28QW;
  qword  V30QW;
  qword  X01QW;
  qword  X23QW;
  qword  X45QW;
  qword  X67QW;
  qword  X00QW;
  qword  X11QW;
  qword  X22QW;
  qword  X33QW;
  qword  X44QW;
  qword  X55QW;
  qword  X66QW;
  qword  X77QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
          VByteOffset += 256;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z0QW = si_dfma(X11QW,V4QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V6QW, Z2QW);
                  Z0QW = si_dfma(X22QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V10QW, Z2QW);
                  Z0QW = si_dfma(X33QW,V12QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V14QW, Z2QW);
                  Z0QW = si_dfma(X44QW,V16QW, Z0QW);
                  Z2QW = si_dfma(X44QW,V18QW, Z2QW);
                  Z0QW = si_dfma(X55QW,V20QW, Z0QW);
                  Z2QW = si_dfma(X55QW,V22QW, Z2QW);
                  Z0QW = si_dfma(X66QW,V24QW, Z0QW);
                  Z2QW = si_dfma(X66QW,V26QW, Z2QW);
                  Z0QW = si_dfma(X77QW,V28QW, Z0QW);
                  Z2QW = si_dfma(X77QW,V30QW, Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
          VByteOffset += 256;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z0QW = si_dfma(X11QW,V4QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V6QW, Z2QW);
                  Z0QW = si_dfma(X22QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V10QW, Z2QW);
                  Z0QW = si_dfma(X33QW,V12QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V14QW, Z2QW);
                  Z0QW = si_dfma(X44QW,V16QW, Z0QW);
                  Z2QW = si_dfma(X44QW,V18QW, Z2QW);
                  Z0QW = si_dfma(X55QW,V20QW, Z0QW);
                  Z2QW = si_dfma(X55QW,V22QW, Z2QW);
                  Z0QW = si_dfma(X66QW,V24QW, Z0QW);
                  Z2QW = si_dfma(X66QW,V26QW, Z2QW);
                  Z0QW = si_dfma(X77QW,V28QW, Z0QW);
                  Z2QW = si_dfma(X77QW,V30QW, Z2QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
          VByteOffset += 256;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b8x1_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ Y4 = (double * __restrict__)Y + 4;
  double * __restrict__ Y6 = (double * __restrict__)Y + 6;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  qword _Z0QW;
  qword _Z2QW;
  qword _Z4QW;
  qword _Z6QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Z4QW;
  qword  Z6QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  Y4QW;
  qword  Y6QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  X01QW;
  qword XccQW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(XccQW,V0QW,_Z0QW);
                  Z2QW = si_dfma(XccQW,V2QW,_Z2QW);
                  Z4QW = si_dfma(XccQW,V4QW,_Z4QW);
                  Z6QW = si_dfma(XccQW,V6QW,_Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);
                         si_stqx((qword)Z4QW,si_from_ptr((void*)Y4),__YByteOffsetQW);
                         si_stqx((qword)Z6QW,si_from_ptr((void*)Y6),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(XccQW,V0QW,_Z0QW);
                  Z2QW = si_dfma(XccQW,V2QW,_Z2QW);
                  Z4QW = si_dfma(XccQW,V4QW,_Z4QW);
                  Z6QW = si_dfma(XccQW,V6QW,_Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 XccQW = si_shufb(X01QW,X01QW,(qword)XsplatControlWord);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
          VByteOffset += 64;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
     XsplatControlWord = si_selb((qword)ReplicateDouble1QW,(qword)ReplicateDouble0QW,si_ceqi(XInHighDoubleQW,0));

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
       XInHighDoubleQW = si_andi(si_shufb(C16QW,ZeroQW,SplatShortToWordControl),0x1);
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b8x2_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ Y4 = (double * __restrict__)Y + 4;
  double * __restrict__ Y6 = (double * __restrict__)Y + 6;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ V8 = (double * __restrict__)V + 8;
  double * __restrict__ V10 = (double * __restrict__)V + 10;
  double * __restrict__ V12 = (double * __restrict__)V + 12;
  double * __restrict__ V14 = (double * __restrict__)V + 14;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  qword _Z0QW;
  qword _Z2QW;
  qword _Z4QW;
  qword _Z6QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Z4QW;
  qword  Z6QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  Y4QW;
  qword  Y6QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  V8QW;
  qword  V10QW;
  qword  V12QW;
  qword  V14QW;
  qword  X01QW;
  qword  X00QW;
  qword  X11QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z4QW = si_dfma(X00QW,V4QW,_Z4QW);
                  Z6QW = si_dfma(X00QW,V6QW,_Z6QW);
                  Z0QW = si_dfma(X11QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V10QW, Z2QW);
                  Z4QW = si_dfma(X11QW,V12QW, Z4QW);
                  Z6QW = si_dfma(X11QW,V14QW, Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);
                         si_stqx((qword)Z4QW,si_from_ptr((void*)Y4),__YByteOffsetQW);
                         si_stqx((qword)Z6QW,si_from_ptr((void*)Y6),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z4QW = si_dfma(X00QW,V4QW,_Z4QW);
                  Z6QW = si_dfma(X00QW,V6QW,_Z6QW);
                  Z0QW = si_dfma(X11QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V10QW, Z2QW);
                  Z4QW = si_dfma(X11QW,V12QW, Z4QW);
                  Z6QW = si_dfma(X11QW,V14QW, Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
          VByteOffset += 128;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b8x4_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ Y4 = (double * __restrict__)Y + 4;
  double * __restrict__ Y6 = (double * __restrict__)Y + 6;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ V8 = (double * __restrict__)V + 8;
  double * __restrict__ V10 = (double * __restrict__)V + 10;
  double * __restrict__ V12 = (double * __restrict__)V + 12;
  double * __restrict__ V14 = (double * __restrict__)V + 14;
  double * __restrict__ V16 = (double * __restrict__)V + 16;
  double * __restrict__ V18 = (double * __restrict__)V + 18;
  double * __restrict__ V20 = (double * __restrict__)V + 20;
  double * __restrict__ V22 = (double * __restrict__)V + 22;
  double * __restrict__ V24 = (double * __restrict__)V + 24;
  double * __restrict__ V26 = (double * __restrict__)V + 26;
  double * __restrict__ V28 = (double * __restrict__)V + 28;
  double * __restrict__ V30 = (double * __restrict__)V + 30;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  double * __restrict__ X2 = (double * __restrict__)X + 2;
  qword _Z0QW;
  qword _Z2QW;
  qword _Z4QW;
  qword _Z6QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Z4QW;
  qword  Z6QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  Y4QW;
  qword  Y6QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  V8QW;
  qword  V10QW;
  qword  V12QW;
  qword  V14QW;
  qword  V16QW;
  qword  V18QW;
  qword  V20QW;
  qword  V22QW;
  qword  V24QW;
  qword  V26QW;
  qword  V28QW;
  qword  V30QW;
  qword  X01QW;
  qword  X23QW;
  qword  X00QW;
  qword  X11QW;
  qword  X22QW;
  qword  X33QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
          VByteOffset += 256;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z4QW = si_dfma(X00QW,V4QW,_Z4QW);
                  Z6QW = si_dfma(X00QW,V6QW,_Z6QW);
                  Z0QW = si_dfma(X11QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V10QW, Z2QW);
                  Z4QW = si_dfma(X11QW,V12QW, Z4QW);
                  Z6QW = si_dfma(X11QW,V14QW, Z6QW);
                  Z0QW = si_dfma(X22QW,V16QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V18QW, Z2QW);
                  Z4QW = si_dfma(X22QW,V20QW, Z4QW);
                  Z6QW = si_dfma(X22QW,V22QW, Z6QW);
                  Z0QW = si_dfma(X33QW,V24QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V26QW, Z2QW);
                  Z4QW = si_dfma(X33QW,V28QW, Z4QW);
                  Z6QW = si_dfma(X33QW,V30QW, Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
          VByteOffset += 256;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);
                         si_stqx((qword)Z4QW,si_from_ptr((void*)Y4),__YByteOffsetQW);
                         si_stqx((qword)Z6QW,si_from_ptr((void*)Y6),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z4QW = si_dfma(X00QW,V4QW,_Z4QW);
                  Z6QW = si_dfma(X00QW,V6QW,_Z6QW);
                  Z0QW = si_dfma(X11QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V10QW, Z2QW);
                  Z4QW = si_dfma(X11QW,V12QW, Z4QW);
                  Z6QW = si_dfma(X11QW,V14QW, Z6QW);
                  Z0QW = si_dfma(X22QW,V16QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V18QW, Z2QW);
                  Z4QW = si_dfma(X22QW,V20QW, Z4QW);
                  Z6QW = si_dfma(X22QW,V22QW, Z6QW);
                  Z0QW = si_dfma(X33QW,V24QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V26QW, Z2QW);
                  Z4QW = si_dfma(X33QW,V28QW, Z4QW);
                  Z6QW = si_dfma(X33QW,V30QW, Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
          VByteOffset += 256;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
//==================================================================================================================================
void SpMV_b8x8_coo16b(const uint32_t NTiles, const double * __restrict__ V, const uint16_t * __restrict__ R, const uint16_t * __restrict__ C, const double * __restrict__ X, double * __restrict__ Y){

  // For each SIMDized row in the tile
  double * __restrict__ Y0 = (double * __restrict__)Y + 0;
  double * __restrict__ Y2 = (double * __restrict__)Y + 2;
  double * __restrict__ Y4 = (double * __restrict__)Y + 4;
  double * __restrict__ Y6 = (double * __restrict__)Y + 6;
  double * __restrict__ V0 = (double * __restrict__)V + 0;
  double * __restrict__ V2 = (double * __restrict__)V + 2;
  double * __restrict__ V4 = (double * __restrict__)V + 4;
  double * __restrict__ V6 = (double * __restrict__)V + 6;
  double * __restrict__ V8 = (double * __restrict__)V + 8;
  double * __restrict__ V10 = (double * __restrict__)V + 10;
  double * __restrict__ V12 = (double * __restrict__)V + 12;
  double * __restrict__ V14 = (double * __restrict__)V + 14;
  double * __restrict__ V16 = (double * __restrict__)V + 16;
  double * __restrict__ V18 = (double * __restrict__)V + 18;
  double * __restrict__ V20 = (double * __restrict__)V + 20;
  double * __restrict__ V22 = (double * __restrict__)V + 22;
  double * __restrict__ V24 = (double * __restrict__)V + 24;
  double * __restrict__ V26 = (double * __restrict__)V + 26;
  double * __restrict__ V28 = (double * __restrict__)V + 28;
  double * __restrict__ V30 = (double * __restrict__)V + 30;
  double * __restrict__ V32 = (double * __restrict__)V + 32;
  double * __restrict__ V34 = (double * __restrict__)V + 34;
  double * __restrict__ V36 = (double * __restrict__)V + 36;
  double * __restrict__ V38 = (double * __restrict__)V + 38;
  double * __restrict__ V40 = (double * __restrict__)V + 40;
  double * __restrict__ V42 = (double * __restrict__)V + 42;
  double * __restrict__ V44 = (double * __restrict__)V + 44;
  double * __restrict__ V46 = (double * __restrict__)V + 46;
  double * __restrict__ V48 = (double * __restrict__)V + 48;
  double * __restrict__ V50 = (double * __restrict__)V + 50;
  double * __restrict__ V52 = (double * __restrict__)V + 52;
  double * __restrict__ V54 = (double * __restrict__)V + 54;
  double * __restrict__ V56 = (double * __restrict__)V + 56;
  double * __restrict__ V58 = (double * __restrict__)V + 58;
  double * __restrict__ V60 = (double * __restrict__)V + 60;
  double * __restrict__ V62 = (double * __restrict__)V + 62;
  double * __restrict__ X0 = (double * __restrict__)X + 0;
  double * __restrict__ X2 = (double * __restrict__)X + 2;
  double * __restrict__ X4 = (double * __restrict__)X + 4;
  double * __restrict__ X6 = (double * __restrict__)X + 6;
  qword _Z0QW;
  qword _Z2QW;
  qword _Z4QW;
  qword _Z6QW;
  qword  Z0QW;
  qword  Z2QW;
  qword  Z4QW;
  qword  Z6QW;
  qword  Y0QW;
  qword  Y2QW;
  qword  Y4QW;
  qword  Y6QW;
  qword  V0QW;
  qword  V2QW;
  qword  V4QW;
  qword  V6QW;
  qword  V8QW;
  qword  V10QW;
  qword  V12QW;
  qword  V14QW;
  qword  V16QW;
  qword  V18QW;
  qword  V20QW;
  qword  V22QW;
  qword  V24QW;
  qword  V26QW;
  qword  V28QW;
  qword  V30QW;
  qword  V32QW;
  qword  V34QW;
  qword  V36QW;
  qword  V38QW;
  qword  V40QW;
  qword  V42QW;
  qword  V44QW;
  qword  V46QW;
  qword  V48QW;
  qword  V50QW;
  qword  V52QW;
  qword  V54QW;
  qword  V56QW;
  qword  V58QW;
  qword  V60QW;
  qword  V62QW;
  qword  X01QW;
  qword  X23QW;
  qword  X45QW;
  qword  X67QW;
  qword  X00QW;
  qword  X11QW;
  qword  X22QW;
  qword  X33QW;
  qword  X44QW;
  qword  X55QW;
  qword  X66QW;
  qword  X77QW;

  qword RotateAmountQW;
  qword R16QW;
  qword C16QW;
  qword R32SplatQW;
  qword C32SplatQW;
                                                 // [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]  [--Zero--]  [--R16b--]   
  vector unsigned char SplatShortToWordControl   = {0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01, 0x10, 0x10, 0x00, 0x01};
  vector unsigned char SplatShortToWordIncrement = {0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x02, 0x02};
  vector unsigned char SplatShortToWordMask      = {0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F, 0xFF, 0xFF, 0x0F, 0x0F};

  qword XByteOffsetQW;
  qword XInHighDoubleQW;
  qword XsplatControlWord;

  qword    YByteOffsetQW;
  qword   _YByteOffsetQW = (qword)((vector unsigned int){(uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF, (uint32_t)0xFFFFFFFF});
  qword  __YByteOffsetQW;
  qword SameRowQW;

  uint32_t RCByteOffset = 0;  // byte offset in R and C
  uint32_t VByteOffset = 0;   // offset in V
  uint32_t TilesRemaining = NTiles;

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
                 V32QW = si_lqx(si_from_ptr((void*)V32),si_from_uint(VByteOffset));
                 V34QW = si_lqx(si_from_ptr((void*)V34),si_from_uint(VByteOffset));
                 V36QW = si_lqx(si_from_ptr((void*)V36),si_from_uint(VByteOffset));
                 V38QW = si_lqx(si_from_ptr((void*)V38),si_from_uint(VByteOffset));
                 V40QW = si_lqx(si_from_ptr((void*)V40),si_from_uint(VByteOffset));
                 V42QW = si_lqx(si_from_ptr((void*)V42),si_from_uint(VByteOffset));
                 V44QW = si_lqx(si_from_ptr((void*)V44),si_from_uint(VByteOffset));
                 V46QW = si_lqx(si_from_ptr((void*)V46),si_from_uint(VByteOffset));
                 V48QW = si_lqx(si_from_ptr((void*)V48),si_from_uint(VByteOffset));
                 V50QW = si_lqx(si_from_ptr((void*)V50),si_from_uint(VByteOffset));
                 V52QW = si_lqx(si_from_ptr((void*)V52),si_from_uint(VByteOffset));
                 V54QW = si_lqx(si_from_ptr((void*)V54),si_from_uint(VByteOffset));
                 V56QW = si_lqx(si_from_ptr((void*)V56),si_from_uint(VByteOffset));
                 V58QW = si_lqx(si_from_ptr((void*)V58),si_from_uint(VByteOffset));
                 V60QW = si_lqx(si_from_ptr((void*)V60),si_from_uint(VByteOffset));
                 V62QW = si_lqx(si_from_ptr((void*)V62),si_from_uint(VByteOffset));
          VByteOffset += 512;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z4QW = si_dfma(X00QW,V4QW,_Z4QW);
                  Z6QW = si_dfma(X00QW,V6QW,_Z6QW);
                  Z0QW = si_dfma(X11QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V10QW, Z2QW);
                  Z4QW = si_dfma(X11QW,V12QW, Z4QW);
                  Z6QW = si_dfma(X11QW,V14QW, Z6QW);
                  Z0QW = si_dfma(X22QW,V16QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V18QW, Z2QW);
                  Z4QW = si_dfma(X22QW,V20QW, Z4QW);
                  Z6QW = si_dfma(X22QW,V22QW, Z6QW);
                  Z0QW = si_dfma(X33QW,V24QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V26QW, Z2QW);
                  Z4QW = si_dfma(X33QW,V28QW, Z4QW);
                  Z6QW = si_dfma(X33QW,V30QW, Z6QW);
                  Z0QW = si_dfma(X44QW,V32QW, Z0QW);
                  Z2QW = si_dfma(X44QW,V34QW, Z2QW);
                  Z4QW = si_dfma(X44QW,V36QW, Z4QW);
                  Z6QW = si_dfma(X44QW,V38QW, Z6QW);
                  Z0QW = si_dfma(X55QW,V40QW, Z0QW);
                  Z2QW = si_dfma(X55QW,V42QW, Z2QW);
                  Z4QW = si_dfma(X55QW,V44QW, Z4QW);
                  Z6QW = si_dfma(X55QW,V46QW, Z6QW);
                  Z0QW = si_dfma(X66QW,V48QW, Z0QW);
                  Z2QW = si_dfma(X66QW,V50QW, Z2QW);
                  Z4QW = si_dfma(X66QW,V52QW, Z4QW);
                  Z6QW = si_dfma(X66QW,V54QW, Z6QW);
                  Z0QW = si_dfma(X77QW,V56QW, Z0QW);
                  Z2QW = si_dfma(X77QW,V58QW, Z2QW);
                  Z4QW = si_dfma(X77QW,V60QW, Z4QW);
                  Z6QW = si_dfma(X77QW,V62QW, Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
                 V32QW = si_lqx(si_from_ptr((void*)V32),si_from_uint(VByteOffset));
                 V34QW = si_lqx(si_from_ptr((void*)V34),si_from_uint(VByteOffset));
                 V36QW = si_lqx(si_from_ptr((void*)V36),si_from_uint(VByteOffset));
                 V38QW = si_lqx(si_from_ptr((void*)V38),si_from_uint(VByteOffset));
                 V40QW = si_lqx(si_from_ptr((void*)V40),si_from_uint(VByteOffset));
                 V42QW = si_lqx(si_from_ptr((void*)V42),si_from_uint(VByteOffset));
                 V44QW = si_lqx(si_from_ptr((void*)V44),si_from_uint(VByteOffset));
                 V46QW = si_lqx(si_from_ptr((void*)V46),si_from_uint(VByteOffset));
                 V48QW = si_lqx(si_from_ptr((void*)V48),si_from_uint(VByteOffset));
                 V50QW = si_lqx(si_from_ptr((void*)V50),si_from_uint(VByteOffset));
                 V52QW = si_lqx(si_from_ptr((void*)V52),si_from_uint(VByteOffset));
                 V54QW = si_lqx(si_from_ptr((void*)V54),si_from_uint(VByteOffset));
                 V56QW = si_lqx(si_from_ptr((void*)V56),si_from_uint(VByteOffset));
                 V58QW = si_lqx(si_from_ptr((void*)V58),si_from_uint(VByteOffset));
                 V60QW = si_lqx(si_from_ptr((void*)V60),si_from_uint(VByteOffset));
                 V62QW = si_lqx(si_from_ptr((void*)V62),si_from_uint(VByteOffset));
          VByteOffset += 512;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;



  while(TilesRemaining){//======================================================================================
    // store results - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                         si_stqx((qword)Z0QW,si_from_ptr((void*)Y0),__YByteOffsetQW);
                         si_stqx((qword)Z2QW,si_from_ptr((void*)Y2),__YByteOffsetQW);
                         si_stqx((qword)Z4QW,si_from_ptr((void*)Y4),__YByteOffsetQW);
                         si_stqx((qword)Z6QW,si_from_ptr((void*)Y6),__YByteOffsetQW);

    // FMAs - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 _Z0QW = si_selb(Y0QW,Z0QW,SameRowQW);
                 _Z2QW = si_selb(Y2QW,Z2QW,SameRowQW);
                 _Z4QW = si_selb(Y4QW,Z4QW,SameRowQW);
                 _Z6QW = si_selb(Y6QW,Z6QW,SameRowQW);
                  Z0QW = si_dfma(X00QW,V0QW,_Z0QW);
                  Z2QW = si_dfma(X00QW,V2QW,_Z2QW);
                  Z4QW = si_dfma(X00QW,V4QW,_Z4QW);
                  Z6QW = si_dfma(X00QW,V6QW,_Z6QW);
                  Z0QW = si_dfma(X11QW,V8QW, Z0QW);
                  Z2QW = si_dfma(X11QW,V10QW, Z2QW);
                  Z4QW = si_dfma(X11QW,V12QW, Z4QW);
                  Z6QW = si_dfma(X11QW,V14QW, Z6QW);
                  Z0QW = si_dfma(X22QW,V16QW, Z0QW);
                  Z2QW = si_dfma(X22QW,V18QW, Z2QW);
                  Z4QW = si_dfma(X22QW,V20QW, Z4QW);
                  Z6QW = si_dfma(X22QW,V22QW, Z6QW);
                  Z0QW = si_dfma(X33QW,V24QW, Z0QW);
                  Z2QW = si_dfma(X33QW,V26QW, Z2QW);
                  Z4QW = si_dfma(X33QW,V28QW, Z4QW);
                  Z6QW = si_dfma(X33QW,V30QW, Z6QW);
                  Z0QW = si_dfma(X44QW,V32QW, Z0QW);
                  Z2QW = si_dfma(X44QW,V34QW, Z2QW);
                  Z4QW = si_dfma(X44QW,V36QW, Z4QW);
                  Z6QW = si_dfma(X44QW,V38QW, Z6QW);
                  Z0QW = si_dfma(X55QW,V40QW, Z0QW);
                  Z2QW = si_dfma(X55QW,V42QW, Z2QW);
                  Z4QW = si_dfma(X55QW,V44QW, Z4QW);
                  Z6QW = si_dfma(X55QW,V46QW, Z6QW);
                  Z0QW = si_dfma(X66QW,V48QW, Z0QW);
                  Z2QW = si_dfma(X66QW,V50QW, Z2QW);
                  Z4QW = si_dfma(X66QW,V52QW, Z4QW);
                  Z6QW = si_dfma(X66QW,V54QW, Z6QW);
                  Z0QW = si_dfma(X77QW,V56QW, Z0QW);
                  Z2QW = si_dfma(X77QW,V58QW, Z2QW);
                  Z4QW = si_dfma(X77QW,V60QW, Z4QW);
                  Z6QW = si_dfma(X77QW,V62QW, Z6QW);
       __YByteOffsetQW = _YByteOffsetQW;

    // V, splat X, same Row - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 X00QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble0QW);
                 X11QW = si_shufb(X01QW,X01QW,(qword)ReplicateDouble1QW);
                 X22QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble0QW);
                 X33QW = si_shufb(X23QW,X23QW,(qword)ReplicateDouble1QW);
                 X44QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble0QW);
                 X55QW = si_shufb(X45QW,X45QW,(qword)ReplicateDouble1QW);
                 X66QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble0QW);
                 X77QW = si_shufb(X67QW,X67QW,(qword)ReplicateDouble1QW);
                  V0QW = si_lqx(si_from_ptr((void*)V0),si_from_uint(VByteOffset));
                  V2QW = si_lqx(si_from_ptr((void*)V2),si_from_uint(VByteOffset));
                  V4QW = si_lqx(si_from_ptr((void*)V4),si_from_uint(VByteOffset));
                  V6QW = si_lqx(si_from_ptr((void*)V6),si_from_uint(VByteOffset));
                  V8QW = si_lqx(si_from_ptr((void*)V8),si_from_uint(VByteOffset));
                 V10QW = si_lqx(si_from_ptr((void*)V10),si_from_uint(VByteOffset));
                 V12QW = si_lqx(si_from_ptr((void*)V12),si_from_uint(VByteOffset));
                 V14QW = si_lqx(si_from_ptr((void*)V14),si_from_uint(VByteOffset));
                 V16QW = si_lqx(si_from_ptr((void*)V16),si_from_uint(VByteOffset));
                 V18QW = si_lqx(si_from_ptr((void*)V18),si_from_uint(VByteOffset));
                 V20QW = si_lqx(si_from_ptr((void*)V20),si_from_uint(VByteOffset));
                 V22QW = si_lqx(si_from_ptr((void*)V22),si_from_uint(VByteOffset));
                 V24QW = si_lqx(si_from_ptr((void*)V24),si_from_uint(VByteOffset));
                 V26QW = si_lqx(si_from_ptr((void*)V26),si_from_uint(VByteOffset));
                 V28QW = si_lqx(si_from_ptr((void*)V28),si_from_uint(VByteOffset));
                 V30QW = si_lqx(si_from_ptr((void*)V30),si_from_uint(VByteOffset));
                 V32QW = si_lqx(si_from_ptr((void*)V32),si_from_uint(VByteOffset));
                 V34QW = si_lqx(si_from_ptr((void*)V34),si_from_uint(VByteOffset));
                 V36QW = si_lqx(si_from_ptr((void*)V36),si_from_uint(VByteOffset));
                 V38QW = si_lqx(si_from_ptr((void*)V38),si_from_uint(VByteOffset));
                 V40QW = si_lqx(si_from_ptr((void*)V40),si_from_uint(VByteOffset));
                 V42QW = si_lqx(si_from_ptr((void*)V42),si_from_uint(VByteOffset));
                 V44QW = si_lqx(si_from_ptr((void*)V44),si_from_uint(VByteOffset));
                 V46QW = si_lqx(si_from_ptr((void*)V46),si_from_uint(VByteOffset));
                 V48QW = si_lqx(si_from_ptr((void*)V48),si_from_uint(VByteOffset));
                 V50QW = si_lqx(si_from_ptr((void*)V50),si_from_uint(VByteOffset));
                 V52QW = si_lqx(si_from_ptr((void*)V52),si_from_uint(VByteOffset));
                 V54QW = si_lqx(si_from_ptr((void*)V54),si_from_uint(VByteOffset));
                 V56QW = si_lqx(si_from_ptr((void*)V56),si_from_uint(VByteOffset));
                 V58QW = si_lqx(si_from_ptr((void*)V58),si_from_uint(VByteOffset));
                 V60QW = si_lqx(si_from_ptr((void*)V60),si_from_uint(VByteOffset));
                 V62QW = si_lqx(si_from_ptr((void*)V62),si_from_uint(VByteOffset));
          VByteOffset += 512;
                  Y0QW = si_lqx(si_from_ptr((void*)Y0),YByteOffsetQW);
                  Y2QW = si_lqx(si_from_ptr((void*)Y2),YByteOffsetQW);
                  Y4QW = si_lqx(si_from_ptr((void*)Y4),YByteOffsetQW);
                  Y6QW = si_lqx(si_from_ptr((void*)Y6),YByteOffsetQW);
             SameRowQW = si_ceq(_YByteOffsetQW,YByteOffsetQW);
        _YByteOffsetQW =  YByteOffsetQW;

    // XBA, YBA, X, X splat control word - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
         XByteOffsetQW = si_shli(C32SplatQW,3);
         YByteOffsetQW = si_shli(R32SplatQW,3);
                 X01QW = si_lqx(si_from_ptr((void*)X0),XByteOffsetQW);
                 X23QW = si_lqx(si_from_ptr((void*)X2),XByteOffsetQW);
                 X45QW = si_lqx(si_from_ptr((void*)X4),XByteOffsetQW);
                 X67QW = si_lqx(si_from_ptr((void*)X6),XByteOffsetQW);

    // Splat R16 to R32, Splat C16 to C32, update splat control word- - - - - - - - - - - - - - - - - - - - - - -
         C32SplatQW = si_shufb(C16QW,ZeroQW,SplatShortToWordControl);
         R32SplatQW = si_shufb(R16QW,ZeroQW,SplatShortToWordControl);
        SplatShortToWordControl = si_and(si_ah(SplatShortToWordControl,SplatShortToWordIncrement),SplatShortToWordMask);

    // R16QW, C16QW, RotateAmount - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                   C16QW = si_lqx(si_from_ptr((void*)C),si_from_uint(RCByteOffset));
                   R16QW = si_lqx(si_from_ptr((void*)R),si_from_uint(RCByteOffset));
        RCByteOffset += 2;

    // Loop Overhead - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    TilesRemaining--;
  }//===========================================================================================================



}
