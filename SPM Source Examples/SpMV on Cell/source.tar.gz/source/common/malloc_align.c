void *malloc_align(int size, int align_size) {
  void *ptr,*ptr2,*aligned_ptr;
  int align_mask = align_size - 1;

  ptr=(void *)malloc(size + align_size + sizeof(int));
  if(ptr==NULL) return(NULL);

  ptr2 = ptr + sizeof(int); // reserve space for a int
  aligned_ptr = ptr2 + (align_size - ((size_t)ptr2 & align_mask)); // align


  ptr2 = aligned_ptr - sizeof(int); // int right before returned pointer contains data
  *((int *)ptr2)=(int)(aligned_ptr - ptr);

  return(aligned_ptr);
}

void free_align(void *ptr) {
  int *ptr2=(int *)ptr - 1;
  ptr -= *ptr2;
  free(ptr);
}
