// SpMV optimization routines
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

uint64_t TotalBytes;
uint32_t TNZ;
uint32_t TDMAs;
uint32_t TCOLs;
uint32_t *pad_malloc;

//  double * LargeV=NULL;
//uint32_t * LargeR=NULL;
//uint32_t * LargeC=NULL;

uint32_t logu(uint32_t x){
  switch(x){
    case  1:return(0);break;
    case  2:return(1);break;
    case  4:return(2);break;
    case  8:return(3);break;
    case 16:return(4);break;
  }
  return(0);
}

void Optimize_SparseMatrix(SparseMatrix *dest, uint64_t thr,uint32_t OptimizationMask){
  uint64_t TotalTiles[RegBlock_MaxR+1][RegBlock_MaxC+1]; // only care about certain combinations
  uint32_t r,c,i;
  for(r=0;r<=RegBlock_MaxR;r++)for(c=0;c<=RegBlock_MaxC;c++)TotalTiles[r][c]=0;

  Affinity_Bind_Memory(thr);

  uint32_t LargeTiles = (dest->NRows/RegBlock_MaxR)*(dest->NCols/RegBlock_MaxC);
  if(dest->ActualNonZeros<LargeTiles)LargeTiles=dest->ActualNonZeros;
  LargeTiles++;
  //printf("Large Tiles = %d\n",LargeTiles);

  // FIX determine LargeTiles first
    double * LargeV = (  double*)MALLOC(RegBlock_MaxR*RegBlock_MaxC*LargeTiles*sizeof(  double));
  uint32_t * LargeR = (uint32_t*)MALLOC(                            LargeTiles*sizeof(uint32_t));
  uint32_t * LargeC = (uint32_t*)MALLOC(                            LargeTiles*sizeof(uint32_t));
  if(LargeV==NULL){printf("LargeV == NULL !!!\n");exit(0);}
  if(LargeR==NULL){printf("LargeR == NULL !!!\n");exit(0);}
  if(LargeC==NULL){printf("LargeC == NULL !!!\n");exit(0);}

  // reencode 1x1 into Large Tile value/RC temp arrays (on the fly ??) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  uint32_t RSize,CSize;
  uint32_t R,C;
  uint32_t P[RegBlock_MaxR]; // pointers for max register block
  uint32_t LTOfs=0;
  uint32_t BlockNZ=0;
  int32_t FirstRow=-1;
  int32_t LastRow=-1;

  P[0]=0;
  for(R=0;R<dest->NRows;R+=RegBlock_MaxR){
    // when done, P[r] should point to the first nonzero on row: R+r
                                             while( (P[0] < dest->NTiles) && (dest->R32b[P[0]]<(R  )) )P[0]++;
    for(r=1;r<RegBlock_MaxR;r++){P[r]=P[r-1];while( (P[r] < dest->NTiles) && (dest->R32b[P[r]]<(R+r)) )P[r]++;}

    // check and see if there are any nonzeros left in this blocked row
    uint32_t ThereAreNonZerosLeftInThisBlockedRow = 0;
    for(r=0;r<RegBlock_MaxR;r++)if( (P[r] < dest->NTiles) && (dest->R32b[P[r]] == (R+r)) )ThereAreNonZerosLeftInThisBlockedRow=1;

    while(ThereAreNonZerosLeftInThisBlockedRow){

      // determine the column index of the next tile
      uint32_t MinC = 0xFFFFFFFF;
      for(r=0;r<RegBlock_MaxR;r++)if( (P[r] < dest->NTiles) && (dest->R32b[P[r]] == (R+r)) && (dest->C32b[P[r]] < MinC) )MinC=dest->C32b[P[r]];
      MinC = RegBlock_MaxC*(MinC/RegBlock_MaxC);

      // initialize a tile
      for(i=0;i<=RegBlock_MaxR*RegBlock_MaxC;i++)LargeV[RegBlock_MaxR*RegBlock_MaxC*LTOfs+i]=0.0;
      LargeR[LTOfs]=R;
      LargeC[LTOfs]=MinC;
      if(FirstRow==-1)FirstRow=R;
      LastRow=R+RegBlock_MaxR;

      // for all rows in tile, scan forward until out of tile
      for(r=0;r<RegBlock_MaxR;r++){
        while( (P[r] < dest->NTiles) && (dest->R32b[P[r]] == (R+r)) && ((dest->C32b[P[r]]-MinC)<RegBlock_MaxC) ){
  	  LargeV[RegBlock_MaxR*RegBlock_MaxC*LTOfs+RegBlock_MaxR*(dest->C32b[P[r]]-MinC)+r] = dest->V[P[r]];
	  BlockNZ++;
  	  P[r]++;
	}
      } // finished a new tile
      LTOfs++;

      ThereAreNonZerosLeftInThisBlockedRow = 0;
      for(r=0;r<RegBlock_MaxR;r++)if( (P[r] < dest->NTiles) && (dest->R32b[P[r]] == (R+r)) )ThereAreNonZerosLeftInThisBlockedRow=1;
    }
  }
  LargeTiles = LTOfs;
  if(BlockNZ != dest->ActualNonZeros){printf("%sERROR - expected %d nonzeros, but only %d were found%s\n",CRT_ERROR,dest->ActualNonZeros,BlockNZ,CRT_RESET);exit(0);}

  // Calculate TotalTiles for each RxC blocking - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  uint32_t MaxRSize = RegBlock_MinR;
  uint32_t MaxCSize = RegBlock_MinC;
  if(OptimizationMask & OPTIMIZATION_REGISTER){
    MaxRSize = RegBlock_MaxR;
    MaxCSize = RegBlock_MaxC;
  }

  for(i=0,LTOfs=0;i<LargeTiles;i++,LTOfs+=RegBlock_MaxR*RegBlock_MaxC){

    //#include "analyze.c"

    for(RSize=RegBlock_MinR;RSize<=MaxRSize;RSize*=2){for(CSize=RegBlock_MinC;CSize<=MaxCSize;CSize*=2){
     for(R=0;R<RegBlock_MaxR;R+=RSize){for(C=0;C<RegBlock_MaxC;C+=CSize){
        uint32_t NonZeroTile=0;
        for(r=R;(r<R+RSize)&&(!NonZeroTile);r++){for(c=C;(c<C+CSize)&&(!NonZeroTile);c++){
          if(LargeV[LTOfs+RegBlock_MaxR*c+r]!=0.0)NonZeroTile=1;
        }}
      TotalTiles[RSize][CSize]+=NonZeroTile;
      //printf("%d %d = %d\n",RSize,CSize,TotalTiles[RSize][CSize]);
      }}
    }}
    
  }
  
  //printf("%d %d..%d=%d\n",dest->NRows,FirstRow,LastRow,LastRow-FirstRow);
  // find which Format has minimum total bytes (RxC x {CSR,COO}) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  uint32_t BestFormat = 0xFFFF;
  uint32_t BestTiles = 0;
  uint32_t BestR = 0;
  uint32_t BestC = 0;
  uint32_t IndexSizeInBits = 32;
  if((ENABLE_16b)&&(dest->NRows < 65536)&&(dest->NCols < 65536))IndexSizeInBits=16;
  if((ENABLE_16b)&&(dest->NRows < 65536)&&(dest->SourceCompression==SPARSE_VECTOR_FOR_DMA))IndexSizeInBits=16;
  if((ENABLE_16b)&&(dest->NRows < 65536)&&(dest->ColumnsTransfered< 65536)&&(dest->SourceCompression==SPARSE_VECTOR_FOR_COPY))IndexSizeInBits=16;
  uint64_t MinimumSize = 0x7FFFFFFF;

  //printf("\n");
  // Try BCSR ...
  if((ENABLE_FORMATS>>FORMAT_BCSR)&0x1)for(RSize=MaxRSize;RSize>=RegBlock_MinR;RSize=RSize>>1){for(CSize=MaxCSize;CSize>=RegBlock_MinC;CSize=CSize>>1){
  //if((ENABLE_FORMATS>>FORMAT_BCSR)&0x1)for(RSize=RegBlock_MaxR;RSize>=RegBlock_MinR;RSize=RSize>>1){for(CSize=RegBlock_MaxC;CSize>=RegBlock_MinC;CSize=CSize>>1){
    uint64_t testSize=0;
    testSize += 8*RSize*CSize*TotalTiles[RSize][CSize]; // Filled tile
    testSize +=   1*(IndexSizeInBits>>3)*TotalTiles[RSize][CSize]; // Column Index per tile
    testSize += 4*(1 + ((LastRow-FirstRow)/RSize)); // Row pointers
    //printf("  BCSR: %d %d x %d tiles, %d rows, %d bytes\n",TotalTiles[RSize][CSize],RSize,CSize,LastRow-FirstRow,testSize);
    //if(testSize<MinimumSize){ // always wins?
    if( (double)testSize<0.95*(double)MinimumSize ){ // always wins?
      BestTiles = TotalTiles[RSize][CSize];
      BestR = RSize;
      BestC = CSize;
      MinimumSize = testSize;
      BestFormat = FORMAT_BCSR;
    }
  }}
  // Try BCOO ...
  if((ENABLE_FORMATS>>FORMAT_BCOO)&0x1)for(RSize=MaxRSize;RSize>=RegBlock_MinR;RSize=RSize>>1){for(CSize=MaxCSize;CSize>=RegBlock_MinC;CSize=CSize>>1){
  //if((ENABLE_FORMATS>>FORMAT_BCOO)&0x1)for(RSize=RegBlock_MaxR;RSize>=RegBlock_MinR;RSize=RSize>>1){for(CSize=RegBlock_MaxC;CSize>=RegBlock_MinC;CSize=CSize>>1){
    uint64_t testSize=0;
    testSize += 8*RSize*CSize*TotalTiles[RSize][CSize]; // Filled tile
    testSize +=   2*(IndexSizeInBits>>3)*TotalTiles[RSize][CSize]; // Row & Column coordinate per tile
    //printf("  BCOO: %d %d x %d tiles, %d rows, %d bytes\n",TotalTiles[RSize][CSize],RSize,CSize,LastRow-FirstRow,testSize);
    if( ((BestFormat==FORMAT_BCOO)&&(testSize<MinimumSize)) || ((double)testSize<0.95*(double)MinimumSize)){ // wins if more than 5% smaller than BCSR
      BestTiles = TotalTiles[RSize][CSize];
      BestR = RSize;
      BestC = CSize;
      MinimumSize = testSize;
      BestFormat = FORMAT_BCOO;
    }
  }}


  // MALLOC arrays - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  dest->P   =NULL;
  dest->V   =NULL;
  dest->C16b=NULL;
  dest->C32b=NULL;
  dest->R16b=NULL;
  dest->R32b=NULL;

  //                           dest->V    = (  double*)MALLOC((BestR*BestC*TotalTiles[BestR][BestC])*sizeof(  double));
  //  if(IndexSizeInBits==16)  dest->C16b = (uint16_t*)MALLOC((            TotalTiles[BestR][BestC])*sizeof(uint16_t)); // needs a column in both csr and coo
  //  if(IndexSizeInBits==32)  dest->C32b = (uint32_t*)MALLOC((            TotalTiles[BestR][BestC])*sizeof(uint32_t)); // needs a column in both csr and coo
  //if(BestFormat==FORMAT_BCSR)dest->P    = (uint32_t*)MALLOC((1 + (dest->NRows/BestR))*sizeof(uint32_t));
  //if(BestFormat==FORMAT_BCOO){
  //  if(IndexSizeInBits==16)  dest->R16b = (uint16_t*)MALLOC((          1+TotalTiles[BestR][BestC])*sizeof(uint16_t));
  //  if(IndexSizeInBits==32)  dest->R32b = (uint32_t*)MALLOC((          1+TotalTiles[BestR][BestC])*sizeof(uint32_t));
  //}

  dest->base1Size=10*CacheLineSizeInDoubles*sizeof(double); // enough pad to align 10 pointers
                              dest->base1Size += (BestR*BestC*TotalTiles[BestR][BestC])*sizeof(  double);
    if(IndexSizeInBits==16)   dest->base1Size +=             (TotalTiles[BestR][BestC])*sizeof(uint16_t); // needs a column in both csr and coo
    if(IndexSizeInBits==32)   dest->base1Size +=             (TotalTiles[BestR][BestC])*sizeof(uint32_t); // needs a column in both csr and coo
  if(BestFormat==FORMAT_BCSR) dest->base1Size +=              (1 + (dest->NRows/BestR))*sizeof(uint32_t); // only needs row pointers
  if(BestFormat==FORMAT_BCOO){
    if(IndexSizeInBits==16)   dest->base1Size +=           (1+TotalTiles[BestR][BestC])*sizeof(uint16_t); // needs row coordinate
    if(IndexSizeInBits==32)   dest->base1Size +=           (1+TotalTiles[BestR][BestC])*sizeof(uint32_t); // needs row coordinate
  }
  dest->base1 = (void*)NUMA_MALLOC(dest->base1Size,thr);
  void*_base1=dest->base1;
                                                            _base1 =(void*)(((uint64_t)_base1 + CacheLineSizeInDoubles*sizeof(double) - 1) & ~(CacheLineSizeInDoubles*sizeof(double)-1));
                              dest->V    = (  double*)_base1;_base1+=(BestR*BestC*TotalTiles[BestR][BestC])*sizeof(  double);
                                                            _base1 =(void*)(((uint64_t)_base1 + CacheLineSizeInDoubles*sizeof(double) - 1) & ~(CacheLineSizeInDoubles*sizeof(double)-1));
    if(IndexSizeInBits==16){  dest->C16b = (uint16_t*)_base1;_base1+=            (TotalTiles[BestR][BestC])*sizeof(uint16_t);}
    if(IndexSizeInBits==32){  dest->C32b = (uint32_t*)_base1;_base1+=            (TotalTiles[BestR][BestC])*sizeof(uint32_t);}
                                                            _base1 =(void*)(((uint64_t)_base1 + CacheLineSizeInDoubles*sizeof(double) - 1) & ~(CacheLineSizeInDoubles*sizeof(double)-1));
  if(BestFormat==FORMAT_BCSR){dest->P    = (uint32_t*)_base1;_base1+=             (1 + (dest->NRows/BestR))*sizeof(uint32_t);}
  if(BestFormat==FORMAT_BCOO){
    if(IndexSizeInBits==16){  dest->R16b = (uint16_t*)_base1;_base1+=          (1+TotalTiles[BestR][BestC])*sizeof(uint16_t);}
    if(IndexSizeInBits==32){  dest->R32b = (uint32_t*)_base1;_base1+=          (1+TotalTiles[BestR][BestC])*sizeof(uint32_t);}
  }

  // create array of pointers & init to 0
  // while NZs processed < Total tiles, for each pointer, advance to end of row adding nonzeros
  uint32_t TileStart=0,TileEnd=0,SmallTileOffset=0;

  if(dest->P!=NULL)for(r=0;r<=(dest->NRows/BestR);r++)dest->P[r]=0;

  dest->NTiles = BestTiles;
  dest->Format = BestFormat;
  if(IndexSizeInBits==16)dest->Bits=0;
  if(IndexSizeInBits==32)dest->Bits=1;
  dest->logR = logu(BestR);
  dest->logC = logu(BestC);
  dest->FirstRow = FirstRow/BestR;
  dest->LastRow = LastRow/BestR;


  while(TileStart < LargeTiles){
    for(R=0;R<RegBlock_MaxR;R+=BestR){ // All small blocked rows within large blocked row
      TileEnd=TileStart;
      while((TileEnd<LargeTiles)&&(LargeR[TileEnd] == LargeR[TileStart])){ // all tiles in this blocked row
        for(C=0;C<RegBlock_MaxC;C+=BestC){ // All small blocked columns within large tile
	  uint32_t Empty=1;  // Determine if small tile is not empty
          for(r=0;(r<BestR)&&(Empty);r++){for(c=0;(c<BestC)&&(Empty);c++){
  	    if(LargeV[RegBlock_MaxR*RegBlock_MaxC*TileEnd + (C+c)*RegBlock_MaxR + (R+r)]!=0.0)Empty=0;
	  }}
          if(!Empty){ // Add a small tile
            if(dest->C16b!=NULL)dest->C16b[SmallTileOffset] = LargeC[TileEnd]+C;
            if(dest->C32b!=NULL)dest->C32b[SmallTileOffset] = LargeC[TileEnd]+C;
            if(dest->R16b!=NULL)dest->R16b[SmallTileOffset] = LargeR[TileEnd]+R;
            if(dest->R32b!=NULL)dest->R32b[SmallTileOffset] = LargeR[TileEnd]+R;
            if(dest->P   !=NULL)dest->P[1 + ((LargeR[TileEnd]+R)/BestR)]++; // Histogram row counts
            for(r=0;r<BestR;r++){for(c=0;c<BestC;c++){
              dest->V[BestR*BestC*SmallTileOffset + BestR*c + r] = LargeV[RegBlock_MaxR*RegBlock_MaxC*TileEnd + (C+c)*RegBlock_MaxR + (R+r)];
	    }}
  	    SmallTileOffset++;
	  }
	}
        TileEnd++;
      }
    }
    TileStart=TileEnd;
  }

  if(dest->R16b!=NULL)dest->R16b[SmallTileOffset] = 0xFFFF;
  if(dest->R32b!=NULL)dest->R32b[SmallTileOffset] = 0xFFFFFFFF;
  if(dest->P!=NULL)for(r=0;r<(dest->NRows/BestR);r++)dest->P[r+1]+=dest->P[r]; // Turn histogram into row pointers

#ifdef VERBOSE_SUMMARY
  printf("cache block: %7d x %7d(%7d doubles in %5d stanzas) @ (%7d,%7d) : %9d nonzeros ",dest->NRows,dest->NCols,dest->ColumnsTransfered,dest->DMAStanzas,dest->ROffset,dest->COffset,dest->ActualNonZeros);
  fflush(stdout);
#endif

  TNZ+=dest->ActualNonZeros;
  TCOLs+=dest->ColumnsTransfered;
  TDMAs+=dest->DMAStanzas;
  #ifdef VERBOSE_SUMMARY
       if(BestFormat==FORMAT_BCSR){
         if( (dest->FirstRow) || (dest->LastRow != (dest->NRows/BestR)) )printf("in %8d %dx%d %db BCSR tiles(%6d..%6d) ",BestTiles,BestR,BestC,IndexSizeInBits,dest->FirstRow,dest->LastRow);
                                                            else printf("in %8d %dx%d %db BCSR tiles ",BestTiles,BestR,BestC,IndexSizeInBits);
       }
  else if(BestFormat==FORMAT_BCOO)printf("in %8d %dx%d %db BCOO tiles ",BestTiles,BestR,BestC,IndexSizeInBits);
  else {printf("%sERROR - Unknown Format - %d%s\n",CRT_ERROR,BestFormat,CRT_RESET);exit(0);}
  printf("\n");
  #endif

  TotalBytes+=MinimumSize + 8*dest->ColumnsTransfered + 8*dest->DMAStanzas;

  FREE(LargeC);
  FREE(LargeR);
  FREE(LargeV);

}

void Optimize_BlockedSparseMatrix(BlockedSparseMatrix * BlockedSpA){

  //uint32_t LargeTiles = (BlockedSpA->NRows/RegBlock_MaxR)*(BlockedSpA->NCols/RegBlock_MaxC);
  //if(BlockedSpA->ActualNonZeros<LargeTiles)LargeTiles=BlockedSpA->ActualNonZeros;
  //LargeTiles++;
  //printf("Large Tiles = %d\n",LargeTiles);
  ///*if(LargeV==NULL)*/LargeV = (  double*)MALLOC(RegBlock_MaxR*RegBlock_MaxC*LargeTiles*sizeof(  double));
  ///*if(LargeR==NULL)*/LargeR = (uint32_t*)MALLOC(                            LargeTiles*sizeof(uint32_t));
  ///*if(LargeC==NULL)*/LargeC = (uint32_t*)MALLOC(                            LargeTiles*sizeof(uint32_t));

  TotalBytes = 0;
  TNZ=0;
  TDMAs=0;
  TCOLs=0;
  if(RegBlock_MaxR>CacheLineSizeInDoubles){printf("%sERROR - RegBlock_MaxR > CacheLineSizeInDoubles%s\n",CRT_ERROR,CRT_RESET);exit(0);}
  if(RegBlock_MaxC>CacheLineSizeInDoubles){printf("%sERROR - RegBlock_MaxC > CacheLineSizeInDoubles%s\n",CRT_ERROR,CRT_RESET);exit(0);}
  if(CacheLineSizeInDoubles%RegBlock_MaxR){printf("%sERROR - CacheLineSizeInDoubles must be a multiple of RegBlock_MaxR%s\n",CRT_ERROR,CRT_RESET);exit(0);}
  if(CacheLineSizeInDoubles%RegBlock_MaxC){printf("%sERROR - CacheLineSizeInDoubles must be a multiple of RegBlock_MaxC%s\n",CRT_ERROR,CRT_RESET);exit(0);}

  printf("Copying and Optimizing cache blocks...");fflush(stdout);

  uint32_t b,thread;
  #ifdef VERBOSE_SUMMARY
  printf("\nSummary:\n");
  #endif

  uint64_t ThreadToAllocateOn = 0;
  thread=0;
  //for(b=0;b<MaxThreads;b++){printf("%d %d\n",b,BlockedSpA->FirstBlockForThread[b]);}
  for(b=0;b<BlockedSpA->FirstBlockForThread[MaxThreads];b++){
    if(b==BlockedSpA->FirstBlockForThread[thread]){
      #ifdef VERBOSE_SUMMARY
      printf("  thread %3d: ",thread);
      #endif
      ThreadToAllocateOn=thread;
      thread++;
    }else{
      #ifdef VERBOSE_SUMMARY
      printf("              ");
      #endif
    }
    fflush(stdout);
    Optimize_SparseMatrix(&BlockedSpA->blocks[b],ThreadToAllocateOn,BlockedSpA->OptimizationMask); 
  }
  #ifdef VERBOSE_SUMMARY
  printf("                                            (%7d doubles in %5d stanzas)                       %9d nonzeros total\n",TCOLs,TDMAs,TNZ);
  #endif

  //TotalBytes+=8*BlockedSpA->NRows; // FIX - 16 if cache machines??
  if(BlockedSpA->blocks[0].SourceCompression==SPARSE_VECTOR_FOR_DMA){TotalBytes+= 8*BlockedSpA->NRows;}
                                                                else{TotalBytes+=16*BlockedSpA->NRows;}
  TotalBytes+=sizeof(SparseMatrix)*BlockedSpA->FirstBlockForThread[MaxThreads];
  //printf("%d TotalBytes\n",TotalBytes);
  BlockedSpA->FlopToByteRatio = 2.0*(double)BlockedSpA->ActualNonZeros / (double)TotalBytes;
  printf("%s~%3.3f%s flop:byte ratio\n",CRT_DONE,BlockedSpA->FlopToByteRatio,CRT_RESET);

  //printf("%sdone%s\n",CRT_DONE,CRT_RESET);
  //printf("\n");
  
  Affinity_unBind();

  //FREE(LargeC);
  //FREE(LargeR);
  //FREE(LargeV);
}
