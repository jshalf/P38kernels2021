eval 'exec perl $0 $*'
        if 0;

$SSE=0;
$DoubleHummer=0;

$NumArgs = $#ARGV+1;

$ARGV0 = $ARGV[0];
$ARGV0 =~ tr/A-Z/a-z/;

if($NumArgs > 1){
  print "max one architecture per invocation - ./generate_kernels.pl [arch]\n";
  exit(0);
}

#                                                                       print "Generating c kernels in ./generic\n";
#if($NumArgs == 1){
#     if($ARGV0 eq "sse"         ){$PATH="./x86/";    $SSE          = 1;print "Generating sse kernels in ./x86\n";}
#  elsif($ARGV0 eq "doublehummer"){$PATH="./bgl/";    $DoubleHummer = 1;print "Generating double hummer kernels in ./bgl\n";}
#  else                           {print "unknown argument - $ARGV0\n";exit(0);}
#}
#
#if(!(-d $PATH)){
#  print "$PATH does not exist\n";
#  exit(0);
#}

$MaxU = 8;
#require "./collision.naive.pl";
#================================================================================
open(H,">./kernels.h");open(F,">./kernels.c");
for($GlobalO=0;$GlobalO<16;$GlobalO++){for($GlobalU=0;$GlobalU<$MaxU;$GlobalU++){$PTF[$GlobalO][$GlobalU]="NULL";}}
for($GlobalO=0;$GlobalO<16;$GlobalO++){for($GlobalU=0;$GlobalU<$MaxU;$GlobalU++){&kernels($GlobalO,$GlobalU,@PTF);}}
close(F);close(H);

#================================================================================
open(F,">./variables.c");
print F "#define    UNROLLINGS $MaxU\n";
print F "void (*Stencil_Plane[16][UNROLLINGS])() = {\n";
#print F "  {\n";
for($GlobalO=0;$GlobalO<16;$GlobalO++){print F"    {";
  for($GlobalU=0;$GlobalU<$MaxU;$GlobalU++){
    printf(F"%15s",     $PTF[$GlobalO][$GlobalU]);
    if($GlobalU!=$MaxU-1){print F ", ";}
  }print F "}";if($GlobalO!=15){print F",";}print F "\n";
}
#print F "  }\n";
print F "};\n";
close(F);
#================================================================================

# A = center
# B = faces
# G = edges
# D = vertices

# DGBA
# 0000 =  0
# 000x =  1
# 00x0 =  2
# 00xx =  3
# 0x00 =  4
# 0x0x =  5
# 0xx0 =  6
# 0xxx =  7
# x000 =  8
# x00x =  9
# x0x0 = 10
# x0xx = 11
# xx00 = 12
# xx0x = 13
# xxx0 = 14
# xxxx = 15

        

sub kernels{
  local($O,$U,@PTF)=@_;
  if($O!=3){return;}

  $BaseName =  "_stencil".$O."_u".$U;
  $PTF[$O][$U] = "&$BaseName";

  # heat equation
  print F "//====================================================================\n";
  print H "void $BaseName();\n";
  print F "void $BaseName(){\n";
  print F "  //variables - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n";
  print F "  //     0 1 2 3 4 5  \n";
  print F "  //         _ _      \n";  
  print F "  // 0   _ _|_:_|_ _  \n";
  for($y=1;$y<$MaxU+1;$y++){
  print F "  // $y  |_:_|_:_|_:_| \n";
  }
  print F "  // $y      |_:_|     \n";
  print F "  // z=0,1,2          \n";
  print F "  // t=  curr,next          \n";
  for($y=1;$y<$MaxU+1;$y++){print F "  qword                    curr_z0_y".$y."_x23_QW;\n";}
  print F "\n";
                      $y=0;{print F "  qword                    curr_z1_y".$y."_x23_QW;\n";}
  for($y=1;$y<$MaxU+1;$y++){print F "  qword curr_z1_y".$y."_x01_QW, curr_z1_y".$y."_x23_QW, curr_z1_y".$y."_x45_QW;\n";}
                $y=$MaxU+1;{print F "  qword                    curr_z1_y".$y."_x23_QW;\n";}
  print F "\n";
  for($y=1;$y<$MaxU+1;$y++){print F "  qword                    curr_z2_y".$y."_x23_QW;\n";}
  print F "\n";
  for($y=1;$y<$MaxU+1;$y++){print F "  qword curr_z1_y".$y."_x12_QW, curr_z1_y".$y."_x34_QW;\n";}
  print F "\n";
  for($y=1;$y<$MaxU+1;$y++){print F "  qword next_z1_y".$y."_x23_QW;\n";}
  print F "\n";
  print F "  uint32_t curr_z0_y0_x00_ByteAddress;\n";
  print F "  uint32_t curr_z1_y0_x00_ByteAddress;\n";
  print F "  uint32_t curr_z2_y0_x00_ByteAddress;\n";
  print F "  uint32_t next_z1_y0_x00_ByteAddress;\n";
  print F "  uint32_t YOffset = 0, DeltaYOffset = 8*((LocalPencilSize)<<3);\n";
  print F "\n";
  print F "  uint32_t floorCBYDim = Parameters.YDimPerBlock & ~($MaxU-1);\n";
 #print F "  if(rank==0)printf(\"\%d\\n\",$U);\n";
  print F "  uint32_t x,y;\n";

  $max = 2;
  if($U==0){$max=1;}
  for($p=0;$p<$max;$p++){

  if($p==0){
  print F "  // full loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
  print F "  for(y=0;y<floorCBYDim;y+=$MaxU){\n";
  $TempU = $MaxU;
  }else{
  print F "  // cleanup loops - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
  $TempU = $U;
  }

  print F "    curr_z0_y0_x00_ByteAddress = (uint32_t)ReadZm1  + YOffset + CacheLineSizeInBytes;\n";
  print F "    curr_z1_y0_x00_ByteAddress = (uint32_t)ReadZp0  + YOffset + CacheLineSizeInBytes;\n";
  print F "    curr_z2_y0_x00_ByteAddress = (uint32_t)ReadZp1  + YOffset + CacheLineSizeInBytes;\n";
  print F "    next_z1_y0_x00_ByteAddress = (uint32_t)WriteZp0 + YOffset;\n";

  for($y=1;$y<$TempU+1;$y++){
  print F "    curr_z1_y".$y."_x01_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_".$y."Rows_0Qwords)); // really _x01\n";
  print F "    curr_z1_y".$y."_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_".$y."Rows_1Qwords)); // really _x23\n";
  print F "    curr_z1_y".$y."_x34_QW = si_shufb(curr_z1_y".$y."_x01_QW,curr_z1_y".$y."_x45_QW,(qword)ABCD_to_BC_ControlWord);    // really _x12\n";
  }print F "\n";

  print F "    for(x=0;x<Parameters.XDimPerBlock;x+=2){\n";

  # same z
  $y=      0;print F "      curr_z1_y".$y."_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_".$y."Rows_1Qwords));\n";
  for($y=1;$y<$TempU+1;$y++){
  print F "      curr_z1_y".$y."_x23_QW = curr_z1_y".$y."_x45_QW;\n";
  print F "      curr_z1_y".$y."_x45_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_".$y."Rows_2Qwords));\n";
  }
  $y=$TempU+1;print F "      curr_z1_y".$y."_x23_QW = si_lqx(si_from_uint(curr_z1_y0_x00_ByteAddress),si_from_uint(Offset_".$y."Rows_1Qwords));\n";
  print F "\n";

  # other z's
  for($y=1;$y<$TempU+1;$y++){
  print F "      curr_z0_y".$y."_x23_QW = si_lqx(si_from_uint(curr_z0_y0_x00_ByteAddress),si_from_uint(Offset_".$y."Rows_1Qwords));\n";
  print F "      curr_z2_y".$y."_x23_QW = si_lqx(si_from_uint(curr_z2_y0_x00_ByteAddress),si_from_uint(Offset_".$y."Rows_1Qwords));\n";
  }print F "\n";

  # permutes for neighbors
  for($y=1;$y<$TempU+1;$y++){
  print F "      curr_z1_y".$y."_x12_QW = curr_z1_y".$y."_x34_QW;\n";
  print F "      curr_z1_y".$y."_x34_QW = si_shufb(curr_z1_y".$y."_x23_QW,curr_z1_y".$y."_x45_QW,(qword)ABCD_to_BC_ControlWord);\n";
  }print F "\n";

  # stencils
  for($y=1;$y<$TempU+1;$y++){
  $ym = $y-1;
  $yp = $y+1;
  print F "      next_z1_y".$y."_x23_QW = \n";
  print F "                          si_dfma((qword) BetaQW,curr_z2_y".$y ."_x23_QW, /* z+1 */ \n";
  print F "                          si_dfma((qword) BetaQW,curr_z0_y".$y ."_x23_QW, /* z-1 */ \n";
  print F "                          si_dfma((qword) BetaQW,curr_z1_y".$yp."_x23_QW, /* y+1 */ \n";
  print F "                          si_dfma((qword) BetaQW,curr_z1_y".$ym."_x23_QW, /* y-1 */ \n";
  print F "                          si_dfma((qword) BetaQW,curr_z1_y".$y ."_x34_QW, /* x-1 */ \n";
  print F "                          si_dfma((qword) BetaQW,curr_z1_y".$y ."_x12_QW, /* x+1 */ \n";
  print F "                           si_dfm((qword)AlphaQW,curr_z1_y".$y ."_x23_QW)))))));\n\n";
  }print F "\n";

  # stores
  for($y=1;$y<$TempU+1;$y++){
  $ym = $y-1;  # no y-1 ghost zone
  print F "      si_stqx(next_z1_y".$y."_x23_QW,si_from_uint(next_z1_y0_x00_ByteAddress),si_from_uint(Offset_".$ym."Rows_1Qwords));\n";
  }print F "\n";

  # increments
  print F "      curr_z0_y0_x00_ByteAddress += 16;\n";
  print F "      curr_z1_y0_x00_ByteAddress += 16;\n";
  print F "      curr_z2_y0_x00_ByteAddress += 16;\n";
  print F "      next_z1_y0_x00_ByteAddress += 16;\n";

  print F "    }\n";
  print F "    YOffset += DeltaYOffset;\n";

  if($p==0){
  print F "  }\n";
  }

  }

  print F "}\n";
}
