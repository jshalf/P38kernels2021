// SpMV HB format loader routines
//   Sam Williams (samw@cs.berkeley.edu)
//   University of California Berkeley
//   Lawrence Berkeley National Lab

// PS3 doesn't have enought DRAM (256MB) to read all the matrix - so just load the pattern
//#define READ_VALUES
// Read Harwell Boeing Format =======================================================================================================
struct NonZeroNode{
  uint32_t Row;
  uint32_t Col;
  #ifdef READ_VALUES
    double value;
  #endif
  struct NonZeroNode * next;
};
typedef struct NonZeroNode NonZeroNode;

void decode_format(char *FMT, int32_t *num, char *type, int32_t *characters, int32_t *mantissa){
  int32_t i;char c;
       if(sscanf(FMT,"(%d%c%d%c%d.%d)",&i,&c,num,type,characters,mantissa)==6){} // FIX kP format (scale)
  else if(sscanf(FMT,"(%d%c%d.%d)"          ,num,type,characters,mantissa)==4){}
  else if(sscanf(FMT,"(%d%c%d)"             ,num,type,characters)         ==3){}
  else {printf("ERROR - unknown format - '%s'\n",FMT);exit(0);}
}

SparseMatrix * LoadMatrix_HBF_to_CSR(char *fn, int32_t MakeUnsymmetric){
  //if(CacheLineSizeInDoubles<  1)CacheLineSizeInDoubles=  1;
  //if(CacheLineSizeInDoubles>128)CacheLineSizeInDoubles=128;
  // matrix is stored in CSC like format
  // must be converted to a blocked CSR format
  FILE *fp;
  char temp[100];
  int32_t i,j;
  int32_t ZerosInFile=0;
  int32_t ZerosInserted=0;
  int32_t nnzProcessed=0;
  SparseMatrix *SpA = (SparseMatrix *)MALLOC(sizeof(SparseMatrix));
  Init_SparseMatrix(SpA);

  printf("%s",CRT_RESET);

  fp = fopen(fn,"r");
  if(fp==NULL){fprintf(stderr, "couldn't open file %s\n",fn);exit(0);}
  printf("reading matrix in: %s...\n",fn);

  // load Header - - - - - - - - - - - - - - - - - - - - - - - - - - - -

  char L1[100];fgets(L1,100,fp);
         char TITLE[100];temp[71-00+1]='\0';sscanf(strncpy(temp,L1+00,71-00+1),"%s", TITLE   );// 00..71 = TITLE
         char   KEY[100];temp[79-72+1]='\0';sscanf(strncpy(temp,L1+72,79-72+1),"%s", KEY     );// 72..79 = KEY
  printf("TITLE='%s' KEY='%s'\n",TITLE,KEY);

  char L2[100];fgets(L2,100,fp);
            int32_t TOTLines;temp[13-00+1]='\0';sscanf(strncpy(temp,L2+00,13-00+1),"%d",&TOTLines);// 00..13 = Total number of lines excluding header
            int32_t PTRLines;temp[27-14+1]='\0';sscanf(strncpy(temp,L2+14,27-14+1),"%d",&PTRLines);// 14..27 = Number of lines for pointers
            int32_t INDLines;temp[41-28+1]='\0';sscanf(strncpy(temp,L2+28,41-28+1),"%d",&INDLines);// 28..41 = Number of lines for row (or variable) indices
            int32_t VALLines;temp[55-42+1]='\0';sscanf(strncpy(temp,L2+42,55-42+1),"%d",&VALLines);// 42..55 = Number of lines for numerical values
            int32_t RHSLines;temp[69-56+1]='\0';sscanf(strncpy(temp,L2+56,69-56+1),"%d",&RHSLines);// 56..69 = Number of lines for right-hand sides
  printf("TOTLines='%d' PTRLines='%d' INDLines='%d' VALLines='%d' RHSLines='%d'\n",TOTLines,PTRLines,INDLines,VALLines,RHSLines);
  
  char L3[100];fgets(L3,100,fp);
        char MXTYPE[100];temp[02-00+1]='\0';sscanf(strncpy(temp,L3+00,02-00+1),"%s", MXTYPE  );// 00 - 02 = Matrix type (see below) {RCP,SUHNZR,AE}
              int32_t   NROW;temp[27-14+1]='\0';sscanf(strncpy(temp,L3+14,27-14+1),"%d",&NROW    );// 14 - 27 = Number of rows (or variables)
              int32_t   NCOL;temp[41-28+1]='\0';sscanf(strncpy(temp,L3+28,41-28+1),"%d",&NCOL    );// 28 - 41 = Number of columns (or elements)
              int32_t NNZERO;temp[55-42+1]='\0';sscanf(strncpy(temp,L3+42,55-42+1),"%d",&NNZERO  );// 42 - 55 = Number of row (or variable) indices
              int32_t NELTVL;temp[69-56+1]='\0';sscanf(strncpy(temp,L3+56,69-56+1),"%d",&NELTVL  );// 56 - 69 = Number of elemental matrix entries
  printf("MXTYPE='%s' NROW='%d' NCOL='%d' NNZERO='%d' NELTVL='%d'\n",MXTYPE,NROW,NCOL,NNZERO,NELTVL);
       if( (MXTYPE[1] == 'U') || (MXTYPE[1] == 'u') ){MXTYPE[1]='U';}
  else if( (MXTYPE[1] == 'R') || (MXTYPE[1] == 'r') ){MXTYPE[1]='R';}
  else if( (MXTYPE[1] == 'S') || (MXTYPE[1] == 's') ){MXTYPE[1]='S';}
  else {printf("unknown matrix type - %s\n",MXTYPE);exit(0);}
       if( (MXTYPE[0] == 'p') ){MXTYPE[0]='P';}
  else if( (MXTYPE[0] == 'r') ){MXTYPE[0]='R';}
  uint32_t NRowsPadded = CacheLineSizeInDoubles*((NROW+CacheLineSizeInDoubles-1)/CacheLineSizeInDoubles);
  uint32_t NColsPadded = CacheLineSizeInDoubles*((NCOL+CacheLineSizeInDoubles-1)/CacheLineSizeInDoubles);

  char L4[100];fgets(L4,100,fp);
        char PTRFMT[100];temp[15-00+1]='\0';sscanf(strncpy(temp,L4+00,15-00+1),"%s" , PTRFMT  );// 00..15 = Format for pointers - get rid of ()'s
        char INDFMT[100];temp[31-16+1]='\0';sscanf(strncpy(temp,L4+16,31-16+1),"%s" , INDFMT  );// 16..31 = Format for row (or variable) indices  - get rid of ()'s
        char VALFMT[100];temp[51-32+1]='\0';sscanf(strncpy(temp,L4+32,51-32+1),"%s" , VALFMT  );// 32..51 = Format for numerical values of coefficient matrix  - get rid of ()'s
        char RHSFMT[100];temp[71-52+1]='\0';sscanf(strncpy(temp,L4+52,71-52+1),"%s" , RHSFMT  );// 52..71 = Format for numerical values of right-hand sides - get rid of ()'s
  printf("PTRFMT='%s' INDFMT='%s' VALFMT='%s' RHSFMT='%s'\n",PTRFMT,INDFMT,VALFMT,RHSFMT);
  
  if(RHSLines){
  char L5[100];fgets(L5,100,fp);
        char RHSType =L5[0];                                                                   //00..00 = Right-hand side type: (F=Full or M=same as Matrix)
        char RHSGuess=L5[1];                                                                   //01..01 = G if a starting vector(s) (Guess) is supplied. (RHSTYP)
        char RHSExact=L5[2];                                                                   //02..02 = X if an exact solution vector(s) is supplied.
              int32_t NRHS;  temp[27-14+1]='\0';sscanf(strncpy(temp,L5+14,27-14+1),"%d",&NRHS    );//14..27 = Number of right-hand sides (NRHS)
              int32_t NRHSIX;temp[41-28+1]='\0';sscanf(strncpy(temp,L5+28,41-28+1),"%d",&NRHSIX  );//28..41 = Number of row indices (NRHSIX)
    printf("RHSType='%c' RHSGuess='%c' RHSExact='%c' NRHS='%d' NRHSIX='%d'\n",RHSType,RHSGuess,RHSExact,NRHS,NRHSIX);
  }
  uint32_t PatternOnly = 0;
  if(VALLines==0)PatternOnly=1;
  if(MXTYPE[0]=='P')PatternOnly=1;

  // Decode Formats - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  int32_t PTRFMT_num,PTRFMT_chars,PTRFMT_mantissa;char PTRFMT_type;if(PTRLines)decode_format(PTRFMT,&PTRFMT_num,&PTRFMT_type,&PTRFMT_chars,&PTRFMT_mantissa);
  int32_t INDFMT_num,INDFMT_chars,INDFMT_mantissa;char INDFMT_type;if(INDLines)decode_format(INDFMT,&INDFMT_num,&INDFMT_type,&INDFMT_chars,&INDFMT_mantissa);
  int32_t VALFMT_num,VALFMT_chars,VALFMT_mantissa;char VALFMT_type;if(VALLines)decode_format(VALFMT,&VALFMT_num,&VALFMT_type,&VALFMT_chars,&VALFMT_mantissa);
//int32_t RHSFMT_num,RHSFMT_chars,RHSFMT_mantissa;char RHSFMT_type;if(RHSLines)decode_format(RHSFMT,&RHSFMT_num,&RHSFMT_type,&RHSFMT_chars,&RHSFMT_mantissa);
  //printf("%s -> %d %c %d %d\n",INDFMT,INDFMT_num,INDFMT_type,INDFMT_chars,INDFMT_mantissa);
  printf("%d(%d) x %d(%d), %d nonzeros\n",NRowsPadded,NROW,NColsPadded,NCOL,NNZERO);
 
  
  // Init Matrix / Choose strategies - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  SpA->NRows=NRowsPadded;
  SpA->FirstRow = 0;
  SpA->LastRow = SpA->NRows;
  SpA->NCols=NColsPadded;
  SpA->ROffset=0;
  SpA->COffset=0;
  SpA->SourceCompression=DENSE_VECTOR;
  SpA->Bits=1;
  SpA->Format=FORMAT_BCSR;
  SpA->logR=0;
  SpA->logC=0;
  SpA->InitY=1;
  SpA->P     = NULL;
  SpA->V     = NULL;
  SpA->C16b  = NULL;
  SpA->C32b  = NULL;
  SpA->R16b  = NULL;
  SpA->R32b  = NULL;

  // Read Matrix into array of nodes - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  char WorkingLine[100];

  printf("Reading Column Pointers...");fflush(stdout);
  int32_t CPValue, Column=0;
  int32_t * ColumnPointers = (int*)MALLOC((NCOL+1) * sizeof(int32_t));
  for(i=0;i<PTRLines;i++){
    fgets(WorkingLine,100,fp);
    for(j=0;j<PTRFMT_num;j++)if(Column <= NCOL){
      temp[PTRFMT_chars] = '\0';CPValue = atoi(strncpy(temp,WorkingLine + (PTRFMT_chars*j),PTRFMT_chars))-1; // -1 for conversion to arrays that start at 0
      ColumnPointers[Column] = CPValue;
      Column++;
    }
  }
  printf("%sdone%s\n",CRT_DONE,CRT_RESET);


  printf("Reading Row Indices...");fflush(stdout);
  NonZeroNode *ArrayOfNodes = (NonZeroNode*)MALLOC((NNZERO+100) * sizeof(NonZeroNode));
  int32_t  Node=0;
  int32_t VNode=0;
  int32_t RowValue;
  Column=0;
  for(i=0;i<INDLines;i++){
    fgets(WorkingLine,100,fp);
    for(j=0;j<INDFMT_num;j++){if(Node<NNZERO){
      temp[INDFMT_chars] = '\0';RowValue = atoi(strncpy(temp,WorkingLine + (INDFMT_chars*j),INDFMT_chars))-1; // -1 for conversion to arrays that start at 0
      ArrayOfNodes[Node].Row = RowValue;
      ArrayOfNodes[Node].Col = Column;
      ArrayOfNodes[Node].next = NULL;
      #ifdef READ_VALUES
        ArrayOfNodes[Node].value = 1.0; // FIX
      #endif
      Node++;
      while(ColumnPointers[Column+1] == Node)Column++;
    }}
  }
  //printf("%d\n",Node);
  printf("%sdone%s\n",CRT_DONE,CRT_RESET);


  VNode=Node;
  #ifdef READ_VALUES
  printf("Reading NonZero Values...");fflush(stdout);
  if(PatternOnly){
    printf("%sIGNORED (Pattern Only)%s\n",CRT_ERROR,CRT_RESET);
  }else
  {
    for(i=0;i<=NCOL;i++)ColumnPointers[i]=0;

    double NZValue;
     Node=0;
    VNode=0;
    for(i=0;i<VALLines;i++){
      fgets(WorkingLine,100,fp);
      for(j=0;j<VALFMT_num;j++){if(Node<NNZERO){
        temp[VALFMT_chars] = '\0';NZValue = atof(strncpy(temp,WorkingLine + (VALFMT_chars*j),VALFMT_chars));
	if(NZValue != 0.0){
	  ColumnPointers[ArrayOfNodes[Node].Col+1]++;
          ArrayOfNodes[VNode].Row = ArrayOfNodes[Node].Row;
          ArrayOfNodes[VNode].Col = ArrayOfNodes[Node].Col;
          ArrayOfNodes[VNode].next = NULL;
          ArrayOfNodes[VNode].value = NZValue; // FIX
	  VNode++;
	}
        Node++;
	if(NZValue==0.0)ZerosInFile++;
      }}
    }
    printf("%sdone%s\n",CRT_DONE,CRT_RESET);
    //printf("found %d explicit zeros in the file\n",ZerosInFile);
    printf("%d nonzeros, %d total\n",VNode,Node);
    for(i=0;i<NCOL;i++)ColumnPointers[i+1] += ColumnPointers[i];
  }
  #endif


  // Link nodes in node array into row pointer array - - - - - - - - - - - - - - - - - - - -
  printf("Internal conversion from CSC to CSR...");fflush(stdout);
  NonZeroNode ** ArrayOfLinkedListsOfNodes;
  ArrayOfLinkedListsOfNodes = MALLOC(SpA->NRows * sizeof(NonZeroNode *));
  for(i=0;i<(int32_t)SpA->NRows;i++)ArrayOfLinkedListsOfNodes[i] = NULL;
  //for(i=(NNZERO-1);i>=0;i--){
  for(i=(VNode-1);i>=0;i--){
    ArrayOfNodes[i].next = ArrayOfLinkedListsOfNodes[ArrayOfNodes[i].Row];
    ArrayOfLinkedListsOfNodes[ArrayOfNodes[i].Row] = &(ArrayOfNodes[i]);
  }
  printf("%sdone%s\n",CRT_DONE,CRT_RESET);

  // Create SpA's structures & copy data into them - - - - - - - - - - - - - -
  // allocate RowPointers
  printf("Allocating Row Pointer Structures...");fflush(stdout);
  SpA->P = (uint32_t *)MALLOC((SpA->NRows+1)*sizeof(uint32_t));
  printf("%sdone%s\n",CRT_DONE,CRT_RESET);

  // update RowPointers - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  printf("Counting actual nonzeros...");fflush(stdout);
  SpA->P[0] = 0;
  for(i=0;i<(int32_t)SpA->NRows;i++){
    SpA->P[i+1] = SpA->P[i];
    NonZeroNode * tPtr = ArrayOfLinkedListsOfNodes[i];
    while(tPtr){
      if(tPtr->Col >= SpA->NCols){printf("ERROR - NNZ.col too big - (%d,%d)\n",i,tPtr->Col);exit(0);}
      SpA->P[i+1]++; 
      tPtr = tPtr->next;
    }
    
    if((i<NROW)&&(MakeUnsymmetric)&&(MXTYPE[1] == 'S'))for(j=ColumnPointers[i];j<ColumnPointers[i+1];j++)if((ArrayOfNodes[j].Row != ArrayOfNodes[j].Col)
    #ifdef READ_VALUES
    &&(ArrayOfNodes[j].value != 0.0)
    #endif
    ){
      if(ArrayOfNodes[j].Row >= SpA->NCols){printf("ERROR - transposed NNZ.row too big - (%d,%d)\n",i,ArrayOfNodes[j].Row);exit(0);}
      if(ArrayOfNodes[j].Row <           i){printf("ERROR - transposed NNZ.row too small - (%d,%d)\n",ArrayOfNodes[j].Row,i);exit(0);}
      SpA->P[i+1]++; 
    }
    
    //printf("nonzeros in row %d: %d (%d thus far)\n",i,SpA->P[i+1]-SpA->P[i],SpA->P[i+1]);
  } 
  printf("%s%d%s\n",CRT_DONE,SpA->P[SpA->NRows],CRT_RESET);

  // allocate col's & values (function of size of blocked column) - - - - - - - - - - - - - - - - - - - -
  printf("Allocating Column and Data Arrays...");fflush(stdout);
  SpA->V     = (  double *)MALLOC(SpA->P[SpA->NRows] * sizeof(  double));
  SpA->C32b  = (uint32_t *)MALLOC(SpA->P[SpA->NRows] * sizeof(uint32_t));
  printf("%sdone%s\n",CRT_DONE,CRT_RESET);

  // for all NZ's in table, add to SpA's col/value pointers - - - - - - - - - - - - - - - - - - - - - - - 
  printf("Copying NonZeros into Column and Data Arrays...");fflush(stdout);
    double *VPtr=SpA->V;
  uint32_t *CPtr=SpA->C32b;

  SpA->ActualNonZeros = 0;
  SpA->P[0] = 0;
  for(i=0;i<(int32_t)SpA->NRows;i++){
    //printf("Processing row %d: ",i);
    SpA->P[i+1] = SpA->P[i];
    NonZeroNode * tPtr = ArrayOfLinkedListsOfNodes[i];
    while(tPtr){
      if(tPtr->Col >= SpA->NCols){printf("ERROR - NNZ.col too big - (%d,%d)\n",i,tPtr->Col);exit(0);}
      if((tPtr->Col > i)&&(MXTYPE[1] == 'S')){printf("ERROR - NNZ.col too big for symmetric - (%d,%d)\n",i,tPtr->Col);exit(0);}
      SpA->P[i+1]++;  
      #ifdef READ_VALUES
        *VPtr = tPtr->value;
      #else
        #ifdef VERIFY
          *VPtr = 1.0*(1+rand()%1000);
	#else
          *VPtr = 1.0;
        #endif
      #endif
      //SpA->ActualNonZeros++;
      if(*VPtr!=0.0)SpA->ActualNonZeros++;
      VPtr++;
      *CPtr = tPtr->Col;  CPtr++;
      //printf("(%d,%d) ",tPtr->Row,tPtr->Col);
      tPtr = tPtr->next;
    }
   
    if((i<NROW)&&(MakeUnsymmetric)&&(MXTYPE[1] == 'S'))for(j=ColumnPointers[i];j<ColumnPointers[i+1];j++)if((ArrayOfNodes[j].Row != ArrayOfNodes[j].Col)
    #ifdef READ_VALUES
    &&(ArrayOfNodes[j].value != 0.0)
    #endif
    ){
    //if((i<NROW)&&(MakeUnsymmetric)&&(MXTYPE[1] == 'S'))for(j=ColumnPointers[i];j<ColumnPointers[i+1];j++)if(ArrayOfNodes[j].Row != ArrayOfNodes[j].Col){
      if(ArrayOfNodes[j].Row >= SpA->NCols){printf("ERROR - transposed NNZ.row too big - (%d,%d)\n",i,ArrayOfNodes[j].Row);exit(0);}
      if(ArrayOfNodes[j].Row <           i){printf("ERROR - transposed NNZ.row too small - (%d,%d)\n",ArrayOfNodes[j].Row,i);exit(0);}
      SpA->P[i+1]++;  
      #ifdef READ_VALUES
        *VPtr = ArrayOfNodes[j].value;
      #else
        #ifdef VERIFY
          *VPtr = 1.0*(1+rand()%1000);
	#else
          *VPtr = 1.0;
        #endif
      #endif
      //SpA->ActualNonZeros++;
      if(*VPtr!=0.0)SpA->ActualNonZeros++;
      VPtr++;
      *CPtr = ArrayOfNodes[j].Row;  CPtr++;
    }
    
    //printf("\n");
  } 
  //printf("%sdone%s\n",CRT_DONE,CRT_RESET);
  SpA->NTiles = SpA->ActualNonZeros;
  //printf("%d tiles\n",SpA->NTiles);

//if(SpA->P[SpA->NRows] % 2){
//  printf("making number of nonzeros even...\n");
//  ZerosInserted++;
//  SpA->P[SpA->NRows]++;
//  *VPtr = 0;VPtr++;
//  *CPtr = 0;CPtr++;
//}

  //SpA->ActualNonZeros = SpA->P[SpA->NRows] - ZerosInserted; // FIX for symmetric matrices !!!


  // Cleanup - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  printf("Cleaning up temps...");fflush(stdout);
  fclose(fp);
  FREE(ArrayOfLinkedListsOfNodes);
  FREE(ArrayOfNodes);
  FREE(ColumnPointers);
  printf("%sdone%s\n",CRT_DONE,CRT_RESET);
  //printf("\n");

  return(SpA);
}

//==============================================================================================================================
