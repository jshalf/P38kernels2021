#include <sched.h>
uint64_t OriginalMask;
 int32_t NUMA_Cores          = -1;
 int32_t NUMA_LogCores       = -1;

void Affinity_Init(){ 
  printf("implementing NUMA via <sched.h>\n");

  OriginalMask = 0;
  sched_getaffinity(0, (int)sizeof(OriginalMask), &OriginalMask);
  uint64_t mask = OriginalMask;
  if(mask){
    NUMA_Cores = 0;
    while(mask){if(mask & 0x1)NUMA_Cores++;mask=mask>>1;}
  }
  switch(NUMA_Cores){
    case   1: NUMA_LogCores = 0;break;
    case   2: NUMA_LogCores = 1;break;
    case   4: NUMA_LogCores = 2;break;
    case   8: NUMA_LogCores = 3;break;
    case  16: NUMA_LogCores = 4;break;
    case  32: NUMA_LogCores = 5;break;
    case  64: NUMA_LogCores = 6;break;
    case 128: NUMA_LogCores = 7;break;
    case 266: NUMA_LogCores = 8;break;
  }

  printf("  found %d cores\n",NUMA_Cores);
  if(NUMA_Cores <= 0)exit(0);
  return;
}

void Affinity_Bind_Memory(uint32_t thread){
  thread = thread%NUMA_Cores;
  uint64_t mask = 1<<thread;
  #ifdef INTERLEAVED_MULTICORE
    mask = 1<< ( ((thread<<1) | (thread>>(NUMA_LogCores-1))) & (uint64_t)(NUMA_Cores-1)); // (twiddled mapping on the clovertown)
  #endif
  if(sched_setaffinity(0, (int)sizeof(mask), &mask)<0){printf("Couldn't bind threads to mask=%04lx\n",mask);exit(0);}
  sched_getaffinity(0, (int)sizeof(mask), &mask);
  return;
}

void Affinity_Bind_Thread(uint32_t thread){
  thread = thread%NUMA_Cores;
  uint64_t mask = 1<<thread;
  #ifdef INTERLEAVED_MULTICORE
    mask = 1<< ( ((thread<<1) | (thread>>(NUMA_LogCores-1))) & (uint64_t)(NUMA_Cores-1)); // (twiddled mapping on the clovertown)
  #endif
  if(sched_setaffinity(0, (int)sizeof(mask), &mask)<0){printf("Couldn't bind threads to mask=%04lx\n",mask);exit(0);}
  sched_getaffinity(0, (int)sizeof(mask), &mask);
  return;
}

void Affinity_unBind(){
  uint64_t mask = OriginalMask;
  if(sched_setaffinity(0, (int)sizeof(mask), &mask)<0){printf("Couldn't unbind threads: mask=%04lx\n",mask);exit(0);}
  sched_getaffinity(0, (int)sizeof(mask), &mask);
  return;
}
