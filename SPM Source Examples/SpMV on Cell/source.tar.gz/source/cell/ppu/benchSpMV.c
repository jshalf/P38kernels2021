#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>
#include <libspe2.h>
//#include <libmisc.h>

#include    <free_align.h>
#include  <malloc_align.h>
#include <realloc_align.h>
#define FREE(pointer)            _free_align(pointer)
#define REALLOC(pointer,size) _realloc_align(pointer,size,7)
#define  MALLOC(size)          _malloc_align(size,7)

#define _BEST_ALIGNMENT __attribute__ ((aligned(128)))
//------------------------------------------------------------------------------
#include "../include/configure.h"
#include "../../common/defines.h"
#include "../../common/types.h"
#include "../../common/affinity.h"
//------------------------------------------------------------------------------
#include "../../common/crt.c"
#include "../../common/affinity.c"
#include "../../common/init.c"
#include "../../common/destroy.c"
#include "../../common/loader.c"
#include "../../common/parallelize.c"
#include "../../common/optimize.c"
#include "../../common/spyplot.c"
//==============================================================================
double frequency;
double timePerTrial = 0.01;
uint32_t minTrials = 100;
uint32_t RThreads = 1;
uint32_t CThreads = 1;
double AbsolutePeakGFLOPs = -1.0;
#include "../include/CycleTime.c"
#include "../include/barrier.c"
//==============================================================================
extern spe_program_handle_t spmv_spe;
//==============================================================================
void * bench_blocked_spe(void *arg){
  uint64_t *pthread_args = (uint64_t*)arg;
  uint32_t rc,entry = SPE_DEFAULT_ENTRY;
  uint32_t ID = pthread_args[3];
  //printf("Hello, I'm pthread %2d, %016llx\n",ID,(uint64_t)pthread_args);
  if((rc = spe_context_run(*((spe_context_ptr_t*)pthread_args[1]), &entry, 0, pthread_args, NULL, NULL)) < 0) {
    fprintf(stderr, "Failed spe_context_run(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
    exit(0);
  }
  pthread_exit(NULL);
}

void bench_blocked_pthreads(BlockedSparseMatrix *BlockedSpA, SparseMatrix *SpA){
  Affinity_unBind();
  uint32_t r,c,t,rc,i,trial;
  uint32_t vectorSize = BlockedSpA->NCols;if(BlockedSpA->NRows > BlockedSpA->NCols)vectorSize = BlockedSpA->NRows;
  Affinity_Bind_Thread(0);
  double *X     = (double*)MALLOC(vectorSize * sizeof(double));
  Affinity_Bind_Thread((BlockedSpA->RThreads*BlockedSpA->CThreads)-1);
  double *Y     = (double*)MALLOC(vectorSize * sizeof(double));
  //double *YTrue = (double*)MALLOC(vectorSize * sizeof(double));
  double *Z = NULL;
  //printf("%016llx, %016llx, %016llx, %016llx\n",(uint64_t)BlockedSpA,(uint64_t)X,(uint64_t)Y,(uint64_t)Z);
  for(i=0;i<vectorSize;i++){X[i]=1.0;Y[i]=0.0;}

      pthread_t pthreadIDs[MaxThreads];
  spe_context_ptr_t speIDs[MaxThreads];
             void * speLSs[MaxThreads];
  uint64_t pthread_args[MaxThreads][16] _BEST_ALIGNMENT; // FIX align

  uint32_t nSPEs = spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES, -1);
  if(nSPEs < BlockedSpA->RThreads*BlockedSpA->CThreads) {
    fprintf(stderr, "System only has %d working SPEs, requested %d.\n",nSPEs,BlockedSpA->RThreads*BlockedSpA->CThreads);
    exit(0);
  }

  //if(BlockedSpA->CThreads>1){printf("CThreads>1 not yet supported\n");exit(0);}
  printf("creating %ld pthreads...\n",BlockedSpA->RThreads*BlockedSpA->CThreads);fflush(stdout);

  for(t=0; t<BlockedSpA->RThreads*BlockedSpA->CThreads; t++){
    Affinity_Bind_Thread(t);
    pthread_args[t][0] = (uint64_t)&pthreadIDs[t]; // pthreadID
    pthread_args[t][1] = (uint64_t)    &speIDs[t]; // speID (context)
    pthread_args[t][2] = (uint64_t)     minTrials; // trials
    pthread_args[t][3] = (uint64_t)             t; // Rank
    pthread_args[t][4] = (uint64_t)    BlockedSpA; // Matrix
    pthread_args[t][5] = (uint64_t)             X; // X
    pthread_args[t][6] = (uint64_t)             Y; // Y
    pthread_args[t][7] = (uint64_t)             Z; // Z
    pthread_args[t][8] = (uint64_t)             0; // BestTime
    pthread_args[t][9] = (uint64_t)             0; // GFLOPs
    if((speIDs[t] = spe_context_create(0,NULL)) == NULL) {
      fprintf(stderr, "Failed spe_context_create(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit(0);
    }
    if((rc = spe_program_load(speIDs[t], &spmv_spe)) != 0) {
      fprintf(stderr, "Failed spe_program_load(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit(0);
    }
    if((rc = pthread_create(&pthreadIDs[t], NULL, &bench_blocked_spe, &pthread_args[t])) != 0) {
      fprintf(stderr, "Failed pthread_create(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit(0);
    }
    if((speLSs[t]=spe_ls_area_get(speIDs[t])) == NULL){
      fprintf(stderr, "Failed spe_ls_area_get(errno=%d strerror=%s)\n", errno, strerror(errno));
      exit(0);
    }
    uint32_t LockAddress=0;
    while(spe_out_mbox_status(speIDs[t])<=0){_usleep(1);}
    spe_out_mbox_read(speIDs[t],&LockAddress,1); // FIX error checking
    spe_locks[t]=(int32_t *)(speLSs[t]+LockAddress);
  }
  // spmv bench is off and running
  for(trial=0;trial<minTrials;trial++){
    // start timer
    _barrier(BlockedSpA->RThreads*BlockedSpA->CThreads);
    // do SpMV
    // ...
    _barrier(BlockedSpA->RThreads*BlockedSpA->CThreads);
    // stop timer
  }
  // spmv bench is done
  for(t=0; t<BlockedSpA->RThreads*BlockedSpA->CThreads; t++){
    if((rc = pthread_join(pthreadIDs[t], NULL)) != 0) {
      fprintf(stderr, "Failed pthread_join(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
      exit(0);
    }
    if((rc = spe_context_destroy(speIDs[t])) != 0) {
      fprintf(stderr, "Failed spe_context_destroy(rc=%d, errno=%d, strerror=%s)\n", rc, errno, strerror(errno));
      exit(0);
    }
  }
  printf("joined %d threads\n",BlockedSpA->RThreads*BlockedSpA->CThreads);
  uint64_t AverageCycles=0;
  uint64_t   WorstCycles=0;
  int32_t  SlowestThread=-1;
  for(t=0; t<BlockedSpA->RThreads*BlockedSpA->CThreads; t++){
    AverageCycles+=pthread_args[t][8];
    if(pthread_args[t][8]>WorstCycles){WorstCycles=pthread_args[t][8];SlowestThread=t;}
  }AverageCycles = AverageCycles / (BlockedSpA->RThreads*BlockedSpA->CThreads);
  printf("average=%ld worst=%ld(thread %2d) %3.2f\n",AverageCycles,WorstCycles,SlowestThread,(double)WorstCycles/(double)AverageCycles);

  //printf("\n");
  //for(i=0;i<vectorSize;i++){
  //  printf("Y[%6d] = %12.6e\n",i,Y[i]);
  //}
  FREE(X);
  FREE(Y);
}

//==============================================================================
int main(int argc, char **argv){
  int i,j;
  uint32_t OptimizationMask;

  Affinity_Init();

       if(argc == 2){/* filename = argv[1]*/}
  else if(argc == 4){RThreads=atoi(argv[2]);CThreads=atoi(argv[3]);}
                else{printf("usage: ./a.out [matrix name] [RThreads] [CThreads]\n");exit(0);}

  if(CThreads*RThreads > MaxThreads){printf("Too many threads %d > %d\n",RThreads*CThreads,MaxThreads);exit(0);}

  SparseMatrix *SpA = LoadMatrix_HBF_to_CSR(argv[1],1);
  printf("%d, %d\n",sizeof(SparseMatrix),sizeof(BlockedSparseMatrix));

  printf("calculating frequency\n");
  uint64_t t0 = CycleTime();
  sleep(1);
  uint64_t t1 = CycleTime();
  frequency = (t1-t0)/1e9;
  printf("%0.6f GHz\n",frequency);

  BlockedSparseMatrix *BlockedSpA;
  // try cache blocking - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  OptimizationMask=0;
  if(RThreads*CThreads>1)OptimizationMask |= OPTIMIZATION_THREAD;
  OptimizationMask |= OPTIMIZATION_REGISTER;
  OptimizationMask |= OPTIMIZATION_PREFETCH;
  OptimizationMask |= OPTIMIZATION_CACHE_BLOCK_X;
  OptimizationMask |= OPTIMIZATION_CACHE_BLOCK_Y;

  BlockedSpA = Parallelize_and_Block_SparseMatrix(SpA,RThreads,CThreads,OptimizationMask,SPARSE_VECTOR_FOR_DMA);
  Optimize_BlockedSparseMatrix(BlockedSpA);
  bench_blocked_pthreads(BlockedSpA,SpA);
  Destroy_BlockedSparseMatrix(BlockedSpA);

  //BlockedSpA = Parallelize_and_Block_SparseMatrix(SpA,RThreads,CThreads,CACHE_BLOCK_BOTH   ,SPARSE_VECTOR_FOR_DMA);
  //Optimize_BlockedSparseMatrix(BlockedSpA);
  //bench_blocked_pthreads(BlockedSpA,SpA);
  //Destroy_BlockedSparseMatrix(BlockedSpA);

  exit(0);

  return(0);
}
