//=====================================================================================================
#define MaxThreads             32

#define PageEntriesAvailable   31 // Opteron L1 TLB
#define PageSizeInDoubles      512

#define MaxStanzaLength        10000000
#define MaxStanzas             10000000
#define CacheLinesAvailable    13*1000 // opteron L2(victim)
#define CacheLineSizeInDoubles 8

#define RegBlock_MinR          1
#define RegBlock_MinC          1
#define RegBlock_MaxR          1
#define RegBlock_MaxC          1

#define PREFETCH_MIN_V            0
#define PREFETCH_MIN_C            0
#define PREFETCH_MAX_V         0
#define PREFETCH_MAX_C          0

#define ENABLE_FORMATS         0x0001 // bit mask for formats
#define ENABLE_16b             0

#define ENABLE_AFFINITY_VIA_SCHED
#define LOW_OVERHEAD_BARRIER
//#define INTERLEAVED_MULTICORE // necessary for Clovertown
