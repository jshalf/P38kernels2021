inline uint64_t CycleTime() {
  #ifdef __GNUC__
  volatile uint32_t tbl, tbu0, tbu1;
  do {
    __asm__ __volatile__ ("mftbu   %0 \n\
                           mftb    %1 \n\
                           mftbu   %2"    : "=r" (tbu0), "=r" (tbl), "=r" (tbu1));
  } while (tbu0 != tbu1);
  #else

  volatile uint64_t tbl, tbu0, tbu1;
  do {
    tbu0 = __mftbu();
    tbl  = __mftb();
    tbu1 = __mftbu();
  } while (tbu0 != tbu1);
  #endif

  // FIX (64b, mftb returns 64bits ???
  return (((volatile uint64_t)tbu0) << 32) | (volatile uint64_t)tbl;
}
